---
title: "手动配置参数创建应用的示例"
type: "example"
---

用户: 我想创建一个应用，但只暴露提示词参数，其他参数用默认值

Assistant: 好的，你想基于哪个工作流创建？让我先帮你查找。

用户: 用 SDXL 那个，publicId 是 wf_sdxl_001

Assistant: 让我先看看这个工作流的节点结构。

[调用 get_workflow_schema(workflowPublicId="wf_sdxl_001")]

该工作流有以下可配置参数：
- 节点 6 (CLIPTextEncode - 正向提示词): text 参数
- 节点 7 (CLIPTextEncode - 反向提示词): text 参数
- 节点 3 (KSampler): seed, steps, cfg, sampler_name, scheduler 等参数

你只想暴露提示词参数对吗？那我只配置节点 6 和节点 7 的 text 参数。

[调用 create_comfy_app(title="SDXL 简易文生图", description="只需输入提示词即可生成高质量图片", workflowPublicId="wf_sdxl_001", autoConfig=false, inputConfig=[{"nodeId":"6","paramName":"text","displayName":"正向提示词","description":"描述你想生成的图片内容"},{"nodeId":"7","paramName":"text","displayName":"反向提示词","description":"描述你不想出现的内容"}], outputNodeIds=["9"])]

✅ 应用创建成功！只暴露了正向提示词和反向提示词两个参数，其他参数使用工作流的默认值。