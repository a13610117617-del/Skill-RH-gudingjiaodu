---
title: "创建文生图应用的完整对话示例"
type: "example"
---

用户: 帮我创建一个文生图应用

Assistant: 好的！我先帮你查找可用的文生图工作流。

[调用 list_workflows(title="文生图")]

找到了 3 个相关的工作流：

1. **SD1.5 文生图** (publicId: wf_sd15_001)
   - 描述: 基于 Stable Diffusion 1.5 的基础文生图工作流
   - 标签: SD1.5, 文生图

2. **SDXL 文生图** (publicId: wf_sdxl_001)
   - 描述: 基于 SDXL 的高质量文生图工作流，支持更高分辨率
   - 标签: SDXL, 文生图, 高清

3. **Flux 文生图** (publicId: wf_flux_001)
   - 描述: 基于 Flux 模型的新一代文生图工作流
   - 标签: Flux, 文生图

你想用哪个工作流？推荐使用 **SDXL 文生图**，它在质量和速度之间有很好的平衡。

用户: 用 SDXL 那个

Assistant: 好的，让我先看看 SDXL 文生图工作流有哪些可配置的参数。

[调用 get_workflow_schema(workflowPublicId="wf_sdxl_001")]

该工作流包含以下可配置节点：
- **正向提示词** (CLIPTextEncode): 描述你想生成的图片内容
- **反向提示词** (CLIPTextEncode): 描述你不想出现的内容
- **采样参数** (KSampler): 步数、CFG 等生成参数
- **图片输出** (SaveImage): 保存生成的图片

我将使用自动配置模式创建应用，自动暴露推荐的输入参数。

[调用 create_comfy_app(title="SDXL 文生图", description="基于 SDXL 的高质量文生图应用", workflowPublicId="wf_sdxl_001", tags="AI绘画,SDXL,文生图", autoConfig=true)]

✅ 应用创建成功！

- **标题**: SDXL 文生图
- **Code**: aBcDeFgH
- **访问地址**: /comfy/apps/aBcDeFgH/playground

你可以通过上面的地址直接使用这个应用。需要我帮你把它同步为 Agent 工具吗？这样其他 Agent 也可以调用它来生成图片。