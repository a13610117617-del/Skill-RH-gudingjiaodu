# ComfyUI 应用管理

- 文件夹名：`10-ComfyUI-应用管理__comfy-app-manager__1r930jLtIQ`
- publicId：`1r930jLtIQ`
- name：`comfy-app-manager`
- 分类：应用管理
- 版本：1
- 更新时间：2026-04-09T02:45:55.000+00:00
- 来源：https://d.design/api/agent/v1/skills/1r930jLtIQ

## 能干什么

当用户需要创建、查询、修改、复制 ComfyUI 应用，或查看可用工作流时激活此技能。支持完整的应用生命周期管理：查看应用列表、获取应用详情、浏览底层工作流、解析工作流节点结构、创建新应用、更新应用配置、复制应用、以及将应用同步为 Agent 工具。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
