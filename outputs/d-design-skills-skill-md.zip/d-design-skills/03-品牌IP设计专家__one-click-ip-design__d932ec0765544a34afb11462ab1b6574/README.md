# 品牌IP设计专家

- 文件夹名：`03-品牌IP设计专家__one-click-ip-design__d932ec0765544a34afb11462ab1b6574`
- publicId：`d932ec0765544a34afb11462ab1b6574`
- name：`one-click-ip-design`
- 分类：未标注
- 版本：62
- 更新时间：2026-06-16T08:07:16.000+00:00
- 来源：https://d.design/api/agent/v1/skills/d932ec0765544a34afb11462ab1b6574

## 能干什么

覆盖品牌 IP 设计的完整工作流，帮助设计师告别零散、低效的 IP 设计方式，以结构化的设计思路将品牌特质转化为具有辨识度的 IP 形象。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
