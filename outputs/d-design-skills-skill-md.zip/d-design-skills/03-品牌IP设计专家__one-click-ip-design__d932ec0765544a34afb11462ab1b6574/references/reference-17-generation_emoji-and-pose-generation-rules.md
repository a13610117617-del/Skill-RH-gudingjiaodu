---
title: "generation_emoji-and-pose-generation-rules"
type: "reference"
---

---
title: "generation_emoji-and-pose-generation-rules"
type: reference
---

---
title: "emoji-and-pose-generation-rules"
type: template
---

# 表情包 & 动作库生成规范

来源：ip-derivative-design Skill，已适配 pop-toy-ip-design 工作流。

---

## 一、表情包生成规范

### 风格选择
使用 ask_user_question 询问用户选择平面或 3D：
- **平面表情包**：粗黑描边 + 平涂，与 2D 三视图风格完全一致
- **3D 表情包**：smooth matte vinyl collectible toy 质感，与 3D 三视图风格一致

### 表情子选项（多选，默认全选）
| id | 标签 | 表情描述 |
|------|------|------|
| `smug` | 傲娇 | 半闭眼 + 嘴角微撇 |
| `happy` | 开心 | 大眼微笑 |
| `wink` | 俏皮 | 单眼眨眼 + 微笑 |
| `surprised` | 惊讶 | 圆眼 + 张嘴 |
| `angry` | 愤怒 | 皱眉 + 抿嘴 |
| `sad` | 悲伤 | 垂眼 + 泪痕 |

### 生成规范
- 尺寸：1920×1080，16:9，2K
- 布局：所有表情在同一张图内均匀排列（3×2 或 2×3 网格），纯白背景
- 必须传入 2D 三视图（或 3D 三视图）作为参考图，保证风格一致性
- TEXT RULE：禁止任何文字、标注、水印

### 平面风格一致性规则（核心）
平面表情包的描边粗细、填色风格、线条质感必须与 2D 三视图完全一致：
- 若已有 2D 三视图 → 必须传入作为 images 参考图，prompt 中加入：
```
⚠️ STYLE CONSISTENCY: Match the outline weight, color fill style, and line quality of the reference 2D turnaround sheet exactly. Same stroke width, same flat color fills, same vector-clean aesthetic.
```
- 若尚未生成 2D 三视图 → 先生成 2D 三视图，再做平面表情包

### 平面描边识别规则（生成 3D 版前必须执行）
若 IP 为「平面插画 + 粗黑描边」风格，生成 3D 表情包时必须在 prompt 中加入：
```
IMPORTANT: The reference image uses 2D flat illustration style with bold black outlines. For this 3D vinyl toy version, REMOVE all bold black outlines — do NOT reproduce the flat illustration outlines. Instead use 3D volumetric edge lighting and surface curvature to define the character's form. The result should look like a smooth matte ABS plastic toy, not a 2D illustration rendered in 3D.
```

### 平面表情包 Prompt 模板
```
2D flat character emoji sheet, [N] expressions arranged in a [grid] grid, pure white background.
STYLE (strictly enforced): Same art style as reference turnaround sheet — uniform 6px black outline, flat color fills, zero gradient, zero shading, vector-flat quality.
⚠️ STYLE CONSISTENCY: Match the outline weight, color fill style, and line quality of the reference 2D turnaround sheet exactly.
CHARACTER: [角色名] — [核心特征：头型/配色/服装/眼睛风格]
EXPRESSIONS (each must be clearly different):
- [表情1]：[具体描述]
- [表情2]：[具体描述]
LAYOUT: [N] character heads/busts evenly arranged in grid, same scale, no overlap, pure white background.
TEXT RULE: Zero text, zero labels, zero annotations anywhere.
```

### 3D 表情包 Prompt 模板
```
3D vinyl collectible toy emoji sheet, [N] expressions arranged in a [grid] grid, pure white background.
RENDER STYLE: Smooth matte vinyl toy surface, clean neutral studio lighting, no color cast, soft even illumination.
CHARACTER CONSISTENCY: Match reference 3D turnaround exactly — same proportions, same design details, same color palette.
EXPRESSIONS (each must be clearly different):
- [表情1]：[具体描述]
- [表情2]：[具体描述]
LAYOUT: [N] character heads/busts evenly arranged in grid, same scale, no overlap, pure white background.
TEXT RULE: Zero text, zero labels, zero annotations anywhere.
```

---

## 二、动作库生成规范

### 风格选择
使用 ask_user_question 询问用户选择平面或 3D：
- **平面动作库**：粗黑描边 + 平涂，与 2D 三视图风格完全一致
- **3D 动作库**：smooth matte vinyl collectible toy 质感，与 3D 三视图风格一致

### 6 个基础动作（固定，全部生成在同一张图内）
| 编号 | 动作 | 描述 |
|------|------|------|
| 01 | 标准站姿 | 双手自然垂放，正面朝向 |
| 02 | 双手叉腰 | 双手叉腰，略带自信/傲娇感 |
| 03 | 蹲坐 | 蹲下，双手放膝盖上 |
| 04 | 挥手 | 单手高举挥手，另一手垂放 |
| 05 | 奔跑 | 侧身奔跑姿态，双臂摆动 |
| 06 | 趴地 | 趴在地上，双手托腮，正面朝上 |

### 生成规范
- 尺寸：1920×1080，16:9，2K
- 布局：6 个全身角色在同一张图内均匀横排或 2×3 排列，纯白背景
- 必须传入 2D 三视图（或 3D 三视图）作为参考图
- TEXT RULE：禁止任何文字、标注、水印

### 平面动作库 Prompt 模板
```
2D flat character pose sheet, 6 full-body poses arranged in a single row (or 2×3 grid), pure white background.
STYLE (strictly enforced): Same art style as reference turnaround sheet — uniform 6px black outline, flat color fills, zero gradient, zero shading, vector-flat quality.
⚠️ STYLE CONSISTENCY: Match the outline weight, color fill style, and line quality of the reference 2D turnaround sheet exactly.
CHARACTER: [角色名] — [核心特征描述]
POSES (6 distinct actions, each clearly different):
01. Standard standing — arms relaxed at sides, facing viewer
02. Hands on hips — confident/smug pose
03. Squatting — crouching down, hands on knees
04. Waving — one arm raised high waving, other arm down
05. Running — side-body running pose, arms swinging
06. Lying face-down — lying flat, chin resting on hands, face toward camera
LAYOUT: 6 full-body characters evenly spaced, same scale, no overlap, pure white background.
TEXT RULE: Zero text, zero labels, zero annotations anywhere.
```

### 3D 动作库 Prompt 模板
```
3D vinyl collectible toy pose sheet, 6 full-body poses arranged in a single row (or 2×3 grid), pure white background.
RENDER STYLE: Smooth matte vinyl toy surface, clean neutral studio lighting, no color cast. Each figure casts a very subtle soft shadow directly beneath.
CHARACTER CONSISTENCY: Match reference 3D turnaround exactly — same proportions, same design details, same color palette. Do NOT redesign any element.
POSES (6 distinct actions):
01. Standard standing — arms relaxed at sides, facing viewer
02. Hands on hips — confident/smug pose
03. Squatting — crouching down, hands on knees
04. Waving — one arm raised high waving, other arm down
05. Running — side-body running pose, arms swinging
06. Lying face-down — lying flat, chin resting on hands, face toward camera
LAYOUT: 6 full-body figures evenly spaced, same scale, no overlap, pure white background.
TEXT RULE: Zero text, zero labels, zero annotations anywhere.
```

---

## 三、通用风格一致性原则

1. **参考图必传**：表情包和动作库生成时，必须将已确认的 2D 或 3D 三视图 fileId 作为 images 参数传入，不得省略。
2. **特征提取**：生图前从三视图中提取角色头型、配色、服装、眼睛风格等关键特征，写入 prompt。
3. **平面→3D 描边处理**：平面风格角色生成 3D 版时，必须加入去除描边声明。
4. **尺寸统一**：所有输出 1920×1080，16:9，2K，不得更改。