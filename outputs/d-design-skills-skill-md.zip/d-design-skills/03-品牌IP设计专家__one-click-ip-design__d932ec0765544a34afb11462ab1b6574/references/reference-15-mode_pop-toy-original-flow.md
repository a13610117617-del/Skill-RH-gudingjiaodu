---
title: "mode_pop-toy-original-flow"
type: "reference"
---

---
title: "mode_pop-toy-original-flow"
type: reference
---

流程一览
● Part 1：潮玩IP塑形与故事设定 ── 确立灵魂与角色
● Part 2：潮玩IP设计 ── 定下骨架与视觉生成（2.1 平面2D三视图 → 2.2 自动生成3D立体三视图）
● Part 3：3D工艺规划（可选） ── 进行潮玩IP商业化特殊材质需求生成，并给予"工业CMF指导"
● Part 4：应用拓展 ── 表情包、动作库、主题盲盒、周边拓展等
● Part 5：提案文件交付 ── 将所有产出按照提案逻辑输出html，帮助设计师一键提案

【核心交互规则】
凡需要用户做出选择、确认或补充信息的节点，必须调用 ask_user_question 工具，以结构化选项呈现，禁止以纯文字列举选项让用户手动输入回复。

【尺寸强制规定】
三视图（2D平面三视图、3D立体三视图）输出尺寸必须严格为 1920×1080（宽×高），比例 16:9，不得使用任何其他尺寸或比例，违反时须立即重新生成，必须严格执行！
盲盒系列图不受此限制，尺寸根据 5 个角色横排所需宽度自动适配，优先保证每个角色展示完整、比例一致。

【2D三视图风格前缀，必须严格执行】
每次生成2D平面三视图时，必须将以下前缀逐字注入提示词开头，不得删改：
---
2D flat character turnaround sheet, front / side / back view, pure white background.
OUTLINE RULES (strictly enforced): All outlines and strokes must be pure solid black (#000000) only — absolutely no colored outlines, no grey outlines, no colored strokes of any kind. Outer silhouette stroke width: uniform 6px, no variation. Inner structural lines (clothing seams, facial features, accessories): uniform 3px, no variation. Zero line weight variation — no calligraphic pressure, no tapered ends, vector-flat line quality throughout.
COLOR RULES (strictly enforced): Flat color fills only — hard-edge solid color blocks, zero gradient, zero airbrush, zero soft shading. The only allowed highlight is a single flat solid-color shape (lighter tone, not white, not gradient) on face/neck area only. No drop shadows, no glow effects, no texture overlays.
STYLE: No sketch texture, no hand-drawn feel — clean vector illustration aesthetic. Character outline has sticker-cut silhouette effect (clean crop edge).
LAYOUT: Three views evenly spaced horizontally — LEFT: front view (facing viewer directly), CENTER: strict 90-degree side profile view (character facing right, only ONE side of face visible, single eye visible, no second face or second eye), RIGHT: back view (character facing away). Each view same scale, no overlap. Pure white background.
SIDE VIEW RULE (strictly enforced): The center view must be a true 90-degree profile — only one eye visible, head shown as single silhouette from the side, absolutely no front-facing features visible, no second eye, no second cheek, no frontal face elements.
PROPORTION: Head-to-body ratio approximately 1:1.2, chibi-adjacent but slightly elongated limbs.
TEXT RULE (strictly enforced): Zero text, labels, annotations, captions, watermarks or any written characters anywhere in the image — absolutely none.
---
在此前缀之后，拼接由《IP视觉设定》各字段逐项转译的角色专属英文描述。

【眼睛设计强制规定，必须严格执行】
除非用户明确指定「无眼睛」或「遮脸/隐藏面部」是该 IP 最核心的视觉钩子与设计点，否则所有角色必须设计清晰可见的眼睛。
原因：眼睛是 IP 情绪表达、记忆度和后续表情包/动作库延展的核心载体，缺少眼睛会大幅降低 IP 的辨识度与商业延展性。
眼睛设计要求：
- 必须有明确的眼型设计（圆眼/杏眼/三角眼/半月眼等），不得模糊处理
- 眼睛须与角色性格强绑定（暗黑风可用细长眼、空洞眼；可爱风用大圆眼；街头风用半眯眼）
- 眼睛是视觉记忆钩子的候选项之一，鼓励将眼睛设计为标志性特征
- 若角色有帽子/头发遮挡，必须确保眼睛仍清晰可见，不得被完全遮盖
- 在 Prompt 中必须明确描述眼型、眼神、眼睛颜色，禁止省略眼睛描述

【版权安全规则，必须严格执行】
禁止将任何外部角色图片、参考图、他人设计作品作为 images 参数传入图像生成工具。所有角色造型完全由 Prompt 文字驱动。

【设定→Prompt 转译规则】
生图前须将《IP视觉设定》以下字段逐项转译为英文：
- 角色名称与简述 / 比例 / 视觉记忆钩子 / 色彩规范 / 表情与眼神
禁止跳过任何字段，禁止用模糊词替代具体描述。

【潮玩质感增强指令（必须追加在角色描述末尾，逐字注入）】
---
POP TOY CHARACTER DESIGN QUALITY (strictly enforced):
This is a professional collectible designer toy character sheet — NOT a simple cartoon or emoji. The character must feel like it belongs in a Pop Mart / Medicom Toy / Kasing Lung product line.
SILHOUETTE COMPLEXITY: The character silhouette must be immediately recognizable and distinctive — with at least 2-3 unique shape elements that make it unmistakable.
DESIGN DETAILS: Rich design details within the flat color system — clothing seams, pocket details, button details, texture patterns, accessory details, layered clothing elements. Drawn as clean inner structural lines (3px).
CHARACTER PERSONALITY: Pose, expression, and design details must communicate a strong personality with backstory and emotional depth.
PROPORTION EXAGGERATION: Oversized head (at least 1:1 to 1:1.5 head-to-body ratio), shortened limbs, enlarged expressive features.
SIGNATURE HOOKS: The 1-2 visual memory hooks must be EXTREMELY prominent — bigger, bolder, more extreme than you think necessary.
CLOTHING & ACCESSORIES RICHNESS: Layered details — collar shapes, cuff details, pocket placement, button arrangement, belt/strap elements, fabric patterns. Accessories must be specific and designed.
EYES (strictly enforced): The character MUST have clearly visible, expressive eyes — eyes are the emotional core of the IP and essential for future emoji/pose extensions. Eye design must match the character's personality. Do NOT hide or omit the eyes unless the user has explicitly defined hidden face as the #1 design hook.
---

【3D三视图 2D→3D 一致性强制规定】
第一步：取出 2D 图的 fileId（必须实时读取，不得凭记忆填写）
第二步：以图生图，将 2D 图 fileId 作为 images 参数传入 3D 图像生成工具
第三步：Prompt 开头必须固定注入以下一致性前缀（逐字使用，不得删改）
---
3D soft toy turnaround sheet, front / side / back view, pure white background. CONSISTENCY RULES (strictly enforced): This 3D render must be a direct 3D conversion of the provided 2D flat design reference image — every detail must match exactly: character silhouette, head-to-body ratio, face shape, eye design, expression, hair/head shape, clothing silhouette, clothing details, accessories, color palette, and ALL signature details. Do NOT redesign any element. Do NOT simplify. Do NOT add elements not in the 2D reference. Do NOT change proportions. TEXT RULE (strictly enforced): Zero text, labels, annotations, captions, watermarks or any written characters anywhere in the image — absolutely none. RENDER STYLE: smooth matte vinyl collectible toy, clean studio neutral lighting (no color cast, no warm/yellow light whatsoever), soft even illumination from slightly above, very subtle ambient occlusion in recessed areas only, gentle rounded surface highlight on top of head — clean white highlight only, never yellow or warm-toned. Zero harsh shadows. Zero drop shadow. Zero background shadow. Surface feels like high-quality matte ABS plastic — smooth, clean, slightly soft. Color saturation matches 2D source exactly, no color shift. LAYOUT: Three views (front / side / back) evenly spaced horizontally, same scale, no overlap. Pure white background, 1920x1080, 16:9.
---
第四步：参考 reference：pop-toy-ip-3d-rule

【各阶段最终确认 fileId 记录规则（必须严格执行）】
每个阶段用户确认图片后，必须在内部记录该阶段最终确认的 fileId：
- 2D 三视图最终版 fileId：[用户确认时记录]
- 3D 三视图最终版 fileId：[用户确认时记录]
- CMF 工艺效果图最终版 fileId：[用户确认时记录]
- 盲盒 2D 平面图最终版 fileId：[用户确认时记录]
- 盲盒 3D 效果图最终版 fileId：[用户确认时记录]
- 盲盒故事系列海报最终版 fileId：[用户确认时记录]
- 周边展示图最终版 fileId：[用户确认时记录]
Part 5 生成提案 HTML 时，必须使用以上记录的最终确认 fileId，禁止使用任何过程稿、中间版本或未经用户确认的图片。

Part 1：潮玩IP塑形与故事设定
1.1 基础信息收集：使用 ask_user_question 工具，一次性提出以下问题：
● 角色原型：动物 / 神话·超级符号 / 物件·食物 / 原创人形
● 目标人群：Z世代情绪消费者 / 资深收藏玩家 / 亲子/儿童市场 / 潮流文化爱好者
● 视觉风格：可爱治愈风 / 潮流符号风 / 暗黑风 / 绘本怪兽风
● 故事原型（选填）：可输入初步想法，或选择"交给AI"

1.2 基础故事搭建：输出提案第一部分文本（名字/视觉风格/目标受众/性格关键词/世界观故事150字/视觉钩子/竞品分析），使用 ask_user_question 让用户确认或调整。

Part 2：潮玩IP设计
2.1：平面2D三视图
参考reference：pop-toy-ip-design-style-selection
参考reference：pop-toy-ip-design-methodology（造型方法论，必读）

用户确认 Part 1 后，输出《IP视觉设定》：
● 角色 / 选定风格 / 比例（夸张比例谱系）/ 视觉记忆钩子（1–2个，极端可识别）/ 其余设计归零 / 色彩规范
输出前必须对照《造型自检清单》逐项自检。确认后按转译规则生图。
【尺寸强制】1920×1080，16:9！
2D生成后，ask_user_question 确认或调整。用户确认后记录最终版 fileId。

2.2：3D立体三视图（用户确认2D后自动执行）
按四步骤执行。【尺寸强制】1920×1080，16:9！
3D生成后，ask_user_question 确认或调整。用户确认后记录最终版 fileId。

Part 3：3D工艺规划（可选）
ask_user_question 询问是否需要。根据视觉风格套用 CMF 黄金工艺组合：
- 可爱治愈风：消光半哑光漆(60%) + 珠光漆(30%) + 高光滴胶(10%)
- 暗黑风：高阻尼PU手感漆(60%) + 半透明有色树脂(30%) + 真空电镀(10%)
- 绘本怪兽风：静电植绒/橡胶漆(60%) + 软胶半透明(30%) + 高饱和荧光漆(10%)
- 潮流符号风：经典细砂磨砂漆(60%) + 全息电镀(30%) + 高光丝网印刷(10%)
确认后生成单角色正面工艺效果图，纯白背景，16:9。用户确认后记录最终版 fileId。

Part 4：应用拓展
使用 ask_user_question（multiSelect: true）让用户选择延展方向：

● 表情包系列：6 个核心表情，适配社交媒体

  【表情包执行规范】参考 reference：emoji-and-pose-generation-rules
  1. 无需询问用户选择表情，直接默认生成全部 6 个表情（傲娇/开心/俏皮/惊讶/愤怒/悲伤）
  2. 必须传入已确认的 3D 三视图 fileId 作为 images 参考图
  3. 默认直接生成 3D 表情包，按 reference 中 3D Prompt 模板生成，布局 3×2 网格，纯白背景，1920×1080
  4. TEXT RULE（必须写入 Prompt）：禁止图片上出现任何文字、标注、表情名称、水印——绝对不允许
  5. 生成后使用 ask_user_question 让用户确认或调整，同时询问「是否需要额外生成平面 2D 版本」
  6. 用户明确需要平面版时，再按 reference 中平面 Prompt 模板额外生成
  7. 用户确认后记录最终版 fileId

● 动作库延展：6 个基础动作合图，适配周边/盲盒设计参考

  【动作库执行规范】参考 reference：emoji-and-pose-generation-rules
  1. 无需询问用户选择动作，直接默认生成全部 6 个基础动作（标准站姿/双手叉腰/蹲坐/挥手/奔跑/趴地）在同一张图内
  2. 必须传入已确认的 3D 三视图 fileId 作为 images 参考图
  3. 默认直接生成 3D 动作库，按 reference 中 3D Prompt 模板生成，1920×1080，纯白背景
  4. SHADOW RULE（必须写入 Prompt）：禁止任何脚下投影、椭圆阴影、地面阴影——每个角色在纯白背景上干净浮立，零阴影
  5. TEXT RULE（必须写入 Prompt）：禁止图片上出现任何文字、标注、动作名称、编号、水印——绝对不允许
  6. 生成后使用 ask_user_question 让用户确认或调整，同时询问「是否需要额外生成平面 2D 版本」
  7. 用户明确需要平面版时，再按 reference 中平面 Prompt 模板额外生成
  8. 用户确认后记录最终版 fileId

● 主题盲盒系列：4 款基础款 + 1 款隐藏款，共 5 款

  【盲盒主题选择（用户选择盲盒后必须先执行此步）】：
  使用 ask_user_question 给用户提供 3 个 AI 拟定主题选项 + 1 个自定义选项。
  3 个主题须根据 IP 的性格关键词、世界观故事自动生成，与角色气质强绑定，每个主题附一句简短说明（≤15字）。
  allowCustomInput: true，用户可自行填写主题。
  用户选定主题后，直接进入生图流程，禁止输出 Markdown 设计方案文档。
  生图前在内部完成三维联动设计（表情×动作×道具），自检通过后直接生图，不向用户展示设计方案。

  《盲盒生成规范》（必须严格执行）：
  - 排列：5 个角色同一行横排，绝对禁止分两行；尺寸：推荐 21:9 宽幅
  - TEXT RULE：禁止任何文字、标注、款式名称、水印
  - 隐藏款：明显差异化，置于最右侧；背景纯白，不重叠
  - 装饰限制：禁止角色周围添加任何气氛装饰元素

  【盲盒款式三维联动设计规范（内部执行，不输出给用户）】
  每款在表情 / 动作 / 道具三个维度独立设计，禁止各款雷同。
  ① 表情（每款必须不同）：嘟嘴生气/惊讶大眼/眯眼满足/哭丧委屈/空洞发呆/咧嘴大笑/斜眼鄙视/闭眼享受/神秘微笑。隐藏款必须与基础款明显差异。
  ② 动作（每款必须不同）：双手叉腰/单手举起道具/双臂展开/蹲坐/奔跑/回头张望/抱膝坐地/踮脚伸手/趴地/跳跃。禁止所有款都使用「双手垂放直立」。
  ③ 道具（每款必须有 1–2 个专属道具）：
  【生产可行性原则】✅ 允许：与角色身体有物理连接（手持/穿戴/依附）❌ 禁止：独立漂浮无法生产的元素
  【骨架一致性】允许变化：服装/道具/表情/动作/配色。禁止改变：基础骨架/头型大小/四肢比例/整体轮廓。

  《盲盒 2D 平面图》（用户确认主题后生成）：
  5 款 2D 平面线稿，纯白背景，5 款横排。TEXT RULE：禁止任何文字。尺寸：推荐 21:9 宽幅。
  用户确认后记录盲盒 2D 平面图最终版 fileId。

  《盲盒 3D 效果图》（用户确认 2D 平面图后自动执行）：
  5 款 3D 渲染，纯白背景，正面站立，脚下极轻微圆形投影，5 款横排。TEXT RULE：禁止任何文字。尺寸：推荐 21:9 宽幅。
  3D 效果图生成后，必须使用 ask_user_question 询问用户下一步：
  「需要盲盒故事系列海报」/「跳过，进入周边拓展」/「跳过，直接提案交付」，allowCustomInput: true。
  用户确认后记录盲盒 3D 效果图最终版 fileId。

  《盲盒故事系列海报》（用户选择需要后执行）：
  一张图内横排 5 款叙事场景，每款占 1/5 宽度。尺寸：21:9 超宽幅，2K。TEXT RULE：禁止任何文字。
  【风格强制规定】：必须是 3D 渲染风格——角色为 smooth matte vinyl collectible toy 质感，场景为 3D 渲染环境，整体呈现 3D 动画电影截图质感。禁止使用 2D 插画、水彩、绘本等平面风格。
  每款规范：低角度仰视或 3/4 侧视 / 角色有互动动作 / 三层景深（前景道具、中景角色、背景环境）/ 叙事性强 / 主题色强绑定 / 3D 场景光影真实。
  用户确认后记录盲盒故事系列海报最终版 fileId。

● 周边拓展：毛绒挂件、手机壳等周边品类延展

  【周边拓展执行规范，必须严格执行】：
  固定生成以下 5 种周边品类，一次性生成一张完整的周边展示图：
  手机壳 / 笔记本（本子）/ 毛绒挂件 / 马克杯 / 杜邦纸袋

  【IP 骨架一致性原则】：所有周边角色造型必须严格遵循 Part 2 确定的 IP 设计骨架，不得自由重新设计。

  【周边图案多样化原则】：
  · 手机壳：全身正面标准站姿 + 下方 IP 名称英文点缀（Poppins Bold）
  · 笔记本：头部特写大图 + 封面底部短句英文点缀（Poppins Light）
  · 杜邦纸袋：全身换动作姿态 + 下方品牌英文点缀（Poppins Bold），尺寸最大
  · 毛绒挂件：全身立体还原，直立站姿，正面朝向镜头，无文字
  · 马克杯：全身换动作或换表情，印花面正对镜头，文字可选

  【展示图排布规范（固定版式）】：
  - 俯拍 top-down flatlay，相机从正上方垂直向下拍摄
  - 固定排布：上排 3 款（手机壳左小 + 笔记本中 + 杜邦纸袋右大）/ 下排 2 款（毛绒挂件左 + 马克杯中）
  - 所有产品 0° 旋转，边缘与画面边框完全平行，禁止任何倾斜
  - 背景根据 IP 设定自动选择，与整体风格协调；柔和均匀光线
  - 英文点缀字体：Poppins Bold 或 Poppins Light，颜色与 IP 主色调协调
  - TEXT RULE：仅允许指定品类出现设计性英文点缀，禁止中文、标注、水印
  - 尺寸：16:9，2K；生成后使用 ask_user_question 让用户确认或调整
  - 用户确认后记录周边展示图最终版 fileId

每个延展方向确认后，调用图像生成能力输出对应视觉稿。每张视觉稿生成后，使用 ask_user_question 工具让用户确认或调整。

Part 5：提案文件交付
使用 ask_user_question 询问用户是否准备好输出提案文件。
确认后，将所有阶段产出整合，输出完整 HTML 提案文档：
第一部分：IP定位与故事设定 / 第二部分：视觉设计规范与三视图 / 第三部分：工艺规划说明（如有）/ 第四部分：应用拓展展示（如有）
设计风格：简洁专业，适合对外提案，配色参考IP主色调。

【提案图片选取规则，必须严格执行】
Part 5 生成提案 HTML 时，每个栏目必须使用该阶段用户最终确认的 fileId，禁止使用过程稿、中间版本或未经用户确认的图片。
- 若某阶段经过多次迭代，只取用户最后一次确认的版本。
- 若用户未明确确认某版本，默认取该阶段最后一次生成的图片。
提案各栏目名称与对应图片：
- 2D 平面三视图 → 2D 三视图最终版
- 3D 立体三视图 → 3D 三视图最终版
- CMF 工艺效果图 → CMF 最终版
- 盲盒 - 2D 平面图 → 盲盒 2D 平面图最终版
- 盲盒 - 3D 效果图 → 盲盒 3D 效果图最终版
- 盲盒故事系列海报 → 盲盒故事系列海报最终版
- 周边系列展示图 → 周边展示图最终版