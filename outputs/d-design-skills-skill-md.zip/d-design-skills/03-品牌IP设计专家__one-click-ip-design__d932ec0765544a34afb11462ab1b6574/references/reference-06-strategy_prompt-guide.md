---
title: "strategy_prompt-guide"
type: "reference"
---

---
title: "strategy_prompt-guide"
type: reference
---

---
title: "prompt-guide.md"
type: reference
---

# IP形象生图提示词指南

## 硬性约束一：品牌IP简约原则（必须遵守）

品牌IP区别于潮玩、游戏、动漫角色——品牌IP的核心使命是**在任何媒介、任何尺寸下都保持高辨识度**（从App图标到户外广告牌）。因此必须遵守以下简约原则：

- **做减法而非加法**：角色身上的每一个视觉元素都必须有品牌层面的存在理由。如果一个细节无法回答"这和品牌有什么关系？"或"这在缩小到32px时还能看到吗？"，就应该删除
- **禁止无关装饰**：禁止出现与品牌/IP内核无关的纯装饰性文字、图案、花纹、徽标。例如角色身上的文字如果不是品牌名或有明确意义的品牌符号，则不允许出现
- **大色块 > 渐变细节**：优先使用辨识度高的大面积纯色色块，渐变和复杂纹理仅在品牌调性明确要求时才使用
- **缩放测试**：设计方案应能在以下三种尺寸下保持可辨认：① 大尺寸海报（完整细节可见），② 中等尺寸社交媒体头像（主特征清晰），③ 极小尺寸favicon/图标（剪影仍可识别）
- **细节预算**：角色身上的显著视觉细节总数不超过3-5个（含品牌超级符号、主夸张元素、标志配色分区），超出此数量的细节应被简化或移除

**提示词中的简约控制关键词（推荐包含）**：
```
clean and simple design, minimal unnecessary details, bold clear silhouette, brand-focused design, easily recognizable at any size, no decorative text, no random patterns
```

## 硬性约束二：材质约束（必须遵守）

所有IP形象的**表面材质**统一使用**光滑哑光潮玩质感**，类似搪胶/vinyl toy：

- **材质**：光滑哑光表面（smooth matte surfaces），类似搪胶潮玩/vinyl toy质感，**严格禁止毛绒、毛发、绒毛、皮毛等一切毛质纹理**
- 无论角色采用什么设计风格，表面材质一律为光滑哑光，不得出现任何毛发/绒毛/皮毛质感

## 设计风格（灵活多样）

除以上硬性约束外，设计风格不做统一限制，应根据品牌调性和角色个性灵活选择。以下维度由设计师自由发挥：

- **五官风格**：可以是豆豆眼极简风、也可以是大眼萌系、表情丰富型、酷帅锐利型等，不限定
- **造型复杂度**：在品牌简约原则的约束下灵活选择，保证每个细节都有品牌意义
- **体型比例**：2头身、3头身或其他Q版比例均可，根据角色原型调整
- **配色**：暖色系、冷色系、高饱和、低饱和均可，跟随品牌色和角色性格
- **艺术风格参考**：Miffy极简风、泡泡玛特潮玩风、迪士尼Q版风、日系可爱风等均可作为参考方向

---

## 提示词结构

按以下模块依次组合提示词：

### 1. 主体声明
```
Professional 3D rendered character design of a [角色描述], [根据品牌调性选择的艺术风格描述].
```
> 艺术风格描述示例（按需选择，不限于以下）：
> - 极简风：`with extremely simple and clean art style inspired by Miffy and Chiikawa`
> - 潮玩风：`in trendy designer toy style with expressive features`
> - 萌系风：`in adorable kawaii style with big expressive eyes and soft round shapes`
> - 酷帅风：`in stylized urban vinyl toy aesthetic with sharp confident expression`
> - 可根据品牌需求自由组合描述

### 2. 角色结构
描述角色的体型、头身比、关键造型元素。根据角色原型和品牌调性灵活设计：可极简体块、也可有适度装饰细节。

### 3. 比例
根据角色原型和品牌需求选择合适的Q版比例（2头身、2.5头身、3头身等）。

### 4. 造型
根据品牌调性设计造型风格。强调光滑哑光材质，但在视觉表现力上可灵活处理。

### 4.5 配件约束（重要）

IP形象图中**不允许出现与角色身体脱离的独立道具或配件**（如旁边放一块蛋糕、背景摆一杯咖啡等）。所有物品必须与角色产生直接的肢体接触关系，例如：

- **允许**：角色双手捧着咖啡杯、角色戴着帽子、角色身上穿着围裙
- **禁止**：角色旁边放着一块蛋糕、角色脚边摆着一杯饮料、画面中出现独立的食物/物品

提示词中需明确写入：`single character only, no separate objects, no floating props, no detached accessories, character holds items directly if needed`

### 5. 材质与风格关键词（核心）

**材质关键词（必须包含）**：
```
Vinyl toy aesthetic, smooth matte surfaces, pop mart collectible figure style. cute cartoon character, chibi style, vinyl toy, collectible figure, character design, mascot design. Soft studio lighting, 8K, high resolution.
```

以上材质关键词为**所有IP必须包含的硬性约束**。在此基础上，可根据品牌调性追加风格关键词，例如：
- 极简风追加：`minimal details, extremely simple body shape, round and soft with no complex details`
- 潮玩风追加：`designer toy, art toy, urban vinyl style`
- 萌系风追加：`kawaii, adorable, big sparkling eyes, soft pastel colors`
- 酷帅风追加：`stylized, confident pose, bold color accents`

**严格禁止**使用以下关键词（会破坏光滑哑光材质）：
- ❌ `Pixar style` — 会导致毛发/皮毛质感
- ❌ `photorealistic texture` — 会导致写实毛发
- ❌ `Blender 3D, octane render` — 倾向写实渲染
- ❌ `soft volumetric lighting` — 会增强毛发体积感
- ❌ `fur, fuzzy, fluffy, hairy, furry` — 直接描述毛发质感

**构图与背景**：
```
character centered in frame, full body shot, white background, clean background, front view, symmetrical front-facing pose, looking straight at viewer
```

**重要：视角必须为正面**。所有IP形象图统一使用正面视角（front view），角色面朝观众，身体呈正面对称姿态。**严格禁止**使用侧面视角、3/4视角（three-quarter view）、斜侧面等带角度的构图。提示词中必须明确包含 `front view, symmetrical front-facing pose, looking straight at viewer`，并在负面提示词中加入 `side view, three-quarter view, angled view, profile view, turned body`。

### 6. 负面提示词（避免）
```
fur, fuzzy, fluffy, hairy, furry, fur texture, realistic fur, animal fur, soft fur, peach fuzz, velvet texture, wool, plush texture, realistic animal, photorealistic, Pixar style, low poly, simplified style, blurry structure, poorly drawn, bad anatomy, ugly, tiling, out of frame, blurry, blurred, watermark, grainy, signature, cut off, draft, amateur, low quality, deformed, disfigured, extra limbs, multiple characters, text, separate objects beside character, floating props, detached items, background objects, food or drinks placed next to character, side view, three-quarter view, angled view, profile view, turned body, tilted pose
```

---

## 完整提示词模板

```
Professional 3D rendered character design of a [物种/角色], [艺术风格描述——根据品牌调性选择]. [颜色描述], [五官描述——根据角色性格灵活选择]. [造型特征]. [配件/服饰 — 必须与角色身体直接接触]. [体型比例描述]. Single character only, no separate objects, no floating props. Front view, symmetrical front-facing pose, looking straight at viewer. Vinyl toy aesthetic, smooth matte surfaces, pop mart collectible figure style. cute cartoon character, chibi style, vinyl toy, collectible figure, character design, mascot design. [可选的额外风格关键词]. Soft studio lighting, character centered in frame, full body shot, white background, clean background. 8K, high resolution.
```

## 标杆示例

以下为已验证的高品质提示词。注意：这些示例展示的是**不同风格方向**，新IP应根据自身品牌调性选择合适的风格，不必统一模仿某一个。

### 示例A：极简风 — 拉花小兔（Miffy/Chiikawa 风格）
```
Professional 3D rendered character design of a minimalist cute baby rabbit with extremely simple and clean art style inspired by Miffy and Chiikawa. Soft cream-colored body, tiny dot eyes and a subtle gentle smile. One long ear gracefully curves into a beautiful latte art swirl shape, the other ear stands straight up. The rabbit sits peacefully holding a tiny warm coffee cup with both small round paws directly. Extremely simple body shape, 2-head proportion, round and soft with no complex details. Warm color palette: cream white body, soft peach pink inner ears, gentle caramel brown accents on the latte ear. Single character only, no separate objects, no floating props, no detached accessories. Front view, symmetrical front-facing pose, looking straight at viewer. Vinyl toy aesthetic, pop mart collectible figure style, minimal details, smooth matte surfaces. cute cartoon character, chibi style, pop mart design, vinyl toy, collectible figure, character design, mascot design. Soft studio lighting, character centered in frame, full body shot, white background, clean background. 8K, high resolution.
```

### 示例B：萌系风 — 奶茶品牌IP（大眼可爱风格）
```
Professional 3D rendered character design of an adorable baby cat in kawaii style with big sparkling eyes and rosy cheeks. Soft pastel pink and cream white color scheme, round expressive eyes with star-shaped highlights. Round chubby body shape, wearing a tiny beret and a milk tea cup charm necklace held directly. 2-head proportion, soft and huggable body shape. Single character only, no separate objects, no floating props. Front view, symmetrical front-facing pose, looking straight at viewer. Vinyl toy aesthetic, smooth matte surfaces, pop mart collectible figure style. cute cartoon character, chibi style, vinyl toy, collectible figure, character design, mascot design. Soft studio lighting, character centered in frame, full body shot, white background, clean background. 8K, high resolution.
```

### 示例C：酷帅风 — 运动品牌IP（锐利潮玩风格）
```
Professional 3D rendered character design of a bold eagle in stylized urban vinyl toy aesthetic with sharp confident expression. High saturation red and electric blue color scheme, sharp focused eyes and determined expression. Wearing sporty headband and athletic wristbands directly on body. Slightly taller 2.5-head proportions, dynamic and powerful stance. Single character only, no separate objects, no floating props. Front view, symmetrical front-facing pose, looking straight at viewer. Vinyl toy aesthetic, smooth matte surfaces, designer toy, art toy. cute cartoon character, chibi style, vinyl toy, collectible figure, character design, mascot design. Soft studio lighting, character centered in frame, full body shot, white background, clean background. 8K, high resolution.
```

---

## 平面设定稿 Character Design Sheet

**设定稿是整个图片生成环节的起点，必须先于3D渲染图生成。**

流程顺序：**设定稿定型 → 设定稿验收 → 基于设定稿生成3D渲染图**

### 设定稿风格规范（已标准化，必须严格遵守）

品牌IP设定稿不是插画，而是可以直接交付给VI手册使用的规范图。风格特征：

- **粗黑描边**：统一的粗线条黑色轮廓（bold thick black outlines），不是细线也不是素描线
- **平涂填色**：角色内部使用大面积平涂纯色（flat solid color fill），不用渐变、不用阴影、不用高光
- **基础配色**：仅使用角色的基础色彩方案，**颜色总数控制在4种以内**（含黑色描边和白色留白）
- **高度概括**：形体极度简化概括，只保留最核心的造型特征，比3D渲染图更简约
- **正面视角**：正面全身居中展示
- **纯白背景，零额外元素（硬性红线）**：画面中**只允许出现角色本身**，背景必须为纯白色。严格禁止出现以下任何元素：
  - ❌ 面部/细节放大标注框（facial detail callouts）
  - ❌ 构造/结构分析图（construction diagrams）
  - ❌ 步行循环/多视角参考图（walk cycle, turnaround references）
  - ❌ 色板/配色标注（color palette swatches）
  - ❌ 任何文字标签、标题、注释（text labels, annotations, titles）
  - ❌ 辅助线、网格、尺寸标注（guidelines, grids, dimensions）
  - 提示词中**必须明确写入**：`plain white background, absolutely no additional elements, no detail callouts, no construction diagrams, no text labels, no color swatches, no annotations, only the character itself`

设定稿的三重作用：

1. **结构定型**：用粗描边+平涂锁定角色的造型骨架和基础配色，去掉3D材质和光影的干扰后验证设计是否足够简约
2. **跨媒介基准**：设定稿是IP落地到所有媒介（单色印刷、刺绣、图标、VI手册、周边衍生）的标准规范图
3. **渲染参照**：后续3D渲染图必须严格还原设定稿的造型结构和配色分区，仅增加材质和光影

### 设定稿提示词模板

```
2D flat design character model sheet of a [角色描述]. Bold thick black outlines, flat solid color fills, no gradients, no shading, no highlights, no 3D effects. [基础配色描述，≤4种颜色]. [关键造型特征描述]. [体型比例描述]. Extremely simplified and abstracted form, only essential design features visible. Clean graphic design style, brand mascot specification sheet. Single character, front view, symmetrical front-facing pose. Character centered in frame, full body, plain white background, absolutely no additional elements, no detail callouts, no construction diagrams, no text labels, no color swatches, no annotations, only the character itself. High resolution.
```

### 设定稿标杆示例（已验证，作为标准参照）

以下示例已通过验收，是所有未来设定稿的**风格标杆**。新设定稿在风格上必须与这些标杆保持一致：粗黑描边、平涂填色、纯白背景、零额外元素。

**标杆A：Pico 变色龙（绿色系）**
```
2D flat design character model sheet of a cute simple chameleon mascot. Bold thick black outlines, flat solid color fills, no gradients, no shading, no highlights, no 3D effects. Bright green body fill with darker green accents, black outline and facial features, white eyes. Large spiral curling tail with arrow tip, single pointed horn on head, half-closed confident eyes, subtle smile. Compact chibi 2-head proportion, short stubby limbs, round smooth body. Extremely simplified and abstracted form, only essential design features visible. Clean graphic design style, brand mascot specification sheet. Single character, front view, symmetrical front-facing pose. Character centered in frame, full body, plain white background, absolutely no additional elements, no annotations, only the character itself. High resolution.
```

**标杆B：Remix 赛博DJ（灰+绿色系）**
```
2D flat design character model sheet of a cute vinyl record head DJ mascot. Bold thick black outlines, flat solid color fills, no gradients, no shading, no highlights, no 3D effects. Dark charcoal gray large circular vinyl record head with groove lines, bright green body and short arms, light gray mitten hands, simple dot eyes and small smile on the record face. Compact chibi 2-head proportion, round record head much larger than body, short stubby legs. Extremely simplified and abstracted form, only essential design features visible. Clean graphic design style, brand mascot specification sheet. Single character, front view, symmetrical front-facing pose. Character centered in frame, full body, plain white background, absolutely no additional elements, no annotations, only the character itself. High resolution.
```

**标杆C：Click 光标精灵（白+绿色系）**
```
Simple 2D flat cartoon mascot, cursor arrow character. Thick black outlines, flat green and white colors, no gradients. Arrow-shaped white body, green eyes, green feet, tiny smile. Chibi style, front view, full body, white background only. Brand mascot specification art, clean and minimal.
```

### 设定稿生成规则

- 设定稿必须严格对应阶段3的设计方案，造型结构完全一致
- 颜色总数 ≤ 4种（含黑色描边），使用品牌基础色，不引入装饰性色彩
- 经简约性检查淘汰的元素不得出现
- 设定稿确认后，3D渲染图必须还原设定稿的造型和配色分区，仅增加材质/光影，不得引入设定稿中不存在的新元素
- 如果设定稿中某个细节显得冗余或混乱，应返回阶段3优化造型方案
- 图片尺寸使用 1024x1024

---

## 3D渲染主视觉图提示词

### 「参考图引导 + 观察描述辅助」双通道法（硬性要求）

**核心原则：利用 Claude 的视觉能力直接"看到"对话中已存在的2D设定稿，而非仅依赖文字描述。**

纯文本提示词在2D→3D转换中会产生严重偏移（颜色漂移、形状变形、比例走样），因为模型对相同文字在不同风格下的视觉解读不同。例如描述"green horn"，2D生成与身体同色的角，3D却可能自动渲染为黄金色。**必须基于对话上下文中已存在的2D设定稿图片来指导3D提示词编写**。

### 执行步骤

#### Step 1 — 确认参考图在上下文中（必须）

2D设定稿图片应已存在于当前对话上下文中（来自上一步 `generate_image` 工具的返回结果）。如果图片因对话轮次过多而不再可见，请要求用户重新发送该图片。

> **Claude 适配说明**：与 QoderWork 中使用 Read 工具读取文件不同，Claude API 中图片通过以下方式进入上下文：① generate_image 工具返回的 tool_result 中包含图片；② 用户在消息中上传图片。两种方式进入上下文后，Claude 均可直接"看到"并分析。

#### Step 2 — 观察易偏移特征（辅助）

利用 Claude 的视觉能力，仔细审视2D设定稿图片，重点识别**3D生成中容易偏移的特征**并记录：

```
━━━ 易偏移特征记录 · [角色名] ━━━
· 颜色风险点：[哪些颜色容易被模型误判？如"橙色喙可能变黄"]
· 形状风险点：[哪些形状容易被简化？如"?弯角可能变直"]
· 比例风险点：[哪些比例容易走样？如"头部占比可能缩小"]
· 材质风险点：[哪些部位容易出现毛发？如"圆球身体可能长毛"]
━━━━━━━━━━━━━━━━━━━
```

**重要：将此观察记录作为文字保存在你的回复中**。这样即使图片后续离开上下文窗口，你仍然拥有准确的文字描述可供参考。

#### Step 3 — 编写双通道提示词

提示词由两部分组成：

**A. 风格转换指令**（主体，告诉模型"把2D变成3D"）：
```
Convert the character from the reference 2D design sheet into a 3D vinyl toy figure. Maintain exactly the same proportions, colors, shapes, and design features as shown in the reference image.
```

**B. 易偏移特征加固**（辅助，用否定句锁定容易出错的细节）：
```
[基于Step 2的记录，对风险点逐一加固]
例：ORANGE beak NOT yellow NOT brown. Question mark CURVED crest NOT straight horn. Head is 60% of total height.
```

### 3D提示词模板（新版）

```
3D vinyl toy figure based on the reference 2D character design sheet. Maintain exactly the same character design, proportions, color scheme, and structural features as the reference image. [易偏移特征加固描述，含颜色、形状、比例的否定句]. Smooth matte vinyl toy surface, soft studio lighting. Front view, symmetrical, full body, centered, plain white background. Simple clean minimal design. No fur, no fuzzy texture. 8K high resolution.
```

### 3D提示词编写规则

- **结构锁定语句（必须包含）**：提示词中必须出现"maintain the same design as the reference"或同义表达，明确要求模型还原参考图
- **用否定句加固颜色**：对易偏移的颜色用否定句，如`ORANGE beak, NOT yellow, NOT brown`
- **用百分比锚定比例**：`head is 55% of total height`而非`large head`
- **关键差异用大写+否定**：`white ROUNDED RECTANGLE face (NOT circular)`
- **不重复描述已有特征**：模型已经通过参考图"看到"了角色，提示词只需补强易偏移的细节，不必从零描述整个角色
- **统一尾缀**：所有3D提示词末尾统一附加 `Smooth matte vinyl toy surface, soft studio lighting. Front view, symmetrical, full body, centered, plain white background. Simple clean minimal design.`
- **禁止引入新元素**：3D提示词不得描述2D设定稿中不存在的任何新元素

### 对比检查

3D生成完成后，**必须将3D结果与2D设定稿并排比对**，检查以下维度：
- 整体轮廓/剪影是否一致
- 配色分区是否匹配（面积比、颜色准确度）
- 标志性元素的位置、大小、形态是否还原
- 是否出现2D中不存在的多余元素

如发现不一致，调整提示词中的加固描述后重新生成。
