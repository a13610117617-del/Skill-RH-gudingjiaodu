---
title: "generation_pop-toy-3d-render-style"
type: "reference"
---

---
title: "generation_pop-toy-3d-render-style"
type: reference
---

---
title: "pop-toy-ip-3d-render-style"
type: example
---

# 3D 立体三视图渲染规范（已验证）

## 验证通过的渲染参考图
fileId：pre/ai/style-fusion/2026-06-02/b09c4cfa-1fd0-48f5-9904-a1a71c5dc321.png

## 渲染风格倒推结论

### 光照规范
- 光源色温：中性白光，严禁暖黄/橙色色偏（no color cast, no warm/yellow light whatsoever）
- 光源方向：从略高于正面方向柔和打入
- 高光：头顶/肩部一块干净圆润的白色高光，严禁黄色或暖色高光

### 阴影规范
- 零强烈阴影（Zero harsh shadows）
- 零地面投影（Zero drop shadow）
- 零背景阴影（Zero background shadow）
- 仅允许凹陷区域极轻微的环境遮蔽（very subtle ambient occlusion in recessed areas only）

### 材质规范
- 哑光 ABS 塑料质感（high-quality matte ABS plastic）
- 表面光滑、干净、略带柔软感
- 色彩饱和度与 2D 原稿完全一致，无色偏

### Prompt 前缀（每次生成3D三视图必须逐字注入）
```
RENDER STYLE: smooth matte vinyl collectible toy, clean studio neutral lighting (no color cast, no warm/yellow light whatsoever), soft even illumination from slightly above, very subtle ambient occlusion in recessed areas only, gentle rounded surface highlight on top of head — clean white highlight only, never yellow or warm-toned. Zero harsh shadows. Zero drop shadow. Zero background shadow. Surface feels like high-quality matte ABS plastic — smooth, clean, slightly soft. Color saturation matches 2D source exactly, no color shift.
```