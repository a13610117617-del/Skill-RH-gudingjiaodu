---
title: "generation_pop-toy-2d-style-reference"
type: "reference"
---

---
title: "generation_pop-toy-2d-style-reference"
type: reference
---

---
title: "pop-toy-ip-2d-style-reference"
type: example
---

# 2D 三视图线稿风格基准参考

## 参考图
fileId：pre/adic-planning/2026-06-02/6f31ec6c-2401-4b42-8ce2-1f701df1e47b/QUQ2Vt1Qpb.png

## 风格倒推结论（已验证）

### 描边规范
- 外轮廓：纯黑 #000000，uniform 6px，无粗细变化
- 内部结构线（服装缝线、五官、配件）：纯黑 #000000，uniform 3px，无粗细变化
- 禁止：彩色描边、灰色描边、笔压感、锥形收尾、任何线条粗细变化

### 上色规范
- 纯色平涂，硬边色块，零渐变、零柔化阴影、零喷枪效果
- 唯一允许的高光：面部/颈部区域单块纯色（浅色调，非白色，非渐变）
- 禁止：投影、发光效果、纹理叠加

### 风格质感
- 矢量插画质感，无手绘纹理、无素描感
- 角色外轮廓带贴纸裁切效果（干净裁边）

### 比例与表情
- 头身比约 1:1.2，chibi 感但四肢略拉长
- 表情：重睑下垂眼 + 粗均匀黑色睫毛线 + 嘴角下撇，街头叛逆感

### 排版布局
- 正面 / 侧面 / 背面三视图横向等距排列
- 纯白背景，各视图等比例，无重叠

## Prompt 前缀（每次生成必须逐字注入开头）
```
2D flat character turnaround sheet, front / side / back view, pure white background.
OUTLINE RULES (strictly enforced): All outlines and strokes must be pure solid black (#000000) only — absolutely no colored outlines, no grey outlines, no colored strokes of any kind. Outer silhouette stroke width: uniform 6px, no variation. Inner structural lines (clothing seams, facial features, accessories): uniform 3px, no variation. Zero line weight variation — no calligraphic pressure, no tapered ends, vector-flat line quality throughout.
COLOR RULES (strictly enforced): Flat color fills only — hard-edge solid color blocks, zero gradient, zero airbrush, zero soft shading. The only allowed highlight is a single flat solid-color shape (lighter tone, not white, not gradient) on face/neck area only. No drop shadows, no glow effects, no texture overlays.
STYLE: No sketch texture, no hand-drawn feel — clean vector illustration aesthetic. Character outline has sticker-cut silhouette effect (clean crop edge).
LAYOUT: Three views (front / side / back) evenly spaced horizontally on pure white background, each view same scale, no overlap.
PROPORTION: Head-to-body ratio approximately 1:1.2, chibi-adjacent but slightly elongated limbs.
EXPRESSION: Heavy-lidded droopy eyes with thick uniform black lash line, downturned mouth — sulky / street attitude.
```