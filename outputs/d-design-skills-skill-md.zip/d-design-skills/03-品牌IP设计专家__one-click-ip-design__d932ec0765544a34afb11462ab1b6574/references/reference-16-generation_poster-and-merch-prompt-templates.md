---
title: "generation_poster-and-merch-prompt-templates"
type: "reference"
---

---
title: "generation_poster-and-merch-prompt-templates"
type: reference
---

---
title: "poster-and-merch-prompt-templates"
type: template
---

# IP 海报 & 实物周边 Prompt 模板

## IP 叙事场景海报（ip_poster）

参考风格图：
- Popmart Molly 艺术家系列：https://industryai.oss-cn-beijing.aliyuncs.com/pre/adic-planning/2026-06-11/709f8169-48c1-45d0-97ff-a2dc184b3fb2/ECRoHGYZik.jpg?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=4FmcSQdahEDWvkcmcxSFYapW%2BYc%3D&x-oss-process=image%2Fformat%2Cjpg
- CryBaby 月亮系列：https://industryai.oss-cn-beijing.aliyuncs.com/pre/adic-planning/2026-06-11/02cbe41e-9549-4122-8c1d-4f8e3b7f759c/OZPa39-YTv.jpg?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=R8%2BV9kaM6VCOTcUBFH8IPsbnE%2Bc%3D&x-oss-process=image%2Fformat%2Cjpg
- Baby Molly 抱抱探索系列（森林）：https://industryai.oss-cn-beijing.aliyuncs.com/pre/adic-planning/2026-06-11/60d20854-bcc4-40e2-983e-e90d46f8e793/KKYXOwO3Nm.jpg?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=AhyM%2FslU4ypIiPjhCYXAWyy5hgc%3D&x-oss-process=image%2Fformat%2Cjpg
- Baby Molly 抱抱探索系列（野餐）：https://industryai.oss-cn-beijing.aliyuncs.com/pre/adic-planning/2026-06-11/8bf6e1db-f15f-49f5-960d-0c9190b7c3a5/0MryPVKcyn.jpg?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=3O1KG0SFbV0ZXbqyF22ra6VkLno%3D&x-oss-process=image%2Fformat%2Cjpg
- Hirono 都市系列：https://industryai.oss-cn-beijing.aliyuncs.com/pre/adic-planning/2026-06-11/49f85c3d-c461-4618-b5a4-414b434e19b5/wrj_b6cDh5.jpg?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=H%2FeyXkpDRQWXgx2dAGM5bKzjgOA%3D&x-oss-process=image%2Fformat%2Cjpg

### 核心 prompt 框架

```
IP brand campaign poster, 9:16 vertical format, Popmart-style cinematic scene poster.
Reference style: Popmart Molly/Hirono/CryBaby campaign posters — IP character placed in a rich narrative scene environment, character interacting dramatically with the scene, cinematic lighting, brand logo and series name as typographic elements.

⚠️ CHARACTER FIDELITY (highest priority): [从原图逐一提取并填入角色特征]

SCENE: [具体场景：地点 + 天气 + 时间 + 角色具体动作 + 情绪]
COMPOSITION:
- Character occupies lower 50-70% of frame, large and impactful
- Cinematic depth: foreground / midground (character + main scene) / background (atmospheric)
- Upper area: series name typography in brand style (elegant, not overly decorative)
- Top corner: brand logo area (small, clean)
- Bottom: subtle copyright line

STYLE: 3D vinyl toy render quality, Popmart collectible matte surface, cinematic scene photography aesthetic, ultra high quality, premium IP campaign poster.
```

### 关键规则
- **禁止白底展示图风格**，必须是叙事场景
- 角色必须与场景有具体互动，不得傻站
- 可含品牌名/系列名排版，风格优雅
- 场景光线必须有氛围感（黄金时段/月光/雨天/聚光灯等）

---

## 实物周边六件套（merch）

### 核心 prompt 框架

```
Brand IP merchandise collection showcase. 6 physical merchandise items freely arranged on a single unified warm off-white background (#F0EEE8). NOT a grid — items scattered naturally, slight overlaps, editorial brand lookbook style.

⚠️ CHARACTER FIDELITY: [从原图逐一提取并填入角色特征]

⚠️ FACING RULES (strictly enforced): ALL 6 items must face directly forward — front face fully visible, NO tilting, NO rotation, NO angled views. Hardcover notebook: perfectly upright, zero tilt (0° rotation), front cover facing viewer directly.

Each item shows the IP character in a DIFFERENT pose/expression for variety.
Hardcover notebook as hero center piece (large, perfectly upright, prominent).
Other 5 items (mug, phone case, tote bag, pin badge, embroidered patch) arranged freely around it.
Soft drop shadows. NO text, NO labels. Ultra high quality product render, 1920x1080.

ITEM DETAILS:
- Center: Hardcover notebook, perfectly upright (0° rotation), brand color cover, IP character standing pose
- Upper left: Phone case, upright, IP character arms-up cheerful pose
- Upper right: Ceramic mug, front-facing, IP character waving pose
- Lower left: Canvas tote bag, upright front-facing, IP character walking pose
- Lower center: Round pin badge, face-on, IP character face close-up, gold metal border
- Lower right: Embroidered patch, face-on, IP character sitting relaxed pose, embroidery texture
```

### 关键规则
- 统一暖白背景 #F0EEE8，6 件共享
- 所有产品正面朝向，禁止倾斜旋转
- 笔记本完全摆正（0° 旋转），中心主角
- 每件 IP 姿势各不相同
- 完全无文字标签