---
title: "generation_turnaround-and-pose-prompt-templates"
type: "reference"
---

---
title: "generation_turnaround-and-pose-prompt-templates"
type: reference
---

---
title: "turnaround-and-pose-prompt-templates"
type: template
---

# 三视图 / 动作库 / 表情包 Prompt 模板

## 平面三视图（flat_3view）

必须逐字注入以下前缀：

```
2D flat character turnaround sheet, front / side / back view, pure white background.
OUTLINE RULES (strictly enforced): All outlines and strokes must be pure solid black (#000000) only — absolutely no colored outlines, no grey outlines, no colored strokes of any kind. Outer silhouette stroke width: uniform 6px, no variation. Inner structural lines (clothing seams, facial features, accessories): uniform 3px, no variation. Zero line weight variation — no calligraphic pressure, no tapered ends, vector-flat line quality throughout.
COLOR RULES (strictly enforced): Flat color fills only — hard-edge solid color blocks, zero gradient, zero airbrush, zero soft shading. The only allowed highlight is a single flat solid-color shape (lighter tone, not white, not gradient) on face/neck area only. No drop shadows, no glow effects, no texture overlays.
STYLE: No sketch texture, no hand-drawn feel — clean vector illustration aesthetic. Character outline has sticker-cut silhouette effect (clean crop edge).
LAYOUT: Three views evenly spaced horizontally — LEFT: front view (facing viewer directly), CENTER: strict 90-degree side profile (only ONE eye visible), RIGHT: back view (character facing away). Each view same scale, no overlap. Pure white background.
```

---

## 平面动作库（flat_pose）

### 布局规范
- 2 行 × 3 列网格
- 每格独立贴纸式角色，无文字标签，无边框
- 白色背景，1920×1080

### 完整 prompt 前缀

```
2D flat character action pose sheet, 6 poses in a 2-row × 3-column grid layout, pure white background, 1920x1080 canvas.

⚠️ CHARACTER FIDELITY (highest priority): All 6 poses must be EXACT reproduction of the IP character in reference image [0]. Extract and match every detail — head shape, face features, outfit colors/patterns, accessories, body proportions. Do NOT invent or simplify any design element.

OUTLINE RULES: All outlines pure solid black (#000000). Outer silhouette: uniform 6px. Inner structural lines: uniform 3px. Zero line weight variation.
COLOR RULES: Flat color fills only, hard-edge solid blocks, zero gradient, zero shading, zero glow, zero drop shadow.
LAYOUT RULES: 2 rows × 3 columns grid. Top row L→R: poses 1, 2, 3. Bottom row L→R: poses 4, 5, 6. Each pose is an independent sticker-style character, clean silhouette crop edge, ample spacing, NO text labels, NO borders. All 6 poses fully visible. Same scale per character.
```

### 6 个动作描述（必须逐一写入）

```
TOP ROW LEFT — Pose 1: Standing upright facing viewer, both arms relaxed at sides, neutral expression.
TOP ROW CENTER — Pose 2: Walking, mid-stride, one leg forward one leg back, arms swinging, casual expression.
TOP ROW RIGHT — Pose 3: Running, body leaning forward, right leg raised knee bent, left leg extended back, arms pumping, determined expression.
BOTTOM ROW LEFT — Pose 4: Both arms raised high V-shape celebration, eyes curved happy crescents, mouth open big smile.
BOTTOM ROW CENTER — Pose 5: One arm raised waving hello, other arm relaxed, friendly smile.
BOTTOM ROW RIGHT — Pose 6: Sitting on ground, legs extended forward, relaxed calm expression.
```

---

## 立体三视图（3d_3view）平面描边去除声明

若 IP 原图为平面插画风格，生成立体版时必须加入：

```
IMPORTANT: The reference image uses 2D flat illustration style with bold black outlines. For this 3D vinyl toy version, REMOVE all bold black outlines — do NOT reproduce the flat illustration outlines. Instead use 3D volume edge lighting and soft ambient occlusion to define form boundaries. The result must look like a physical 3D vinyl collectible toy, not a 2D illustration.
```

---

## 参考图链接

- 平面动作库正确示例（2×3 网格，贴纸风格）：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-15/699b198b-ad2f-490b-a612-0ee3ccc89c38.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=8ujfV9x6Dqxv3G%2FfMf3o0wk2D5Q%3D&x-oss-process=image%2Fformat%2Cpng
- 平面三视图正确示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-11/52a4f5a1-5bf4-4652-803c-65f8fe71c416.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=IlhVcsuGtJvoxUsFV56ikTmFVKg%3D&x-oss-process=image%2Fformat%2Cpng
- 盲盒产品陈列图示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-11/da390a5b-c998-412e-9c94-f8404d512595.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=a7XBkz86qP2MSqwJFugNuycamjw%3D&x-oss-process=image%2Fformat%2Cpng
- 场景故事海报墙示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-11/296371b0-9635-4c7d-a6b6-66fc0fb2c61b.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=a%2Fby0TBTCWkrlYIrxgkuRAddEvc%3D&x-oss-process=image%2Fformat%2Cpng
- 实物周边六件套示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-11/87bdb78a-e3cd-4659-a58a-8879a30f1e05.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=%2BaZikJy1Lpg4zBiZr79SDn2O4n4%3D&x-oss-process=image%2Fformat%2Cpng
- IP 叙事场景海报示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-11/b51fd8c8-cc06-49e4-b59c-e2680b2bdaf6.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=pbb7i1oFHYSa6B8deoE5gGi30Vc%3D&x-oss-process=image%2Fformat%2Cpng