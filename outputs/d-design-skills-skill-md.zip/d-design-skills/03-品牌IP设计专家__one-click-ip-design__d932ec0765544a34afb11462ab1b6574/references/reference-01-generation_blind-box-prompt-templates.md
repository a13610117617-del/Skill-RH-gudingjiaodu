---
title: "generation_blind-box-prompt-templates"
type: "reference"
---

---
title: "generation_blind-box-prompt-templates"
type: reference
---

---
title: "blind-box-prompt-templates"
type: template
---

# 盲盒系列 Prompt 模板

## 产品陈列图（lineup）

```
Blind box series product display, 5 characters in a single horizontal row, pure white background, 1920x1080 canvas.
5 characters same base design, different themed outfits, each standing on small circular base.
3D vinyl toy render quality, Popmart collectible level, soft studio lighting, subtle ground shadow.
NO text labels.

⚠️ CHARACTER FIDELITY: [从原图逐一提取并填入角色特征]
ONLY outfit/accessories change per theme — head, face, body proportions stay IDENTICAL.
```

---

## 场景故事海报墙（poster_wall）

参考风格图：
- 五格叙事场景海报墙示例：https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-06-09/208f343f-02dd-49dc-ac2f-f915382ebaa4.png?Expires=1781262710&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=FIfW5QnHMGPKIvROg40Q9X3iST4%3D&x-oss-process=image%2Fformat%2Cpng

### 尺寸规范
- aspectRatio：`21:9`，resolution：`2K`
- 单格：1242px × 1660px，5 格总宽 6210px
- 5 格无缝拼接，无分隔线，无背景

### 骨架锁定声明（必须逐字写入 prompt 开头）

```
⚠️ SKELETON LOCK (highest priority): The character in ALL panels must be an EXACT match to the blind box figures shown in reference image [1]. Do NOT redesign, simplify, or alter the character's head shape, face features, body proportions, or costume structure in any way. The scene and pose change, but the character must look IDENTICAL to the reference figures. Any deviation is a critical error.
```

### 3D 渲染风（3d_render）完整框架

```
Blind box series cinematic story poster wall, 5 vertical panels seamlessly joined side by side, each panel 1242px × 1660px, NO dividing lines, NO gaps, NO borders, NO outer background.

⚠️ SKELETON LOCK: [逐字加入上方声明]
⚠️ TEXT RULES: NO text, NO numbers, NO letters, NO labels anywhere. Completely text-free.

RENDER STYLE: 3D vinyl toy render quality, Popmart collectible matte surface, cinematic 3D scene environments, soft atmospheric lighting.
LAYOUT: 5 panels seamlessly joined. Each panel: distinct color palette, lighting mood, 3D scene depth (foreground/midground/background).
SCENE REQUIREMENTS: Character ACTIVE pose in 3D environment (NOT standing still). Unique cinematic lighting per panel.

[逐一写入每格场景：地点+天气+时间+角色具体动作+情绪+光线氛围+前景元素]
```

### 2D 插画风（2d_illustration）完整框架

```
Blind box series cinematic story poster wall, 5 vertical panels seamlessly joined side by side, each panel 1242px × 1660px, NO dividing lines, NO gaps, NO borders, NO outer background.

⚠️ SKELETON LOCK: [逐字加入上方声明]
⚠️ TEXT RULES: NO text, NO numbers, NO letters, NO labels anywhere. Completely text-free.

STYLE: 2D flat illustration, bold black outlines, flat color fills, Ghibli-inspired narrative scene, cel-shading.
LAYOUT: 5 panels seamlessly joined. Each panel: distinct color palette, lighting mood, 3-layer scene depth.
SCENE REQUIREMENTS: Character ACTIVE pose (NOT standing still). Environmental storytelling. Unique mood lighting per panel.

[逐一写入每格场景]
```

### 每格场景必须包含
1. 场景环境（地点、天气、时间）
2. 角色具体动作（不得写"站着"或"展示"）
3. 情绪表达
4. 光线氛围
5. 前景装饰元素