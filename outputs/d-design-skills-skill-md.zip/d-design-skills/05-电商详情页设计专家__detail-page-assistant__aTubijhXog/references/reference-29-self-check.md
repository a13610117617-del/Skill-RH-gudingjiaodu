---
title: "self-check"
type: "reference"
---

# 输出前模板校验清单

> 在生成 HTML 的**最后一个 Section 之前**对照本清单执行校验。全部通过后再输出最终 HTML。

---

## 致命级（7 项必查，任一项不通过则必须重写）

### 1. `<style>` 标签内容检查（最高优先级）

- [ ] `<style>` 中**仅包含**：`html, body` reset + `@font-face` 字体声明
- [ ] `<style>` 中**不存在任何** CSS 类（`.xxx {`）、ID 选择器（`#xxx {`）、标签选择器（`section {`、`div {`）、伪类（`:root`）、CSS 变量（`var(--xxx)`）
- [ ] HTML 中**不存在** `class="xxx"` 属性（所有样式必须内联）
- [ ] **快速自查**：在 `<style>` 中搜索 `{`，除了 `html, body {` 和 `@font-face {` 外不应出现任何 `{`

### 2. Section 尺寸 — 内联显式声明

- [ ] 每个 Section 的内联 `style` 中都包含 `width: XXXpx` 和 `height: XXXpx`
- [ ] 数值严格等于 `section-size-map.md` 映射表：16:9 → 1200×675，1:1 → 800×800，4:3 → 790×592.5
- [ ] **同页所有 Section 使用完全相同的宽高值**（禁止 hero 900px、mood 800px、scene 860px 等不一致写法）
- [ ] 顶层容器 `width` 必须等于 Section `width`

### 3. 图片来源 — 全部 Nano2

- [ ] 全局搜索所有 `<img src="...">`，确认 `src` 全部指向 Nano2 生成图 URL
- [ ] **不存在**用户原始上传图的 URL
- [ ] 所有 `<img>` 包含 `data-image-id` 属性

### 4. 模式归属 — 无杂交

- [ ] 每个 Section 严格归属模式 A **或**模式 B 中的一种
- [ ] **不存在**"半屏 absolute 图片 + 半屏文字 + 交界渐变"的杂交形态

### 5. 徽章标签 — 纯文字无框

- [ ] **不存在**任何带 `background-color`、`border`、`padding`、`border-radius` 组合的"小块标签"元素
- [ ] 徽章标签仅使用 `font-size`、`color`、`letter-spacing`、`margin` 控制视觉

### 6. 字体 — 仅 2 种字重 + 内联标注

- [ ] 全局搜索 `font-family:`，确认**只出现** `language_font.md` 中定义的 2 种字重名称
- [ ] **不存在**任何额外字重（如 Thin、Light、SemiBold、Bold、Oswald 等）
- [ ] 每个承载文本的标签都用内联 `style` 独立标注了 `font-family`

### 7. Section 标签必须为 `<div>`

- [ ] **不存在** `<section>` 标签（全部使用 `<div>`）

---

## 重要级（6 项抽查）

### 8. 模块构成
- [ ] Section 总数 ≥ 6，且包含至少 3-5 个非卖点模块

### 9. 卖点覆盖
- [ ] 5 个卖点全部覆盖，无一遗漏

### 10. Emoji 清零
- [ ] 全局不存在任何 Emoji 字符

### 11. 模式 A object-fit 检查
- [ ] 所有模式 A Section 中的 `<img>` 都使用 `object-fit: contain`
- [ ] **不存在** `object-fit: cover`（唯一允许 `cover` 的仅模式 B 的整屏氛围背景图）

### 12. 模式 A 图片容器 — 1:1 正方形
- [ ] 16:9 模式 A 的图片容器使用内联 `width`/`height` 写死为**相等像素值**（如 500px×500px）
- [ ] 4:3 模式 A 的图片容器在 50% 宽度容器内通过 `width:100%; aspect-ratio:1/1` 保持正方形（非写死固定像素）
- [ ] 1:1 模式 A 的图片容器使用内联 `width`/`height` 写死为**相等像素值**（如 300px×300px）
- [ ] 所有模式 A 图片容器包含 `aspect-ratio: 1/1`
- [ ] **4:3 左右分栏文字区**：与图片区各占 50%（`flex:0 0 50%; width:50%`）
- [ ] **不存在** `flex: 1`、`height: 100%`、`flex: 1.1` 等自适应写法

### 13. 渐变蒙层 — 仅模式 B
- [ ] `linear-gradient` / `radial-gradient` **仅出现在模式 B** 的蒙层容器上（`position:absolute; inset:0`）
- [ ] 模式 A Section 内**不存在**任何渐变蒙层
- [ ] 渐变至少使用 5-6 个色标点（非简单 2 段渐变）
- [ ] 渐变**不存在**于文字子容器上（`width:50%` 等），仅在全屏蒙层容器上

### 14. 反模板复制
- [ ] 配色、字体、文案全部为本次新生成，未直接 copy 案例内容
