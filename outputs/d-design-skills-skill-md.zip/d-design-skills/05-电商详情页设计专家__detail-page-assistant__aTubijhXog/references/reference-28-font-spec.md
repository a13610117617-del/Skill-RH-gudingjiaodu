---
title: "font-spec"
type: "reference"
---

# 字体规范（仅 2 种字重 + 内联标注）

> 字体选择、字重名称、`@font-face` 加载规则。字号规范见各模板文件的"字号规范"表。

---

## ⚠️ 核心铁律：每种语言只允许 2 种字重

**每种语言只使用 `language_font.md` 中定义的 2 种字重，严禁引入第 3 种或任何额外字体**。

以中文（zh-cn）为例：
- ✅ 允许：`AlibabaPuHuiTi_2_55_Regular`（正文）、`AlibabaPuHuiTi_2_95_ExtraBold`（标题）
- ❌ 严禁：`AlibabaPuHuiTi_2_35_Thin`、`AlibabaPuHuiTi_2_45_Light`、`AlibabaPuHuiTi_2_75_SemiBold`、`AlibabaPuHuiTi_2_85_Bold`、`Oswald`、`FlyFlowerSong`、`LogoSCUnboundedSans` 等任何额外字重或字体

如需在标题和正文之间建立字重梯度，**只能用字号差，不能引入中间字重**。

---

## 字体加载

- **加载方式**：根据 `target_language` 查 `language_font.md`，使用 `@font-face` 加载
- **加载位置**：写在 HTML `<head>` 的 `<style>` 标签内
- **严禁**引入 Google Fonts 或任何第三方 CDN 链接
- **字重数量**：每种语言只声明 2 个 `@font-face`（Regular + ExtraBold/Bold）

---

## 字体标注规范

- **每个承载文本的标签**都必须用内联 `style` 独立标注 `font-family`，禁止依赖继承
- **禁止使用**：`font-bold`、`font-normal`、`font-weight: 700` 等 Tailwind 默认类或内联字重
- 字重名称严格来自 `language_font.md` 映射表

---

## 文案换行规范（`<br>` 使用铁律）

- `<br>` 前后必须为**相同语种字符**，严禁跨语种断行。
- **禁止出现长短句**：断行后相邻各行的字符数应保持视觉均衡，严禁悬殊对比（如一行 14 字、下一行仅 4 字）。如出现长短句，必须重新组织文案或调整断行位置。
