---
title: "scale_16x9"
type: "reference"
---


<!DOCTYPE html>
<html lang="zh-CN">
<head>
<style>
  html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
    box-sizing: border-box;
  }
  * {
    box-sizing: border-box;
  }
</style>

  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PE 平口袋详情页</title>
  <style>
    @font-face {
      font-family: 'AlibabaPuHuiTi_2_55_Regular';
      src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-55%20Regular.ttf') format('truetype');
    }
    @font-face {
      font-family: 'AlibabaPuHuiTi_2_95_ExtraBold';
      src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-95%20ExtraBold.ttf') format('truetype');
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'AlibabaPuHuiTi_2_55_Regular', 'PingFang SC', 'Microsoft YaHei', sans-serif;
      background: #f5f5f5;
    }
  </style>
</head>
<body>
<div class="poster-container" data-name="详情页容器" style="width:1200px; margin:0 auto; background:#fff;">

  <!-- ===== Section 1: 首屏主视觉 ===== -->
  <div data-name="首屏主视觉" style="position:relative; width:1200px; height:675px; overflow:hidden;">
    <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/be6b1977-a63e-43d7-83f6-e0aa3f1200a6.png"
         data-name="首屏背景图"
         style="width:100%; height:100%; object-fit:cover; display:block;" />
    <!-- 左侧文案遮罩 -->
    <div data-name="首屏文案区" style="position:absolute; top:0; left:0; width:55%; height:100%; background:linear-gradient(to right, rgba(255,255,255,0.97) 70%, rgba(255,255,255,0)); display:flex; flex-direction:column; justify-content:center; padding:0 72px;">
      <div data-name="品类标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:3px; color:#555; margin-bottom:28px;">PE 平口袋</div>
      <h1 data-name="主标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.15; color:#111; margin-bottom:20px;">
        透明如镜<br/>坚韧如铁
      </h1>
      <p data-name="副标题" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#555; line-height:1.7; margin-bottom:36px;">
        高透明 PE 平口袋，适用食品、五金、<br/>文件、电器等多场景收纳包装
      </p>
      <div data-name="三项亮点" style="display:flex; gap:32px;">
        <div data-name="亮点1" style="text-align:center;">
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; color:#111;">高透</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888; margin-top:4px;">晶莹透亮</div>
        </div>
        <div style="width:1px; background:#ddd;"></div>
        <div data-name="亮点2" style="text-align:center;">
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; color:#111;">耐用</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888; margin-top:4px;">抗撕防破</div>
        </div>
        <div style="width:1px; background:#ddd;"></div>
        <div data-name="亮点3" style="text-align:center;">
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; color:#111;">多规</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888; margin-top:4px;">尺寸齐全</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== Section 2: 卖点1 — 超高透明度（图文分离） ===== -->
  <div data-name="卖点1-超高透明度" style="width:1200px; height:675px; display:flex; align-items:center; background:#fff; padding:0 72px; gap:64px;">
    <div data-name="卖点1-文案" style="flex:1; display:flex; flex-direction:column; justify-content:center;">
      <div data-name="徽章标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:2px; color:#111; margin-bottom:24px;">超高透明度</div>
      <h2 data-name="卖点标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        晶莹剔透<br/>内容一目了然
      </h2>
      <p data-name="卖点描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#666; line-height:1.8; margin-bottom:36px;">
        采用优质 PE 原料，透光率高达 90% 以上，袋内物品清晰可见，无需开袋即可快速识别内容物，大幅提升仓储分拣与日常收纳效率。
      </p>
      <div data-name="数据项" style="display:flex; gap:48px;">
        <div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:56px; color:#111;">90<span style="font-size:16px;">%+</span></div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; margin-top:4px;">透光率</div>
        </div>
        <div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:56px; color:#111;">0<span style="font-size:16px;">雾化</span></div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; margin-top:4px;">无雾面处理</div>
        </div>
      </div>
    </div>
    <div data-name="卖点1-图片" style="width:480px; height:480px; border-radius:29px; overflow:hidden; flex-shrink:0;">
      <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/d2588cbc-f4e8-42b6-933b-146f2b6d98c7.png"
           data-name="透明度展示图"
           style="width:100%; height:100%; object-fit:cover;" />
    </div>
  </div>

  <!-- ===== Section 3: 卖点2 — 耐用防撕裂（图文分离） ===== -->
  <div data-name="卖点2-耐用防撕裂" style="width:1200px; height:675px; display:flex; align-items:center; background:#f8f8f8; padding:0 72px; gap:64px;">
    <div data-name="卖点2-图片" style="width:480px; height:480px; border-radius:29px; overflow:hidden; flex-shrink:0;">
      <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/6874d270-7653-4511-af76-551f0137d005.png"
           data-name="耐用展示图"
           style="width:100%; height:100%; object-fit:cover;" />
    </div>
    <div data-name="卖点2-文案" style="flex:1; display:flex; flex-direction:column; justify-content:center;">
      <div data-name="徽章标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:2px; color:#111; margin-bottom:24px;">耐用防撕裂</div>
      <h2 data-name="卖点标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        强韧材质<br/>承重不变形
      </h2>
      <p data-name="卖点描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#666; line-height:1.8; margin-bottom:36px;">
        经过特殊工艺处理的 PE 薄膜，具备优异的抗拉伸与抗撕裂性能，装载重物时不易破损，封口处热合牢固，确保内容物安全无忧。
      </p>
      <div data-name="数据项" style="display:flex; gap:48px;">
        <div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:56px; color:#111;">5<span style="font-size:16px;">kg+</span></div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; margin-top:4px;">承重能力</div>
        </div>
        <div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:56px; color:#111;">3<span style="font-size:16px;">丝+</span></div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; margin-top:4px;">膜厚可选</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ===== Section 4: 卖点3 — 多场景适用（图片叠底） ===== -->
  <div data-name="卖点3-多场景适用" style="position:relative; width:1200px; height:675px; overflow:hidden;">
    <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/8df06aad-f7a1-4b4d-9bbd-a167ed558ab5.png"
         data-name="多场景背景图"
         style="width:100%; height:100%; object-fit:cover; display:block;" />
    <div data-name="多场景文案" style="position:absolute; top:0; left:0; width:52%; height:100%; background:linear-gradient(to right, rgba(255,255,255,0.95) 65%, rgba(255,255,255,0)); display:flex; flex-direction:column; justify-content:center; padding:0 72px;">
      <div data-name="徽章标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:2px; color:#fff; margin-bottom:24px;">多场景适用</div>
      <h2 data-name="卖点标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        六大场景<br/>一袋全搞定
      </h2>
      <p data-name="卖点描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#555; line-height:1.8;">
        干货包装、食品收纳、五谷杂粮、文件整理、五金收纳、电器包装，全面覆盖家庭与商业使用场景，一款产品满足多种需求。
      </p>
      <div data-name="场景标签组" style="display:flex; flex-wrap:wrap; gap:10px; margin-top:28px;">
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">干货包装</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">食品包装</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">五谷杂粮</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">文件整理</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">五金收纳</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">电器包装</span>
      </div>
    </div>
  </div>

  <!-- ===== Section 5: 卖点4 — 环保材质（图文分离） ===== -->
  <div data-name="卖点4-环保材质" style="width:1200px; height:675px; display:flex; align-items:center; background:#fff; padding:0 72px; gap:64px;">
    <div data-name="卖点4-文案" style="flex:1; display:flex; flex-direction:column; justify-content:center;">
      <div data-name="徽章标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:2px; color:#2d7a3a; margin-bottom:24px;">环保材质</div>
      <h2 data-name="卖点标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        安全无毒<br/>可回收再利用
      </h2>
      <p data-name="卖点描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#666; line-height:1.8; margin-bottom:36px;">
        采用符合国家食品级标准的 PE 原料，无毒无味，安全可靠。材料可回收再利用，减少环境负担，兼顾实用性与可持续发展理念。
      </p>
      <div data-name="认证标签" style="display:flex; gap:16px;">
        <div style="color:#2d7a3a; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">食品级安全</div>
        <div style="color:#2d7a3a; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">无毒无味</div>
        <div style="color:#2d7a3a; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px;">可回收材质</div>
      </div>
    </div>
    <div data-name="卖点4-图片" style="width:480px; height:480px; border-radius:29px; overflow:hidden; flex-shrink:0;">
      <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/807348ab-a29e-4099-b992-48eff00e00cd.png"
           data-name="环保展示图"
           style="width:100%; height:100%; object-fit:cover;" />
    </div>
  </div>

  <!-- ===== Section 6: 卖点5 — 规格齐全（图文分离） ===== -->
  <div data-name="卖点5-规格齐全" style="width:1200px; height:675px; display:flex; align-items:center; background:#f8f8f8; padding:0 72px; gap:64px;">
    <div data-name="卖点5-图片" style="width:480px; height:480px; border-radius:29px; overflow:hidden; flex-shrink:0;">
      <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/fd252737-96b3-4f1f-a164-a3019243ed9f.png"
           data-name="规格展示图"
           style="width:100%; height:100%; object-fit:cover;" />
    </div>
    <div data-name="卖点5-文案" style="flex:1; display:flex; flex-direction:column; justify-content:center;">
      <div data-name="徽章标签" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; letter-spacing:2px; color:#111; margin-bottom:24px;">规格齐全</div>
      <h2 data-name="卖点标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        多种尺寸<br/>按需灵活选配
      </h2>
      <p data-name="卖点描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#666; line-height:1.8; margin-bottom:36px;">
        提供从小号到超大号的完整尺寸系列，厚度可选 2 丝至 8 丝，满足不同重量与体积的包装需求，支持批量定制，适合个人及企业采购。
      </p>
      <div data-name="尺寸标签组" style="display:flex; flex-wrap:wrap; gap:10px;">
        <span style="color:#111; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; font-weight:bold;">小号</span>
        <span style="color:#333; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; font-weight:bold;">中号</span>
        <span style="color:#555; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; font-weight:bold;">大号</span>
        <span style="color:#777; font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; font-weight:bold;">超大号</span>
      </div>
    </div>
  </div>

  <!-- ===== Section 7: 详细规格参数表（图文分离） ===== -->
  <div data-name="规格参数表" style="width:1200px; height:675px; display:flex; align-items:center; background:#fff; padding:0 72px; gap:64px;">
    <div data-name="参数图" style="width:420px; height:420px; border-radius:29px; overflow:hidden; flex-shrink:0;">
      <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/568c980e-9e0d-4d9d-aba2-d573f308deb1.png"
           data-name="规格参数图"
           style="width:100%; height:100%; object-fit:cover;" />
    </div>
    <div data-name="参数文案" style="flex:1;">
      <div data-name="参数标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; color:#111; margin-bottom:32px;">产品规格参数</div>
      <table data-name="参数表格" style="width:100%; border-collapse:collapse;">
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0; width:40%;">产品名称</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">PE 平口袋（透明塑料袋）</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">材质</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">聚乙烯（PE）</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">厚度规格</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">2 丝 / 3 丝 / 4 丝 / 5 丝 / 6 丝 / 8 丝</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">尺寸范围</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">5×8 cm — 80×120 cm（支持定制）</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">颜色</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">透明（可定制磨砂/彩色）</td>
        </tr>
        <tr style="border-bottom:1px solid #eee;">
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">包装形式</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">卷装（100 只 / 卷）</td>
        </tr>
        <tr>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#999; padding:14px 0;">适用场景</td>
          <td style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#222; padding:14px 0;">食品、五金、文件、电器、服装等</td>
        </tr>
      </table>
      <p data-name="备注" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#bbb; margin-top:20px;">* 支持 OEM 定制，可印刷 LOGO，欢迎企业批量采购</p>
    </div>
  </div>

  <!-- ===== Section 8: 使用场景图（图片叠底） ===== -->
  <div data-name="使用场景图" style="position:relative; width:1200px; height:675px; overflow:hidden;">
    <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/e3017a18-cdab-4a58-9ffe-492287fad630.png"
         data-name="场景背景图"
         style="width:100%; height:100%; object-fit:cover; display:block;" />
    <div data-name="场景文案" style="position:absolute; top:0; left:0; width:50%; height:100%; background:linear-gradient(to right, rgba(255,255,255,0.95) 65%, rgba(255,255,255,0)); display:flex; flex-direction:column; justify-content:center; padding:0 72px;">
      <div data-name="场景标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; line-height:1.2; color:#111; margin-bottom:20px;">
        随手一撕<br/>即取即用
      </h2>
      <p data-name="场景描述" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#555; line-height:1.8;">
        卷装设计，连续撕取无需剪刀，家庭、仓库、超市、工厂均可轻松使用，大幅提升包装效率，告别繁琐操作。
      </p>
    </div>
  </div>

  <!-- ===== Section 9: 售后保障（图片叠底） ===== -->
  <div data-name="售后保障" style="position:relative; width:1200px; height:675px; overflow:hidden; background:#111;">
    <img src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-08/d8b36fc0-7109-42bc-96a0-45ca3a5988ed.png"
         data-name="保障背景图"
         style="width:100%; height:100%; object-fit:cover; display:block; opacity:0.25;" />
    <div data-name="保障文案" style="position:absolute; top:0; left:0; width:100%; height:100%; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:0 72px;">
      <div data-name="信任标题" style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:48px; color:#fff; margin-bottom:16px; text-align:center;">我们的承诺</div>
      <div data-name="副标题" style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:18px; color:#aaa; margin-bottom:64px; text-align:center; letter-spacing:2px;">品质保障 · 放心购买</div>
      <div data-name="保障项目" style="display:flex; gap:80px; justify-content:center;">
        <div data-name="保障1" style="text-align:center;">
          <div style="width:64px; height:64px; border-radius:50%; background:rgba(255,255,255,0.08); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:18px; color:#fff; margin-bottom:8px;">品质保证</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888;">严格质检，出厂合格</div>
        </div>
        <div data-name="保障2" style="text-align:center;">
          <div style="width:64px; height:64px; border-radius:50%; background:rgba(255,255,255,0.08); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
          </div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:18px; color:#fff; margin-bottom:8px;">极速发货</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888;">当日下单，次日发出</div>
        </div>
        <div data-name="保障3" style="text-align:center;">
          <div style="width:64px; height:64px; border-radius:50%; background:rgba(255,255,255,0.08); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
          </div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:18px; color:#fff; margin-bottom:8px;">无忧退换</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888;">7 天无理由退换货</div>
        </div>
        <div data-name="保障4" style="text-align:center;">
          <div style="width:64px; height:64px; border-radius:50%; background:rgba(255,255,255,0.08); display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:18px; color:#fff; margin-bottom:8px;">专属客服</div>
          <div style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:16px; color:#888;">1 对 1 售前售后服务</div>
        </div>
      </div>
    </div>
  </div>

</div>
</body>
</html>