---
title: "section-size-map"
type: "reference"
---

# Section 尺寸映射 与 模式判定

> 每个 Section 的固定尺寸与模式归属，均由此文件强制规定。不得随意偏离。

---

## 模式 A/B 速查表

| 特征 | 模式 A（图文分离） | 模式 B（图片叠底） |
|------|-------------------|-------------------|
| **布局** | 16:9/4:3→`flex-direction:row` 左右分栏；1:1→`flex-direction:column` 上下分栏 | `position:relative` + 图片 `absolute inset:0` |
| **图片尺寸** | 强制 1:1 正方形 | 100% 全屏铺满 |
| **object-fit** | `contain`（强制） | `cover`（仅全屏背景图） |
| **渐变蒙层** | 严禁 | 必须（5-6 色标点多段渐变） |
| **图片容器** | 内联 `width:560px; height:560px; aspect-ratio:1/1; flex-shrink:0` | 无固定容器，`absolute inset-0 w-full h-full` |
| **文字背景** | 纯色 / 继承 Section 背景 | 透明，叠在图片上 |
| **决定来源** | 模板库/卖点库标注「图文分离模式」 | 模板库/卖点库标注「图片叠底模式」 |

**判定决策树**：
```
读取模板库/卖点库模块的【布局说明】标签
│
├── "图文分离模式" → 模式 A（加载 mode-a-split.md）
│
└── "图片叠底模式" → 模式 B（加载 mode-b-overlay.md）
```

**杂交禁令**：严禁出现"半屏 absolute 图片 + 半屏文字 + 交界渐变"。每个 Section 必须严格归属 A 或 B 中的一种。

---

## Section 尺寸统一铁律（最高优先级）

### 映射表

| 终端 | 画布比例 | 排版方向 | Section 固定尺寸（宽×高） |
|------|---------|---------|------------------------|
| 桌面端 | 16:9 | **横向**（宽>高） | **1200 × 675** |
| 手机端 | 4:3 | **横向**（宽>高） | **790 × 592.5** |
| 方形 | 1:1 | 正方形（宽=高） | **800 × 800** |

> ⚠️ **横向排版铁律（最高优先级）**：无论是手机端还是桌面端，**所有 Section 都是横向排版（宽度 > 高度）**。严禁将手机端理解为竖屏/纵向/portrait（高度 > 宽度）。4:3 指的是画布宽高比，**宽 790 > 高 592.5**，不是竖屏 3:4。

### 强制声明规则

1. **每个 Section 必须在内联 `style` 中显式声明 `width` 和 `height`**，不可省略、不可用 `auto`/`100%`/`calc()` 替代
2. **同页所有 Section 必须使用完全相同的宽高值**，禁止混合尺寸
3. **顶层容器宽度必须等于 Section 宽度**
4. **禁止在 `<style>` 中定义任何控制尺寸的选择器**（如 `.section { height: ... }`）

### 严禁写法

```html
<!-- 错误 1：Section 使用任意高度 -->
<div style="width: 750px; height: 900px;">  ❌ 高度必须是映射表中的值

<!-- 错误 2：顶层容器宽度与 Section 不一致 -->
<div style="width: 750px;">  ❌ 4:3 应为 790px
  <div style="width: 790px; height: 592.5px;">

<!-- 错误 3：用 CSS 类控制尺寸 -->
<style>.section { height: 800px; }</style>  ❌ 严禁

<!-- 错误 4：省略高度，依赖内容撑开 -->
<div style="width: 790px;">  ❌ 缺少 height
```

### 正确写法

```html
<!-- 正确：16:9 桌面端 -->
<div style="width: 1200px; height: 675px; ...">Section 1</div>
<div style="width: 1200px; height: 675px; ...">Section 2</div>

<!-- 正确：4:3 手机端 -->
<div style="width: 790px; height: 592.5px; ...">Section 1</div>
<div style="width: 790px; height: 592.5px; ...">Section 2</div>

<!-- 正确：1:1 方形 -->
<div style="width: 800px; height: 800px; ...">Section 1</div>
<div style="width: 800px; height: 800px; ...">Section 2</div>
```
