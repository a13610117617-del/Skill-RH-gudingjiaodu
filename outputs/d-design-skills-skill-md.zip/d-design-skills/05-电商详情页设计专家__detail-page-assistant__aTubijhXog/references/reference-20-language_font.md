---
title: "language_font"
type: "reference"
---

# 语种映射表

## en-us（English）
- **字体选择**：Inter
    - **字重1**：Inter-Regular 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Regular.ttf'
    - **字重2**：Inter-Bold 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Bold.ttf'

## zh-cn（中文简体）
- **字体选择**：Alibaba PuHuiTi 2.0
    - **字重1**：AlibabaPuHuiTi_2_55_Regular（正文）
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-55%20Regular.ttf'
    - **字重2**：AlibabaPuHuiTi_2_95_ExtraBold（标题）
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-95%20ExtraBold.ttf'

## ja-jp（日本語）
- **字体选择**：Noto Sans JP 
    - **字重1**：NotoSansJP-Regular  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/NotoSansJP-Regular.ttf'
    - **字重2**：NotoSansJP-Bold  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/NotoSansJP-Bold.ttf'

## ko-kr（한국어）
- **字体选择**：Pretendard 
    - **字重1**：Pretendard-Regular  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/Pretendard-Regular.otf'
    - **字重2**：Pretendard-Bold  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/Pretendard-Bold.otf'

## th-th（ภาษาไทย）
- **字体选择**：Noto Sans Thai 
    - **字重1**：NotoSansThai-Regular  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/NotoSansThai-Regular.ttf'
    - **字重2**：NotoSansThai-Bold  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/NotoSansThai-Bold.ttf'

## vi-vn（Tiếng Việt）
- **字体选择**：Oktah Round 
    - **字重1**：OktahRound-Lt  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/oktah_round_light-BF6407f0ed773d3.otf'
    - **字重2**：OktahRound-BdIt  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/oktah_round_bold_italic-BF6407f0ed72273.otf'

## tr-tr（Türkçe）
- **字体选择**：PT Sans
    - **字重1**：PTSans-Regular  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/PT_Sans-Web-Regular.ttf'
    - **字重2**：PTSans-Bold  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/PT_Sans-Web-Bold.ttf'

## ru-ru（Русский）
- **字体选择**：Gilroy 
    - **字重1**：Gilroy-Regular  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/Gilroy-Regular.otf'
    - **字重2**：Gilroy-Bold  
        - **src**：'https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/Gilroy-Bold.otf'

## fr-fr（Français）
- **字体选择**：Inter
    - **字重1**：Inter-Regular 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Regular.ttf'
    - **字重2**：Inter-Bold 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Bold.ttf'

## es-es（Español）
- **字体选择**：Inter
    - **字重1**：Inter-Regular 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Regular.ttf'
    - **字重2**：Inter-Bold 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Bold.ttf'

## pt-br（Português Brasil）
- **字体选择**：Inter
    - **字重1**：Inter-Regular 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Regular.ttf'
    - **字重2**：Inter-Bold 
        - **src**：'https://next-ubanner.oss-cn-beijing.aliyuncs.com/ALIWOOD_TEMPLATE/online-resource/inter/Inter-Bold.ttf'