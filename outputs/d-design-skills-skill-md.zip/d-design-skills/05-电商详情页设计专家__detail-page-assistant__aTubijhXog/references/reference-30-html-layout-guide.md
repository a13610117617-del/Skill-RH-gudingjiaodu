---
title: "html-layout-guide"
type: "reference"
---

# HTML 排版总规范（Step 5 入口）

> 本文件是生成详情页 HTML 时的唯一入口。按下方"阅读顺序"依次加载子文件，不得跳读。

---

## 阅读顺序（必须按序加载）

1. 先读本文件（全局铁律 + 骨架 + 图片/文字/间距/Emoji 规范）
2. 加载 `references/section-size-map.md`（Section 尺寸 + 模式判定）
3. 根据 Section 模式分别加载：
   - 【图文分离模式】→ `references/mode-a-split.md`
   - 【图片叠底模式】→ `references/mode-b-overlay.md`
4. 加载 `references/font-spec.md`（字体选择 + 字重铁律 + `<br>` 换行规范）；**字号从当前匹配模板的"字号规范"表中读取，按画布比例选 16:9 或 4:3 列**；徽章标签纯文字铁律见本文件"文字背景与色块规范"小节
5. 输出前对照 `references/self-check.md` 逐项自查

---

## 参考案例（最高优先级）

生成 HTML 前必须先阅读对应画布比例的标准案例文件，以其 HTML 结构、Section 写法、图片容器写法为直接模仿对象：

| 画布比例 | 必读参考文件 |
|---------|------------|
| 16:9 | `references/案例/scale_16x9.html` |
| 4:3 | `references/案例/scale_4x3.html` |

**模仿重点**：图文分离 Section 的图片容器写法（`width`/`height`/`object-fit`）、叠底 Section 的渐变蒙层写法、徽章标签纯文字写法、**全部内联 `style` 的样式写法**。

### 参考案例内容隔离铁律

参考案例文件中的商品文案、配色 HEX 值、具体 Section 主题（如"沉浸式游戏体验""萌趣卡通"等）与品牌标识**严禁出现在最终输出中**。最终 HTML 必须完全使用本次商品的真实信息。若发现最终 HTML 中存在与参考案例完全相同的句子或 HEX 值，视为严重违规。

---

## 全局铁律（8 条）

1. **Section 尺寸统一**：同页所有 Section 使用完全相同的固定宽高。映射见 `section-size-map.md`（16:9→1200×675，4:3→790×592.5，1:1→800×800）。数值在每个 Section 的内联 `style` 中以 `width: XXXpx; height: XXXpx` 显式声明。**顶层容器 `width` 必须等于 Section `width`**。严禁使用 `<section>` 标签，全部使用 `<div>`
   - ⚠️ **横向排版铁律（最高优先级）**：无论用户选择"手机端"还是"桌面端"，**所有 Section 都是横向排版（宽度 > 高度）**。"手机端"仅表示画布比例用 4:3（790×592.5），**绝不意味着竖屏/纵向/portrait（高度 > 宽度）**。严禁让 Section 高度超过宽度
2. **图片来源必须 Nano2**：`<img>` 的 `src` 严禁使用用户原图 URL，必须是 Nano2 生成图
3. **文字背景禁令**：严禁色块/半透明底（`bg-white/80`、`backdrop-blur` 等），仅允许渐变蒙层，且蒙层仅用于模式 B
4. **字体显式标注**：每个承载文本的标签必须用内联 `style` 独立标注 `font-family`，禁止依赖继承
5. **静态页面**：禁止任何 CSS/JS 动效
6. **全部内联样式（最高优先级）**：所有样式必须使用内联 `style="..."`，**严禁在 `<style>` 中定义任何 CSS 类**（包括但不限于 `.section`、`.split`、`.overlay`、`.data-grid`、`.poster-container`、`.hero`、`.badge`、`.tag`、`.label`、`.chip`、`.feature`、`.warranty`、`.spec`、`.mood`、`.scene`、`.brand`、`.divider` 等，**无论名称是什么，一律禁止**），**严禁定义 ID 选择器**（如 `#s1`），**严禁定义标签选择器**（如 `section { ... }`、`div { ... }`），**严禁使用 CSS 变量**（如 `:root { --xxx }`、`var(--xxx)`），**严禁 `<link>` 引入外部 CSS**，**严禁 `<style>` 中出现任何 `{` 除了 `html, body { reset }` 和 `@font-face { ... }`**
7. **禁止使用语义化 HTML 标签**：Section 必须使用 `<div>`，**严禁使用 `<section>`、`<article>`、`<main>` 等语义标签**
8. **自检方法（生成后立即执行）**：全局搜索 `<style>` 标签内容，确认除 `html, body` reset 和 `@font-face` 外不含任何 `{`；全局搜索 `class=` 确认值为空或不存在；全局搜索 `section style` 确认所有 Section 的 `width`/`height` 与 `section-size-map.md` 完全一致

---

## HTML 结构骨架

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>商品详情页</title>
    <style>
      html, body { margin: 0; padding: 0; }
      @font-face {
        font-family: 'AlibabaPuHuiTi_2_55_Regular';
        src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/阿里巴巴芭芭...Regular.ttf') format('truetype');
      }
      @font-face {
        font-family: 'AlibabaPuHuiTi_2_95_ExtraBold';
        src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/阿里巴巴芭芭...ExtraBold.ttf') format('truetype');
      }
    </style>
</head>
<body>
    <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; margin: 0 auto; width: 1200px;">
        <!-- Section 1 -->
        <div data-name="首屏主视觉" style="width: 1200px; height: 675px; ...">...</div>
        <!-- Section 2 -->
        <div data-name="卖点1" style="width: 1200px; height: 675px; ...">...</div>
        <!-- Section N -->
        <div data-name="售后保障" style="width: 1200px; height: 675px; ...">...</div>
    </div>
</body>
</html>
```

**关键要求**：
- `<style>` 必须放在 `<head>` 内，**仅允许** `html, body` reset + `@font-face` 字体声明，**不得有任何其他 `{` 出现**
- **禁止在 `<style>` 中定义任何 CSS 类、ID 选择器、标签选择器、CSS 变量**
- 每个 Section 必须使用 `<div>` 标签（**严禁 `<section>`**），所有样式（含 `width`/`height`/`display`/`background`/`position` 等）全部写在内联 `style` 中
- 所有标签必须正确闭合

---

## 图片元素规范

| 规则 | 要求 |
|------|------|
| 1:1 对应 | `<img>` 数量、用途必须与 Recipe 严格 1:1 对应，禁止自行添加 Logo、二维码、装饰图 |
| 图片来源铁律 | 所有 Section 必须使用 Nano2 生成的背景图；用户原图仅允许作为 Nano2 生图参考，最终页面禁止直用 |
| 占位图 | 必须使用 `https://placehold.co/宽x高` 灰色占位图 |
| 比例匹配 | 占位图宽高比必须严格匹配 Recipe 中的 `size` 字段 |
| 数据绑定 | 必须添加 `data-image-id` 属性，对应 Recipe 中图片 ID |
| `object-fit` 规则 | 见下方「object-fit 选择决策树」 |

**裁切防护铁律**：任何"产品整体展示""尺寸规格图""细节特写"类 `<img>` 只要使用 `object-fit: cover`，即视为违规。

---

## object-fit 选择决策树

```
这个 <img> 图片的用途是什么？
│
├── 充当模式 B 的整屏氛围背景图（absolute inset-0 全屏铺满）
│   └── → 使用 object-fit: cover（唯一允许 cover 的场景）
│
├── 产品整体展示 / 尺寸规格图 / 细节特写 / 场景图+产品主体
│   └── → 使用 object-fit: contain（强制，无论模式 A 或 B）
│
├── 模式 A Section 中的任何 <img>
│   └── → 使用 object-fit: contain（强制）
│
├── 图片容器宽高比 ≠ 1:1 且用于展示产品
│   └── → 使用 object-fit: contain（强制）
│
└── 不确定
    └── → 优先使用 object-fit: contain（更安全）
```

---

## 文字背景与色块规范（全局）

- 严禁为文字添加纯色/半透明色块背景框（如 `bg-white/80`、`bg-black/50`、`backdrop-blur`、`rounded` 色块容器）
- 严禁为文字添加任何形式的几何线框（包括但不限于 `border`、`outline`、`box-shadow` 描边、伪元素 `::before/::after` 绘制的矩形/菱形/圆角框）
- 唯一允许：CSS 渐变蒙层，且必须作用于图片父容器（仅模式 B），而非文字容器

### 徽章标签纯文字铁律

模板/卖点 Section 中的"徽章标签"（如卖点名称标签、品类标签、场景标签等）**必须是纯文字**：

- **禁止**：背景色（`background`、`background-color`）、填充内边距（`padding`）、边框（`border`）、圆角（`border-radius`）、色块容器
- **允许**：仅通过 `font-size`、`font-weight`、`color`、`letter-spacing`、`margin` 控制视觉层级
- 正确写法：`<span style="font-size:16px; letter-spacing:2px; color:#888; margin-bottom:24px;">超高透明度</span>`
- 禁止写法：`<span style="background:#111; padding:5px 14px; border-radius:4px;">超高透明度</span>`
- 禁止写法：`<span style="border:1.5px solid #111; padding:5px 14px;">超高透明度</span>`

---

## 间距与容器规范

- **Section 安全区**：固定宽高 + 高额 Padding（如 `padding: 60px 80px`）
- **顶层容器**：必须设 `margin: 0 auto`
- **body 背景**：必须为 `#ffffff` 或 `transparent`

---

## 其他规范

- **Emoji 清零**：严禁在 HTML 中使用任何 Emoji 字符或 Unicode 图标符号。若需视觉标识，必须使用 CSS 几何图形（圆形、菱形、线条）或纯色图标字体
- **静态页面**：严禁任何 CSS/JS 动效

---

## 一次性生成约束

将全局设计规范与所有 Section 内容**一次性拼接传入模型**，生成包含所有 Section 的**单个完整 HTML 文件**（使用占位图）。

- 禁止分批/循环调用，无论 Section 数量多少，必须一次响应完成
- Section 数量必须与 Step 3 规划完全一致，严禁遗漏
- 生成完成后必须按 `self-check.md` 自查
