---
title: "scale_4x3"
type: "reference"
---

<!DOCTYPE html>
<html lang="zh-CN">
<head>
<style>
  html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    min-height: 100%;
    box-sizing: border-box;
  }
  * {
    box-sizing: border-box;
  }
</style>

  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>北欧单人沙发椅详情页</title>
  <style>
    html, body { margin: 0; padding: 0; background: #ffffff; }
    * { box-sizing: border-box; }
    @font-face {
      font-family: 'AlibabaPuHuiTi_2_55_Regular';
      src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-55%20Regular.ttf') format('truetype');
    }
    @font-face {
      font-family: 'AlibabaPuHuiTi_2_95_ExtraBold';
      src: url('https://pages-content.oss-accelerate.aliyuncs.com/pic-fonts/%E9%98%BF%E9%87%8C%E5%B7%B4%E5%B7%B4%E6%99%AE%E6%83%A0%E4%BD%93%202.0-95%20ExtraBold.ttf') format('truetype');
    }
  </style>
</head>
<body>
<div data-name="详情页容器" style="width: 790px; margin: 0 auto; font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; background: #ffffff;">

  <!-- Section 1: 首屏主视觉（图片叠底模式） -->
  <div data-name="首屏主视觉" style="width: 790px; height: 592px; position: relative; overflow: hidden; background: #2c3a2e;">
    <img data-image-id="img_s1_bg" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/f46da2ce-4966-4073-b7b3-c4736302c89b.png?Expires=1778840179&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=VtmZMYLhPkC2h5gpl%2F16ok0PwUw%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="首屏主视觉" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to bottom, rgba(20,28,20,0.18) 0%, rgba(20,28,20,0.62) 60%, rgba(20,28,20,0.82) 100%);"></div>
    <div data-name="首屏文案" style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 56px 64px;">
      <span data-name="品类标签" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.2em; color: rgba(255,255,255,0.85); margin-bottom: 20px;">北欧单人沙发椅</span>
      <h1 data-name="主标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.1; color: #ffffff; margin: 0 0 18px 0; max-width: 560px;">慢下来<br>好好坐着</h1>
      <p data-name="副标题" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 18px; color: rgba(255,255,255,0.78); line-height: 1.7; max-width: 400px; margin: 0;">北欧简约设计 · 实木橡木腿 · 45D 高密度海绵<br>为每一个值得被好好对待的瞬间而生</p>
    </div>
    <div data-name="品牌标识" style="position: absolute; top: 48px; right: 56px; font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 18px; letter-spacing: 0.15em; color: rgba(255,255,255,0.75);">NORDIA HOME</div>
  </div>

  <!-- Section 2: 卖点 — 北欧简约设计（图文分离模式） -->
  <div data-name="卖点-北欧简约设计" style="width: 790px; height: 592px; display: flex; flex-direction: row; align-items: stretch; background: #faf8f4; overflow: hidden;">
    <!-- 文字区 -->
    <div data-name="文字区" style="flex: 0 0 50%; width: 50%; display: flex; flex-direction: column; justify-content: center; padding: 60px 52px;">
      <span data-name="徽章" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.18em; color: #7a6a52; margin-bottom: 22px;">北欧简约设计</span>
      <h2 data-name="卖点标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 18px 0;">线条纯粹<br>美学自成一格</h2>
      <p data-name="卖点描述" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; line-height: 1.85; color: #6b6b6b; max-width: 320px; margin: 0 0 32px 0;">源自北欧设计哲学，以克制的弧线勾勒椅背轮廓，宽阔的包裹式扶手提供自然支撑。每一条缝线都经过精准排布，简约而不简单，融入任何家居风格都毫不违和。</p>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div data-name="数据项1">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">3<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">色可选</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">多色系搭配</div>
        </div>
        <div data-name="数据项2">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">360<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">°</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">全角度美观</div>
        </div>
      </div>
    </div>
    <!-- 图片区 -->
    <div data-name="图片区" style="flex: 0 0 50%; width: 50%; display: flex; align-items: center; justify-content: center; padding: 44px;">
      <div style="width: 100%; aspect-ratio: 1/1; border-radius: 24px; overflow: hidden; background: #f0ece4; box-shadow: 0 24px 48px -16px rgba(0,0,0,0.12), 0 8px 20px -8px rgba(0,0,0,0.07);">
        <img data-image-id="img_s2_design" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/d14adb73-c0b8-4ba7-841b-48287b670263.png?Expires=1778840235&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=TV7vMkk9owdpWg1eC99WJquaGS8%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="北欧简约设计" style="width: 100%; height: 100%; object-fit: contain;" />
      </div>
    </div>
  </div>

  <!-- Section 3: 卖点 — 高密度海绵填充（图文分离模式，图左文右） -->
  <div data-name="卖点-高密度海绵" style="width: 790px; height: 592px; display: flex; flex-direction: row-reverse; align-items: stretch; background: #ffffff; overflow: hidden;">
    <!-- 文字区 -->
    <div data-name="文字区" style="flex: 0 0 50%; width: 50%; display: flex; flex-direction: column; justify-content: center; padding: 60px 52px;">
      <span data-name="徽章" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.18em; color: #3d6b42; margin-bottom: 22px;">高密度海绵填充</span>
      <h2 data-name="卖点标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 18px 0;">45D 高密度<br>坐感如云</h2>
      <p data-name="卖点描述" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; line-height: 1.85; color: #6b6b6b; max-width: 320px; margin: 0 0 32px 0;">采用 45D 高密度海绵，回弹力强，久坐不塌陷。坐垫与靠背分层填充，软硬适中，精准托住腰椎与背部曲线，让每一次落座都是对身体的温柔呵护。</p>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div data-name="数据项1">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">45<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">D</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">海绵密度</div>
        </div>
        <div data-name="数据项2">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">5<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">年</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">不变形承诺</div>
        </div>
      </div>
    </div>
    <!-- 图片区 -->
    <div data-name="图片区" style="flex: 0 0 50%; width: 50%; display: flex; align-items: center; justify-content: center; padding: 44px;">
      <div style="width: 100%; aspect-ratio: 1/1; border-radius: 24px; overflow: hidden; background: #f5f2ec; box-shadow: 0 24px 48px -16px rgba(0,0,0,0.12), 0 8px 20px -8px rgba(0,0,0,0.07);">
        <img data-image-id="img_s3_foam" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/5554823b-98d2-4752-9dcc-c7bca71cfccc.png?Expires=1778840298&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=MDzpAnYCRdjc6uZrNcp5tO%2B20kQ%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="高密度海绵" style="width: 100%; height: 100%; object-fit: contain;" />
      </div>
    </div>
  </div>

  <!-- Section 4: 卖点 — 实木橡木腿（图文分离模式） -->
  <div data-name="卖点-实木橡木腿" style="width: 790px; height: 592px; display: flex; flex-direction: row; align-items: stretch; background: #faf8f4; overflow: hidden;">
    <!-- 文字区 -->
    <div data-name="文字区" style="flex: 0 0 50%; width: 50%; display: flex; flex-direction: column; justify-content: center; padding: 60px 52px;">
      <span data-name="徽章" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.18em; color: #8a6a3a; margin-bottom: 22px;">实木橡木腿</span>
      <h2 data-name="卖点标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 18px 0;">原木纹理<br>自然生长的温度</h2>
      <p data-name="卖点描述" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; line-height: 1.85; color: #6b6b6b; max-width: 320px; margin: 0 0 32px 0;">精选北欧橡木原料，经过 60 天自然风干处理，保留木材天然纹理与温润质感。榫卯结构精密连接，承重稳固，每一条腿都是一件有温度的手工艺品。</p>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div data-name="数据项1">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">60<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">天</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">自然风干处理</div>
        </div>
        <div data-name="数据项2">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">200<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">kg</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">承重测试认证</div>
        </div>
      </div>
    </div>
    <!-- 图片区 -->
    <div data-name="图片区" style="flex: 0 0 50%; width: 50%; display: flex; align-items: center; justify-content: center; padding: 44px;">
      <div style="width: 100%; aspect-ratio: 1/1; border-radius: 24px; overflow: hidden; background: #f0ece4; box-shadow: 0 24px 48px -16px rgba(0,0,0,0.12), 0 8px 20px -8px rgba(0,0,0,0.07);">
        <img data-image-id="img_s4_oak" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/7e4d914f-4b77-4184-936f-9e46cf974be2.png?Expires=1778840363&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=6Tm2rPyXoOi5FK094QLt6DAXr8M%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="实木橡木腿" style="width: 100%; height: 100%; object-fit: contain;" />
      </div>
    </div>
  </div>

  <!-- Section 5: 卖点 — 墨绿皮革面料（图文分离模式，图左文右） -->
  <div data-name="卖点-皮革面料" style="width: 790px; height: 592px; display: flex; flex-direction: row-reverse; align-items: stretch; background: #ffffff; overflow: hidden;">
    <!-- 文字区 -->
    <div data-name="文字区" style="flex: 0 0 50%; width: 50%; display: flex; flex-direction: column; justify-content: center; padding: 60px 52px;">
      <span data-name="徽章" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.18em; color: #3a5c42; margin-bottom: 22px;">优质皮革面料</span>
      <h2 data-name="卖点标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 18px 0;">墨绿皮革<br>触感细腻如肌</h2>
      <p data-name="卖点描述" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; line-height: 1.85; color: #6b6b6b; max-width: 320px; margin: 0 0 32px 0;">精选优质头层皮革，经过多道工序鞣制处理，表面细腻柔滑，耐磨防污。墨绿色调沉稳内敛，与原木腿形成自然的色彩对话，彰显主人的生活品味与审美格调。</p>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div data-name="数据项1">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">A<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">级皮革</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">头层牛皮</div>
        </div>
        <div data-name="数据项2">
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 40px; color: #2c3a2e; line-height: 1;">8<span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: #aaa; margin-left: 4px;">道</span></div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; margin-top: 6px;">鞣制工序</div>
        </div>
      </div>
    </div>
    <!-- 图片区 -->
    <div data-name="图片区" style="flex: 0 0 50%; width: 50%; display: flex; align-items: center; justify-content: center; padding: 44px;">
      <div style="width: 100%; aspect-ratio: 1/1; border-radius: 24px; overflow: hidden; background: #e8ede9; box-shadow: 0 24px 48px -16px rgba(0,0,0,0.12), 0 8px 20px -8px rgba(0,0,0,0.07);">
        <img data-image-id="img_s5_leather" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/d14adb73-c0b8-4ba7-841b-48287b670263.png?Expires=1778840235&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=TV7vMkk9owdpWg1eC99WJquaGS8%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="皮革面料" style="width: 100%; height: 100%; object-fit: contain;" />
      </div>
    </div>
  </div>

  <!-- Section 6: 尺寸规格（图文分离模式） -->
  <div data-name="尺寸规格" style="width: 790px; height: 592px; display: flex; flex-direction: row; align-items: stretch; background: #faf8f4; overflow: hidden;">
    <div data-name="文字区" style="flex: 0 0 50%; width: 50%; display: flex; flex-direction: column; justify-content: center; padding: 60px 52px;">
      <span data-name="徽章" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.18em; color: #7a6a52; margin-bottom: 22px;">产品规格</span>
      <h2 data-name="规格标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 24px 0;">尺寸参数<br>精准适配您的空间</h2>
      <div style="display: flex; flex-direction: column; gap: 14px; margin-bottom: 28px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e8e2d8; padding-bottom: 12px;">
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #999;">整体宽度</span>
          <span style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 14px; color: #2c3a2e;">85 cm</span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e8e2d8; padding-bottom: 12px;">
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #999;">整体深度</span>
          <span style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 14px; color: #2c3a2e;">82 cm</span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e8e2d8; padding-bottom: 12px;">
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #999;">整体高度</span>
          <span style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 14px; color: #2c3a2e;">82 cm</span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e8e2d8; padding-bottom: 12px;">
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #999;">面料材质</span>
          <span style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 14px; color: #2c3a2e;">头层牛皮</span>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #999;">腿部材质</span>
          <span style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 14px; color: #2c3a2e;">实木橡木</span>
        </div>
      </div>
      <p style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #bbb; line-height: 1.6;">包装清单：沙发椅 x1 · 安装说明书 x1 · 安装工具 x1</p>
    </div>
    <div data-name="图片区" style="flex: 0 0 50%; width: 50%; display: flex; align-items: center; justify-content: center; padding: 44px;">
      <div style="width: 100%; aspect-ratio: 1/1; border-radius: 24px; overflow: hidden; background: #f5f2ec; box-shadow: 0 24px 48px -16px rgba(0,0,0,0.12), 0 8px 20px -8px rgba(0,0,0,0.07);">
        <img data-image-id="img_s6_size" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/75e51b70-b68b-48ac-834b-5afef99073db.png?Expires=1778840418&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=Ja%2BBsbcouRdNWgODPvvRCgvfxP8%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="尺寸规格" style="width: 100%; height: 100%; object-fit: contain;" />
      </div>
    </div>
  </div>

  <!-- Section 7: 生活场景使用图（图片叠底模式） -->
  <div data-name="生活场景" style="width: 790px; height: 592px; position: relative; overflow: hidden; background: #2c3a2e;">
    <img data-image-id="img_s7_lifestyle" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/8d218fb8-6706-4134-b0a4-0fd4f9e8455b.png?Expires=1778840480&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=c5GhI47yK18vs0vORMVI86Sa%2BP4%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="生活场景" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;" />
    <div style="position: absolute; inset: 0; background: linear-gradient(135deg, rgba(20,28,20,0.72) 0%, rgba(20,28,20,0.28) 50%, rgba(20,28,20,0.08) 100%);"></div>
    <div data-name="场景文案" style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: center; align-items: flex-start; padding: 64px 72px;">
      <span data-name="场景标签" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.2em; color: rgba(255,255,255,0.9); margin-bottom: 24px;">生活场景</span>
      <h2 data-name="场景标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.15; color: #ffffff; margin: 0 0 20px 0; max-width: 380px;">一把椅子<br>一段好时光</h2>
      <p data-name="场景描述" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: rgba(255,255,255,0.82); line-height: 1.75; max-width: 340px; margin: 0;">无论是清晨的一杯咖啡，还是傍晚的一本好书，这把椅子都能给你最温柔的陪伴。高密度海绵久坐不累，让每一个放松的瞬间都值得被珍藏。</p>
    </div>
  </div>

  <!-- Section 8: 空间搭配氛围图（图片叠底模式） -->
  <div data-name="空间搭配" style="width: 790px; height: 592px; position: relative; overflow: hidden; background: #1e2820;">
    <img data-image-id="img_s8_space" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/65f6086a-1949-4cab-b1e4-6a84ed0a01d8.png?Expires=1778840539&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=Dy7JdIetxuk9rCwok4tBR8iAESU%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="空间搭配" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(15,22,15,0.85) 0%, rgba(15,22,15,0.35) 50%, rgba(15,22,15,0.05) 100%);"></div>
    <div data-name="氛围文案" style="position: absolute; bottom: 0; left: 0; right: 0; display: flex; flex-direction: column; align-items: center; justify-content: flex-end; padding: 56px 64px; text-align: center;">
      <h2 data-name="意境金句" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.1; color: #ffffff; margin: 0 0 16px 0;">让家，成为<br>最美的风景</h2>
      <p data-name="品牌口号" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 18px; color: rgba(255,255,0.65); letter-spacing: 0.15em;">NORDIA HOME · 北欧家居美学</p>
    </div>
  </div>

  <!-- Section 9: 买家秀（图片叠底模式） -->
  <div data-name="买家秀" style="width: 790px; height: 592px; position: relative; overflow: hidden; background: #2a3528;">
    <img data-image-id="img_s9_review" src="https://industryai.oss-cn-beijing.aliyuncs.com/pre/ai/style-fusion/2026-05-14/4c25e79b-c31a-4700-829b-e30f0c3ca3e4.png?Expires=1778840597&OSSAccessKeyId=LTAI5tCv9DpB7gYic1oGsAyv&Signature=NrwxH3%2BGwHh1di1jOgsTvNJjQnQ%3D&x-oss-process=image%2Fresize%2Cw_1536%2Ch_1536%2Cm_lfit%2Climit_0%2Fformat%2Cpng#.png" alt="买家秀" style="position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;" />
    <div style="position: absolute; inset: 0; background: linear-gradient(to right, rgba(15,22,15,0.78) 0%, rgba(15,22,15,0.42) 45%, rgba(15,22,15,0.05) 100%);"></div>
    <div data-name="买家秀文案" style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: center; align-items: flex-start; padding: 64px 72px;">
      <span data-name="标签" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.2em; color: rgba(255,255,255,0.88); margin-bottom: 24px;">真实买家秀</span>
      <h2 data-name="买家秀标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.15; color: #ffffff; margin: 0 0 24px 0; max-width: 360px;">他们都爱上了<br>这把椅子</h2>
      <div style="display: flex; flex-direction: column; gap: 16px; max-width: 340px;">
        <div style="border-left: 3px solid rgba(255,255,255,0.5); padding-left: 16px;">
          <p style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: rgba(255,255,255,0.85); line-height: 1.7; margin: 0 0 6px 0;">"颜色太好看了，和我家的原木风格完美搭配，坐上去超级舒服！"</p>
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: rgba(255,255,255,0.5);">@小鹿同学 · 已购买 3 个月</span>
        </div>
        <div style="border-left: 3px solid rgba(255,255,255,0.5); padding-left: 16px;">
          <p style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 14px; color: rgba(255,255,255,0.85); line-height: 1.7; margin: 0 0 6px 0;">"做工很精细，皮革摸起来很舒服，橡木腿很稳，值得入手！"</p>
          <span style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: rgba(255,255,255,0.5);">@北欧风爱好者 · 已购买 6 个月</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Section 10: 售后保障（图片叠底模式） -->
  <div data-name="售后保障" style="width: 790px; height: 592px; position: relative; overflow: hidden; background: #f5f1ea;">
    <div style="position: absolute; inset: 0; background: linear-gradient(135deg, #f0ebe0 0%, #e8e0d0 50%, #f5f1ea 100%);"></div>
    <div data-name="保障文案" style="position: absolute; inset: 0; display: flex; flex-direction: column; justify-content: center; align-items: center; padding: 64px 72px; text-align: center;">
      <span data-name="保障标签" style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; letter-spacing: 0.2em; color: rgba(255,255,255,0.9); margin-bottom: 28px;">品质承诺</span>
      <h2 data-name="保障标题" style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 34px; line-height: 1.2; color: #1e1e1e; margin: 0 0 48px 0;">我们的承诺<br>您的安心</h2>
      <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 32px; width: 100%; max-width: 620px;">
        <div data-name="保障项1" style="display: flex; flex-direction: column; align-items: center; gap: 12px;">
          <div style="width: 48px; height: 48px; border-radius: 50%; background: #2c3a2e; display: flex; align-items: center; justify-content: center;">
            <div style="width: 20px; height: 20px; border: 2px solid #ffffff; border-radius: 50%;"></div>
          </div>
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 18px; color: #1e1e1e;">2 年质保</div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #888; line-height: 1.6;">整椅质量保障<br>非人为损坏免费维修</div>
        </div>
        <div data-name="保障项2" style="display: flex; flex-direction: column; align-items: center; gap: 12px;">
          <div style="width: 48px; height: 48px; border-radius: 50%; background: #2c3a2e; display: flex; align-items: center; justify-content: center;">
            <div style="width: 20px; height: 4px; background: #ffffff; border-radius: 2px;"></div>
          </div>
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 18px; color: #1e1e1e;">30 天退换</div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #888; line-height: 1.6;">无忧退换货<br>不满意全额退款</div>
        </div>
        <div data-name="保障项3" style="display: flex; flex-direction: column; align-items: center; gap: 12px;">
          <div style="width: 48px; height: 48px; border-radius: 50%; background: #2c3a2e; display: flex; align-items: center; justify-content: center;">
            <div style="width: 8px; height: 8px; background: #ffffff; border-radius: 50%;"></div>
          </div>
          <div style="font-family: 'AlibabaPuHuiTi_2_95_ExtraBold', sans-serif; font-size: 18px; color: #1e1e1e;">终身服务</div>
          <div style="font-family: 'AlibabaPuHuiTi_2_55_Regular', sans-serif; font-size: 12px; color: #888; line-height: 1.6;">专属客服团队<br>全程跟踪服务</div>
        </div>
      </div>
    </div>
  </div>

</div>
</body>
</html>
