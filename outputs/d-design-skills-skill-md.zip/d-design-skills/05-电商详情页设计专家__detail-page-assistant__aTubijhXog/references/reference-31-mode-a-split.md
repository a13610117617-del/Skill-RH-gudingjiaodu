---
title: "mode-a-split"
type: "reference"
---

# 模式 A：图文分离模式（Mode A - Split Layout）

> 适用条件：模板库/卖点库模块的**布局说明**标注为【图文分离模式】。
> 模式归属由模板库/卖点库决定，严禁模型自行切换。

---

## 布局规则（按画布比例决定）

| 画布比例 | 布局方向 | 说明 |
|---------|---------|------|
| 16:9 | 左右分栏 | 左文右图 / 左图右文交替 |
| 4:3 | 左右分栏 | 左文右图 / 左图右文交替 |
| 1:1 | 上下分栏 | 上文下图（禁止左右分栏） |

- **16:9 / 4:3 画布**：`display:flex; flex-direction:row`，Section 内文字区与图片区左右并排，交替使用 `flex-direction:row`（左文右图）与 `flex-direction:row-reverse`（左图右文）
- **1:1 画布**：`display:flex; flex-direction:column`，严禁使用左右分栏
- ⚠️ **横向排版铁律（最高优先级）**：4:3 画布对应"手机端"，但**必须使用 `flex-direction:row` 左右分栏**，严禁因"手机端"而切换为 `flex-direction:column` 上下分栏。4:3 只是画布比例，不改变横向排版方向

---

## 图片尺寸铁律（最高优先级）

**图片区域必须为严格 1:1 正方形**，这是模式 A 不可绕过的核心规则，所有画布比例统一。

| 画布比例 | Section 尺寸 | 图片区域尺寸（必须 1:1） |
|---------|-------------|----------------------|
| 16:9 | 1200×675 | **500×500**（或在 480-560 区间，宽高严格相等） |
| 4:3 | 790×592.5 | **在 50% 宽度容器内通过 `width:100%; aspect-ratio:1/1` 自适应** |
| 1:1 | 800×800 | **300×300**（或在 280-320 区间，宽高严格相等） |

---

## 图片容器尺寸约束（强制写死像素，内联 style）

### 16:9 左右分栏 — 正确写法

```html
<!-- 图片容器：内联写死 500×500 -->
<div style="width:500px; height:500px; aspect-ratio:1/1; flex-shrink:0; display:flex; align-items:center; justify-content:center; background:#f0ebe3;">
  <img src="..." style="width:100%; height:100%; object-fit:contain;">
</div>
```

### 4:3 左右分栏 — 正确写法

```html
<!-- 4:3 左右分栏容器 -->
<div style="width:790px; height:592.5px; display:flex; flex-direction:row; align-items:stretch; background:#fff; overflow:hidden;">
  <!-- 文字区：占一半 -->
  <div style="flex:0 0 50%; width:50%; display:flex; flex-direction:column; justify-content:center; padding:60px 52px;">
    ...
  </div>
  <!-- 图片区：占一半，图片容器 1:1 正方形 -->
  <div style="flex:0 0 50%; width:50%; display:flex; align-items:center; justify-content:center; padding:44px;">
    <div style="width:100%; aspect-ratio:1/1; border-radius:24px; overflow:hidden; background:#f0ece4;">
      <img src="..." style="width:100%; height:100%; object-fit:contain;">
    </div>
  </div>
</div>
```

**4:3 左右分栏铁律**：
- 文字区与图片区各占 50%（`flex:0 0 50%; width:50%`）
- 图片容器通过 `aspect-ratio:1/1` 保持严格 1:1 正方形（在 50% 宽度内最大化展示）
- 使用 `flex-direction:row`（左文右图）与 `flex-direction:row-reverse`（左图右文）交替

### 严禁的写法

```html
<!-- 错误 1：高度使用 100%（会随父容器变化失去 1:1） -->
<div style="width:500px; height:100%;">

<!-- 错误 2：仅设宽度、未设高度（高度会被内容撑开） -->
<div style="width:500px;">

<!-- 错误 3：使用 flex:1 让图片自适应（会破坏 1:1） -->
<div style="flex:1; height:100%;">

<!-- 错误 4：图片容器宽高不等（破坏正方形） -->
<div style="width:500px; height:340px;">

<!-- 错误 5：在 <style> 中定义 .img-side CSS 类 -->
<style>.img-side { width:500px; height:500px; }</style>
```

---

## 实现铁律（不可绕过）

### 1. 必须使用 Flex/Grid 布局

文字区与图片区必须是同级 flex/grid 子项，严禁使用 `position: absolute` 让图片做半屏背景图。

### 2. 图片容器规范

- 图片所在容器必须是独立 flex 子项，使用内联 `style` 声明
- 图片容器宽高必须严格相等，形成 1:1 正方形
- 必须同时设置 `aspect-ratio:1/1` 作为双重保险
- 必须设置 `flex-shrink:0` 防止被父容器压缩
- `<img>` 必须使用 `object-fit:contain` + `width:100%; height:100%`
- 严禁 `object-fit:cover`（会导致图片裁剪）
- 严禁 `position:absolute`
- 严禁高度使用 `100%`、`auto`、百分比或与宽度不相等的像素值
- 严禁在 `<style>` 中定义 `.img-side` 等 CSS 类

### 3. 文字容器规范

- 必须是纯色背景或继承 Section 背景色，使用内联 `style`
- 严禁在文字容器上叠加渐变蒙层（蒙层是模式 B 专属）
- 16:9 / 4:3 左右分栏：文字区与图片区各占 50%（`flex:0 0 50%; width:50%`）

### 4. 图文间距与呼吸感

- 16:9：flex 容器设置 `gap:60px`
- 4:3：文字区与图片区各占 50%，通过各自的 `padding` 产生视觉缓冲间距
- 文案区与图片区之间必须保留 **≥ 24px** 的视觉缓冲间距
- 图片容器与 Section 边缘保留合理留白

### 5. Section 高度与图片高度的关系

- 图片容器高度**必须小于** Section 高度，保留上下空白
- 严禁让图片容器高度等于或超过 Section 高度

---

## 正确结构示例

### 16:9 模式 A（左右分栏，Section 1200×675，图片 500×500）

```html
<div style="width:1200px; height:675px; display:flex; flex-direction:row; align-items:center; padding:0 60px; gap:60px; box-sizing:border-box; background:#fff;">
  <!-- 文字区：占据剩余宽度 -->
  <div style="flex:1;">
    <h2 style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif; font-size:38px;">标题</h2>
    <p style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif; font-size:15px;">描述文案</p>
  </div>
  <!-- 图片区：严格 500×500 正方形 -->
  <div style="width:500px; height:500px; aspect-ratio:1/1; flex-shrink:0; display:flex; align-items:center; justify-content:center; background:#f0ebe3;">
    <img src="..." style="width:100%; height:100%; object-fit:contain;">
  </div>
</div>
```

### 4:3 模式 A（左右分栏，Section 790×592.5）

```html
<div style="width:790px; height:592.5px; display:flex; flex-direction:row; align-items:stretch; background:#fff; overflow:hidden;">
  <!-- 文字区：占一半 -->
  <div style="flex:0 0 50%; width:50%; display:flex; flex-direction:column; justify-content:center; padding:60px 52px;">
    <span style="display:inline-block;width:fit-content;white-space:nowrap;padding:6px 16px;background-color:#ede8df;color:#7a6a52;font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif;font-size:12px;letter-spacing:0.18em;margin-bottom:22px;">卖点标签</span>
    <h2 style="font-family:'AlibabaPuHuiTi_2_95_ExtraBold',sans-serif;font-size:36px;line-height:1.2;color:#1e1e1e;margin:0 0 18px 0;">卖点标题<br>副标题</h2>
    <p style="font-family:'AlibabaPuHuiTi_2_55_Regular',sans-serif;font-size:14px;line-height:1.85;color:#6b6b6b;max-width:320px;margin:0;">卖点描述文案。</p>
  </div>
  <!-- 图片区：占一半，图片容器通过 aspect-ratio:1/1 保持正方形 -->
  <div style="flex:0 0 50%; width:50%; display:flex; align-items:center; justify-content:center; padding:44px;">
    <div style="width:100%; aspect-ratio:1/1; border-radius:24px; overflow:hidden; background:#f0ece4;">
      <img src="..." style="width:100%; height:100%; object-fit:contain;">
    </div>
  </div>
</div>
```

**4:3 左右分栏关键约束**：
- 文字区与图片区各占 50%（`flex:0 0 50%; width:50%`）
- 图片容器通过 `aspect-ratio:1/1` 保持严格 1:1 正方形
- 使用 `flex-direction:row`（左文右图）与 `flex-direction:row-reverse`（左图右文）交替

---

## 错误结构示例（严禁）

```html
<!-- 错误 1：图片做半屏 absolute 背景 -->
<div style="position:relative; height:675px;">
  <img style="position:absolute; left:0; width:55%; height:100%; object-fit:cover;">
  <div style="position:absolute; right:0; width:50%;">...</div>
</div>

<!-- 错误 2：图片容器宽高不等（高度 100% 不等于 340px） -->
<div style="display:flex; height:675px;">
  <div>文字</div>
  <div style="width:340px; height:100%;">
    <img>
  </div>
</div>

<!-- 错误 3：在 <style> 中定义 .img-side CSS 类 -->
<style>.img-side { width:500px; height:500px; }</style>
```
