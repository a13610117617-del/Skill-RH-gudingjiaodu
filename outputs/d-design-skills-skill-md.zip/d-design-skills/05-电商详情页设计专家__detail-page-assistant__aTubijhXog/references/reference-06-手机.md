---
title: "手机"
type: "reference"
---

# 手机
## selling_points: sj_1 耐摔/三防认证

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Rugged Hero - Extreme Durability""] [Layout Type]: [""Triple-Card High-Impact Triptych""] [Global Canvas Logic]: [ 纵向分区： 画布顶部 25% 区域设定为绝对视觉留白（Negative Space）。 主体布局： 画布底部 75% 区域为卡片展示区。 空间撑满协议 (核心修正)： 三个圆角卡片必须在纵向上完全撑满底部的 75% 空间。卡片的底边应贴近画布底边缘，仅在画布最左、最右、最底侧及卡片之间保留极窄的极浅灰色缝隙，确保视觉冲击力最大化。 无阴影协议： 保持卡片与背景平齐，严禁任何投影。背景色值统一为极浅灰色 (#F2F2F2)。] === SECTION A (主体与卡片内容) === [Anchoring & Space]: [ 三个卡片从左至右水平等分排列，卡片间保留极窄的极浅灰色缝隙。卡片内部展示设备在不同极端环境下的生存状态。] [Generic Subject Container]: [高端三防智能手机设备（Rugged Mobile Device Architecture）。 Description: (严格泛化) 一款高端的移动设备架构。其直径圆环形镜头模组及侧边防护按键的几何逻辑完全依参考图为准。] Single Subject Rule (硬性规定)： 每个卡片内部严禁出现两台或两台以上的设备。禁止叠放、禁止重复，每张卡片仅展示一台手机（Single device per card only）。] [Card Content & Environment]: [ 左侧卡片 (水下环境)： 一台手机浸泡在湍急流水中，表面带有圆润的水珠，背景为深色鹅卵石。 中间卡片 (荒漠环境)： **一台手机（仅限一台）**斜插或半掩埋在细腻的荒漠流沙中，机身表面覆盖着薄薄的沙尘，呈现风蚀质感。 右侧卡片 (物理冲击)： 一台手机在岩石撞击瞬间，伴随飞溅的碎石与粉尘，强调坚硬机身的抗冲击性。] [Environment]: [卡片外部背景为单一、连贯的极浅灰色 (#F2F2F2)。顶部 25% 空间纯净无物。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 高对比度商业布光。利用侧向轮廓光捕捉水珠和砂砾的质感。确保三张照片的明暗调性、光源方向保持高度统一。] === HARD CONSTRAINTS (硬性限制) === TOP 25% BLANK: 顶部必须预留绝对留白。 FILL BOTTOM 75%: 卡片需纵向占满底部的全部可用空间。 STRICTLY ONE PHONE PER CARD: 每一张卡片严禁出现超过一台手机，禁止叠放，禁止重复。 NO SHADOWS: 保持卡片边缘洁净，严禁阴影。 CONSISTENT HARDWARE: 三张卡片中的手机必须是同一型号。 [Negative Prompt (负向提示词)]: (Two phones in one card, stacked phones, overlapping devices, duplicate devices, multiple smartphones, shadows under cards, floating effects, dividing lines in background, top space filled, text, logo.)
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图文分离模式】整体布局采用顶部居中对齐与下部三栏纵向分区。顶部文本组跨越垂直中轴线，由高字重标题与常规字重辅助区构成上下层级。下半部包含三个等宽并行的矩形视觉元素。在每个矩形内部的产品轮廓上，均嵌入一处小型、不透明矩形文字容器，该容器与产品轮廓保持固定位移。整体强调中轴对称，顶部通过垂直间距确立引导，底部通过重复性容器布局实现结构一致性。

---

## selling_points: sj_2 大容量电池/快充

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Subject Mode]: [""Rugged Product Hero - Lower-Third Alignment""] [Layout Type]: [""Extreme Bottom-Weighted Composition""] [Global Canvas Logic]: [ 重心强制约束：主体结构（手机+电池）必须严格限制在画布垂直高度的底部 0%-40% 区域内。 负空间控制：顶部 60% 区域必须为绝对纯净、无任何杂质的渐变浅灰色/白色虚空（Absolute Negative Space），严禁任何构图元素侵入。 构图分布：单台设备水平放置，利用大面积的顶部留白压迫视线向下聚焦。 ] === SECTION A (主画面/主体表现) === [Anchoring & Space]: [ 视角：极低角度侧平视。 地面美学 (Weightless Ground)：地平面需呈现出极高的亮度，与背景融为一体。 投影弱化 (Shadow Suppression)：取消一切物理阴影，仅保留极其微弱、近乎透明的环境遮蔽（Minimal Ghostly AO）。 倒影处理：使用渐隐式的倒影 (Faded Subliminal Reflection)，倒影应在向下延伸几毫米内迅速消失，严禁形成深色色块。 ] [Device Integrity - 手机严禁泛化]: [ 主体性质：Solid and Opaque Phone Body (坚固且不透明的手机实体)。 细节保护：严格锁定参考图的工业设计。手机背板是一个完整的、封闭的物理平面。严禁显示任何内部结构、零件或空腔。 ] [Floating Battery Layer - 电池模块]: [ 形态逻辑：一个薄且宽大 (Slim and wide) 的发光矩形层。 悬浮关系：平行悬浮于手机背板上方，不产生物理接触。 纹理与光效：高密度线性微网格，高饱和青蓝色 (Cyan) 自发光，带有精密的光学透明质感。 ] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 无影照明 (Shadowless Lighting)：采用全方位的商业漫反射柔光，彻底消除明暗交界线和物理阴影。 自发光融合：电池模块的青光仅作为微弱的氛围点缀，不应对地面产生强烈的色偏投影。 ] === HARD CONSTRAINTS (硬性限制) === STRICT BOTTOM 40%: 整个手机和电池组合严禁超出画布下方的 40% 范围。 MINIMALIST SHADOW: 严禁黑色、灰色或任何重度投影，画面底部必须保持通透。 OPAQUE CHASSIS: 手机背板绝对不可见内部结构。 ULTRA-SLIM PROFILE: 电池必须表现为一层“发光薄片”，不要过厚。 HIGH FIDELITY: 手机外观细节必须与参考图高度一致。 [Negative Prompt (负向提示词)]: (Centered composition, top-heavy, middle-placed subject, heavy black shadows, dark ground, strong reflections, internal circuits, motherboard, disassembled view, thick battery, messy wires, cluttered background, grey gradient line.)
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局采用垂直分区逻辑。上部为文本聚合区，下部为产品轮廓锚点。文本区顶部设中心对齐层级，跨越垂直中轴线，由加粗主级与常规次级文本构成。其下方分布六组文本单元，呈三列双行矩阵排列，均直接叠于背景之上，无额外背景框。每组单元内部遵循左对齐原则，通过字重区分双层级关系：上层加粗，下层常规。文字为深色，顶部不要有深色渐变。 该文本矩阵以中轴线为基准对称排布，形成了清晰的网格结构。底部产品轮廓水平居中，与上方文本阵列维持均衡的视觉留白。整体空间分区明确，视觉引导由顶端中心点向下方矩阵平铺扩散，层级逻辑严密，构图比例均衡，体现了严谨的工程化排版。

---

## selling_points: sj_3 屏幕高刷新率

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Subject Mode]: [""Product Hero - Screen Tech Focus""] [Layout Type]: [""Lower-Weighted Composition""] [Global Canvas Logic]: [ 1. **构图分布：** 采用“下沉式”构图，主体设备及其屏幕叠影层被严格锚定在**画面的下半部分（底部约 65% 区域）**。 2. **留白协议：** 画布**顶部 35% 区域设定为绝对视觉留白（Negative Space）**，严禁任何硬件或叠影零件侵入。 3. **背景连续性：** 全图必须使用**单张连续的无缝背景 (Single seamless continuous background)**。严禁在留白区与主体区交界处出现任何物理分割线、色块断层或亮度突变。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 极低角度侧平视（Extreme Low-angle Lateral View）。视角几乎与地面贴合。背景采用**无限延伸的影棚穹顶（Seamless Cyclorama）**逻辑，确保从底部地面到顶部留白区呈现出极致丝滑的浅灰白渐变过渡。**严禁在地面展示任何文字、字母或“120Hz”字样投影。**] [Generic Subject Container]: [Mobile Device Architecture（动态高刷新率演示状态）。 Description: (严格泛化) 一款高端智能手机设备。其物理外观与工业机身轮廓完全依参考图为准。 Color & Trim: 屏幕上方呈现多层半透明的光学切片（Motion Trail Layers），通过蓝紫色（Cyan）渐变光效传达流畅感。严禁任何跟屏幕垂直立起的形态。] [Material Physics]: [ **叠影质感：** 屏幕叠影表现为多层半透明发光体，边缘带有轻微的光学羽化，无文字内容。 **机身质感：** 加固中框展现出颗粒感细腻的哑光漫反射，物理切面转折锐利。 **地面特性：** 地面呈现为高亮抛光材质，仅捕获并漫反射来自屏幕的纯净冷光晕，**严禁产生任何字符形状的投影**。] [Environment]: [极简高调（High-key）科技空间。背景色值由顶部的纯白色（#FFFFFF）向底部的极浅灰色（#F5F5F5）平滑、无缝地渐变，营造极致的工业纯净感。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 电影级专业布光。利用屏幕本身的半透明叠影作为核心氛围光源。**全局照明一致性原则：** 整个 1:1 空间内的采光逻辑必须完全统一，确保背景色调在视觉上绝对连贯。] [Hard Constraints (硬性限制)] 1. **TOP 35% ABSOLUTE BLANK:** 顶部 35% 区域严禁出现任何物体，仅保留纯净背景。 2. **NO TEXT ON FLOOR:** 严禁在地面、背景或画面任何位置展示“120Hz”或任何其他文字。 3. **SEAMLESS BACKGROUND:** 背景必须横向、纵向完全连贯，禁止出现地平线或分割感。 4. **BOTTOM 65% POSITIONING:** 保持构图重心在下方。 5.GENERALIZATION: 严禁对手机形态进行任何概括或修改，必须忠实于参考图。
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局呈上文下图分布。顶部信息区跨越中轴线，由高层级加粗文本构成居中重心。其下分布五组离散信息块，呈三列两行的矩阵排布，其中次行右侧留白。每组均包含高低双层字重结构，每组信息块含高字重首层与常规字重次层，内部左对齐且直接叠放于背景。视觉重心受顶部文字密度引导，下方以横向产品轮廓作为空间定位锚点。整体未设封闭式容器，通过间距与字重建立视觉分区。逻辑严谨，信息块间距等比分布，形成高度结构化的参数化版式。

---

## selling_points: sj_4 处理器/大运行内存/大存储空间

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""CMF Layering""] [Layout Type]: [""Asymmetric Lower-Third Composition""] [Global Canvas Logic]: [ 重心布局： 两块半导体存储芯片以对角线趋势分布在画面的下半部分（Lower 65%）。 留白协议： 画面顶部 35% 区域设置为绝对的视觉留白（Negative Space），严禁任何芯片实体或复杂纹理侵入。 空间排布： 两块芯片彼此分离且严禁重叠（Non-overlapping, spatially separated）。 背景连续性： 整个背景（包括留白区与芯片区）必须由单张连续的电路蓝图纹理贯通，严禁出现任何形式的物理分割线或色块断层。 【接地指令】： 芯片必须紧贴电路板表面 (Surface-mounted/SMT)。严禁任何悬浮间隙，芯片底部边缘应产生深邃且极细的接触阴影 (Contact Shadows)，展现其实际重量感。] === SECTION A (主画面/全景) === [Anchoring & Space]: [高角度等轴侧透视图（High-angle Isometric View）。芯片主体锚定在画面中下部。视角强调芯片作为独立个体的空间感，而非堆叠感。背景电路纹理从底部自然向上延伸至留白区，但纹理在中上部需逐渐淡出，确保背景的一致性与连续感。视角聚焦于两块独立放置的黑色正方形芯片。] [Generic Subject Container]: [高端智能手机核心存储组件。 Description: (严格泛化) 一组独立排布的封装芯片架构。 【去标化协议】：芯片表面严禁出现任何文字、字母、数字或丝印标志（Strictly NO TEXT / Unmarked）。 Color & Trim: 芯片主体为纯净的深炭黑色（Charcoal Grey），展现最原始的工业美学。基板边缘带有抛光金属银色的精细倒影。] [Material Physics]: [ 【真实材质】： 芯片顶面呈现原始半导体芯片的微观结构质感（Raw semiconductor micro-matte texture）。无文字干扰，展现真实的 CMF 工艺细节。] [Environment]: [数字科技实验室空间。背景为统一的白色底色，带有极浅灰色的线性电路路径（Schematic lines）。电路路径需从芯片底部平滑延伸至顶部的留白区域，确保背景的视觉连贯性。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高调商业摄影布光。利用柔和的环境遮蔽阴影（Ambient Occlusion）强化芯片的悬浮立体感。重点使用冷白色的边框光（Rim Light）勾勒芯片的 90 度转折边缘，在无文字的纯净表面上形成一道利落的物理高光。] [Hard Constraints (硬性限制)] NO TEXT ON CHIPS: 芯片表面必须完全纯净，无任何文字。 NO OVERLAP: 两块芯片必须分开，禁止堆叠。 TOP 35% BLANK: 顶部 35% 严禁出现芯片或发光体。 CONTINUOUS BACKGROUND: 背景纹理必须横向、纵向完全连贯，无分割线。
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图片叠底模式】整体采用垂直分层与中轴对称布局。顶部跨越垂直中轴线，由加粗文字区与常规文字区构成，呈中心对齐。中部文本区域呈横向双栏排布，分列于中轴线左右两侧，每组均包含高低双层字重结构。左右文本组的空间位置分别垂直对应于下方两个产品轮廓元素的正上方，文本组根据偏上方的那组顶部对齐。所有文字区域均直接叠加于背景视觉元素之上，无独立背景框。底部产品轮廓呈对角线位移分布，作为空间锚点支撑上方文字排布，整体通过对齐逻辑实现工程化秩序。

---

## selling_points: sj_5 Gemini AI功能

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Friendly AI Assistant - Advanced Intelligence""] [Layout Type]: [""Unified High-Key Composition""] [Global Canvas Logic]: [ 画幅协议： 设定为 1:1 正方形比例。 纵向分区： 画布顶部 35% 区域设定为绝对视觉留白（Negative Space），背景为纯净的浅灰色到白色的平滑渐变。 内容锚定： 核心 AI 机器人主体锚定在画布底部 65% 区域。 去卡片化协议： 严禁出现底部的白色 UI 卡片或磨砂玻璃容器。 机器人主体应直接、完整地置于背景之上，底部无任何遮挡。 背景连续性： 背景采用单张连续的高调（High-key）浅色科技空间，环境光线通透，展现顶级工业产品画册质感。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 正面直视视角（Frontal View）。视觉重心聚焦于机器人高度拟人化且友好的交互面部。构图平衡对称，通过圆润的轮廓线消除冰冷的机械感，建立与用户间的信任感。] [Generic Subject Container]: [Highly Sophisticated & Friendly AI Architecture. Description: (亲和力与精密感平衡) 一款融合了极致精密工艺与友好外形的 AI 机器人。 面部特征： 头部为流线型类球体。深邃的深蓝宝石盖板下，拥有一对具有神采的数字化圆形双眼； 嘴巴设计： 在眼部下方，设计有一个极简且优雅的 LED 发光曲线作为嘴巴，呈现出微微上扬的温和表情，模拟人类的微笑； 交互背景： 背后环绕着半透明的、极细的全息数字化光圈（HUD），展示其智能运算状态。 Color & Trim: 机身为极简科技白（Ceramic White）与缎面抛光银（Satin Polished Silver）。核心发光位为温暖的柔和青色（Soft Cyan）。] [Material Physics]: [ 外观质感： 机身呈现温润的高级陶瓷（Vitrified Ceramic）质感，表面有细腻的珍珠母贝光泽。 面部盖板： 采用高透明度、无畸变的弧面玻璃，能够看到内部精密的透镜组件。 发光组件： 眼部和嘴巴的 LED 光线具有柔和的呼吸感，边缘带有细腻的物理溢光（Bloom），无刺眼感。] [Environment]: [ 极简禅意科技空间。 背景色调由底部的浅灰向顶部的纯白自然过渡。空气中带有极轻微的朦胧感，使背景中的全息圆环呈现出优美的焦外虚化（Bokeh）。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 高调工作室漫反射布光。 环境光充沛且柔和，利用柔光箱在机器人头部的圆润弧面上形成长而优雅的弧形高光（Strip Highlights）。确保面部表情清晰，整体氛围阳光、健康、充满科技人文关怀。] === HARD CONSTRAINTS (硬性限制) === MUST HAVE EYES AND MOUTH: 机器人必须具备清晰的、具有亲和力的双眼和微斜上扬的嘴巴线。 APPROACHABLE DESIGN: 工业设计必须圆润，严禁出现尖锐边缘或攻击性造型。 ASPECT RATIO 1:1. LIGHT BACKGROUND: 全局浅色，严禁黑色。 NO UI CARD: 严禁出现底部的磨砂玻璃遮挡卡片。 TOP 35% BLANK: 顶部 35% 区域必须为纯净留白。 [Negative Prompt (负向提示词)]: (Aggressive, scary, sharp edges, no mouth, dark background, black, bottom UI card, frosted glass bar, floating text, labels, smartphone, wide crop, shadows, chaotic background.)
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图片叠底模式】整体采用垂直向心布局。顶部由加粗标题区与常规副标题区构成，跨越垂直中轴线居中对齐。中部设有一大型圆角矩形容器，背景高度透明并设有极细边框，该容器横跨中轴线且位于底部视觉元素正上方。容器内部短语区块呈双列纵向排布，左侧与右侧组均采用左对齐逻辑。布局通过字重建立由上至下的视觉层级，中部容器将多组区块聚合，与背景视觉元素在垂直维度上形成清晰的分层与工程化分区。

---

## selling_points: sj_6 超薄/轻量化设计

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Product Hero""] [Layout Type]: [""Lower-Weighted Composition""] [Global Canvas Logic]: [ 构图分布： 虽然视觉重心位于画面的中下部（底部 70% 区域），但背景色调与质感必须从底部向上方 30% 的留白区平滑、无痕地延伸。 重心分布： 单台设备水平侧倾，精准平衡于一根人类食指尖端。 交互核心： 指尖与设备的接触点必须位于机身背板的几何中心（Geometric Center of the Backplate），形成完美的平衡支点视觉。 背景连续性： 整个背景必须由单张连续的背景图贯通，严禁出现任何形式的物理分割线或色块断层。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 中下部锚定视角。主体设备位于画幅中下 70% 区域，通过低角度仰拍强调中框的线性厚度。背景连续性协议： 全图共享一张无缝背景，严禁出现任何物理分割线或明暗断层，确保留白区与主体区自然过渡。] [Generic Subject Container]: [Mobile Device Architecture（中心平衡状态）。 Description: (严格泛化) 一款极致纤薄的高端智能手机设备。指尖稳固支撑于背板中心，设备在其上呈微妙的对角线倾斜。镜头模组与 R 角细节完全依参考图为准。] 接触点处的指尖皮肤与金属背板交界清晰，呈现真实的物理压感与极微小的接触阴影（AO）。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [电影级高调布光。利用细长的条形高光（Strip Light）为主体勾勒出极细的边框轮廓。全局环境光确保顶部 30% 留白区域色调纯净、统一，没有任何视觉干扰。] [Hard Constraints (硬性限制)] NO HORIZON LINE: 严禁出现任何地平线、分割线或由于构图造成的色块断层。 SEAMLESS GRADIENT: 背景必须是单一且连续的白灰色阶渐变（#FFFFFF 到 #F2F2F2）。 CENTERED BALANCE: 指尖必须位于背板的正中心。 BOTTOM 70% FOCUS: 主体保持在画面中下方，顶部 30% 保持完全空旷。
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局采用垂直中轴线对称逻辑。顶部区域横跨中心，包含加粗一级文本区与常规字重二级文本区，呈居中对齐。中部信息分布于垂直中轴线两侧，呈双列镜像排布；每列包含垂直叠放的两组纯文本区，上层文本字重及尺寸显著高于下层。该双列模块均悬浮于底部背景轮廓上方。所有文本直接置于背景之上，未采用独立背景框体。空间分区明确，通过阶梯式字重建立层级，各文本区与轮廓保持垂直等距。

---

## selling_points: sj_7 NFC功能

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Subject Mode]: [""Product Hero - Advanced NFC Visualization""] [Layout Type]: [""Seamless Continuous Composition""] [Global Canvas Logic]: [ 画幅分区协议： 画布顶部 25% 区域设定为排版留白空间。 极简背景协议 (核心修正)： 全图采用单张连续的极浅灰色 (#F7F7F7) 无缝影棚背景。严禁在 25% 留白区与下方内容区间出现任何物理分割线、色块断层或水平切痕。背景需呈现出从底部到顶部极致平滑、一体化的视觉连续性。 主体分布： 核心手持设备与信号扩散光效整体布局于画布中下部。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 正面直视视角，单手持握移动设备呈现约45度斜向构图。视觉焦点位于设备中心及其扩散出的能量场。 信号扩散逻辑： 信号场由三层半透明光环组成，其物理平面必须与手机背板保持绝对平行 (Parallel)，呈现出从机身中心向四周辐射的透视感。] [Generic Subject Container]: [Mobile Device Architecture. Description: (严格泛化) 设备背板完全显露，由单手稳固持握。其镜头布局、机身比例及手指持握的逻辑完全依参考图为准。] [Visual Effect - 360° NFC (效果优化)]: [ 去描边化协议： 严禁出现细窄的、具有硬边缘的矢量线条（No hard strokes/outlines）。 光束感增强： 信号扩散环应表现为软边缘的渐变光晕 (Soft-edged gradient halos)。每一圈环呈现为从中心向边缘自然羽化的蓝青色自发光色场，具有体积感和呼吸感。 三环逻辑： 严格设定为三圈。最内圈直径显著宽于手机机身宽度。 弱化重叠： 当光晕覆盖手机背板时，需呈现高透明度的蒙版效果，仅保留微弱的色彩叠加，确保不遮挡手机的 CMF 细节。] 背板呈现温润的陶瓷玻璃质感 (Vitrified Ceramic Glass)，伴有丝绸般的漫反射高光。信号光效表现为高斯模糊化的光电磁场 (Gaussian-blurred electromagnetic field)，具有数字化的深邃感。] 无限远背景协议。背景为单一的、无分割的极浅灰色渐变空间，营造出极致纯净的专业产品渲染视觉。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 商业级全局柔光。利用大面积柔光箱确保背景色调的统一性。信号光晕被设定为次要自发光源，产生轻微的氛围漫反射。] === HARD CONSTRAINTS (硬性限制) === ABSOLUTELY NO DIVIDING LINES: 全图背景必须无缝连续，严禁顶部留白区与内容区之间出现任何横线。 SOFT HALOS ONLY: 严禁使用线条描边，必须使用柔和、羽化的渐变光晕。 ULTRA-LIGHT GRAY BACKGROUND: 背景统一为极浅灰色渐变 (#F7F7F7)。 PARALLEL ALIGNMENT: 信号光晕必须平行于手机背板。 EXACTLY THREE RINGS: 信号光晕数量固定为三圈。 NO TEXT: 严禁出现任何文字标签或 Logo。 INNER RING > PHONE WIDTH: 最内圈必须完全环绕并宽于手机。
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局采用顶部居中垂直堆叠逻辑。视觉重心在垂直维度分为上下两部分，信息区位于画面上部约三分之一处，跨越垂直中轴线。该区域由两层文本构成：顶层为高字重标题区，下方为低字重正文短语区，均呈严格水平居中对齐。文字区域直接叠放于背景之上，不含几何背景框或容器。下部约三分之二空间由产品轮廓及环绕式视觉元素占据。文字区域与产品轮廓保持固定比例负空间，形成清晰的功能分区。整体动线由顶部信息向中心产品锚点收拢，视觉路径工程化且明确，无多余散点干扰。

---

## selling_points: sj_8 Android 15/16系统

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Product Hero - Android 16 Edition""] [Layout Type]: [""Integrated High-Scale UI Collage""] [Global Canvas Logic]: [ 1. 居中与比例： 核心展示区域（手机+扇形面板，不计投影）必须垂直居中 (Vertically Centered) 且大比例显示 (Large Scale)，主体高度应占据活动区域的 70% 以上，形成一个高大、宏伟的视觉墙。 2. 扇形透视： 手机为中心，6 块 UI 面板呈 1+3+3 的放射状扇形纵深排列。面板的高度与手机屏幕高度保持约 90% 的高度一致。] === SECTION A (主画面/全景) === [Anchoring & Space]: [绝对正视视角 (Strict Frontal Orthographic View)。手机设备位于画面正中心，无任何偏角。左右两侧 UI 面板通过透视向远处收缩。图标叠在手机界面之上随机分布] [Generic Subject Container]: [Mobile Device Architecture. Description: (严格泛化) 一款高端智能手机。正面大屏占比，正视角度。 屏幕内部展示 Android 16 原生壁纸，带有醒目的系统 Widget。屏幕展示原生系统界面 (Minimalist Android Home Screen)：上方为一个简洁的数字时钟小部件，下方保留 4 个彩色 Dock 图标。严禁复杂的文字堆叠或密集网格。 Size Note: 手机设备在画面中具有极高的纵向占比。] [Material Physics]: [ 六个独立功能面板 (6 Unique Functional Panels)： 面板形态： 纯白色不透明实体，锋利直角 (Sharp 90-degree corners)，严禁圆角。 左侧 (3个面板)： 左1. 隐私防窥界面 ；左2. 真实拨号界面，采用标准的 Android 电话拨号 UI，暗黑模式；左3. 手机管家环形进度条设置。 右侧 (3个面板)： 右1. 音乐播放器；右2. 社交界面 Feeds流卡片；右3. 系统设置页面。 质感： 哑光白色底色，文字和图标色彩鲜艳，具有真实的 2D 矢量设计感。 内容要求： 每个面板元素单一、准确，严禁内容重复或信息过载。] [Active VFX & Lighting]: [ 随机图标阵列 (Icon Chaos): 约 8 个主流应用图标（Facebook, YouTube, WhatsApp, X, Instagram, TikTok, Chrome, Maps, Play Store 等）。 分布逻辑： 图标随机散落在手机周围及 UI 面板之上 (Randomly scattered)，大小不一，具有透视落差。图标在最上层，盖在 UI 面板或手机之上，大小不一随机排列，形成深度丰富的三维层叠感。 【严禁重复】 包含 Facebook, YouTube, WhatsApp, X, Instagram, TikTok, Chrome, Maps, Play Store, Photos, Settings。每一个图标在画面中仅能出现一次，严禁相同图标多次堆叠。] [Environment]: [极致简约的白色科技空间，地面具有高清镜面反射，完美倒映出手机及底部的 UI 元素。 投影处理 (Soft Shadows): 阴影必须紧贴界面底边 (Shadows anchored to base)。弱化反射与投影 (Weakened reflection)。地面仅保留微弱、模糊的软阴影（Soft ambient occlusion），严禁出现高清晰度的镜像倒影，确保地面视觉干扰降至最低。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [全方位高调均匀布光。重点加强 UI 面板与图标之间的微弱环境阴影 (Ambient Occlusion)，增强层叠的真实感，确保顶部留白区域干净无瑕。] [Hard Constraints (硬性限制)] NO TEXT/LETTERS/WORDS AT THE TOP. (顶部严禁出现文字、字母或单词) NO DUPLICATE ICONS. (图标严禁重复) 主体高度应占据活动区域的 70% 左右。 HIGH SCALE PANELS: 面板高度必须达到手机高度的 85-90%。
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图文分离模式】整体布局采用顶部居中与中心对称结构。顶部跨越垂直中轴线，由双层文本组成：上层为高字重主层级，下层为常规字重次层级。中下部视觉重心以产品轮廓为空间锚点，向两侧呈放射状层叠排布。除顶部核心区外，背景空间内无额外纯文字背景框或标签容器。布局逻辑明确，利用垂直中轴线建立严密平衡，通过字重差异确立顶部层级，底部通过几何轮廓的堆叠引导视觉焦点，整体呈现去修饰化的工程化排布。

---

## selling_points: sj_9 超清拍摄

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Subject Mode]: [""High-Fidelity Product Hero""] [Layout Type]: [""Dual-Subject Horizontal Composition""] [Global Canvas Logic]: [ 绝对无缝背景协议 (核心修订)： 全图必须使用单一且物理连续的极浅灰色至白色空气感渐变 (#F7F7F7 to #FFFFFF)。严禁在画面任何位置出现横向线条、地平线、色块断层或亮度突变。 背景应像无限延伸的雾气一样，从底部自然消散至顶部，确保 35% 留白区与内容区在视觉上完全融为一体，无任何可察觉的交界。 去容器化协议： 严格禁止在主体内容外围出现任何圆角矩形边框、卡片容器或 UI 背景块。 水平对齐： 左右两个主体在视觉中心线上保持严格水平对齐。 纵向分布： 主体内容锚定在画布底部 65% 区域，顶部 35% 区域保持绝对纯净负空间。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 正面直视视角（Frontal View）。左侧主体为横向握持，右侧主体为垂直立姿。] 1:1 硬件特征锁定： 严禁生成通用的智能手机模型。硬件细节（镜头、中框、按键、黑边）必须严格遵循参考图的工业设计。] [Generic Subject Container]: [High-End Imaging Smartphone. Description: 左侧状态 (高清后摄表现)： 单手横向握持设备。屏幕内展示一张全屏高清风景照。 右侧状态 (前摄自拍矩阵)： 设备垂直立姿。屏幕内展示一张极高清晰度的全屏人物自拍照 (Selfie Portrait)。以该设备为中心，多张数字化照片卡片向两侧对称扇形展开。 内容一致性协议 (核心修订)： 所有扇形展开的数字化照片卡片，其内容必须全部锁定为“人物自拍照”（Selfie Portraits）。严禁出现风景、城市建筑、食物、宠物或家庭合照。每张卡片应展示不同角度或背景的单人自拍像，以强化前置摄像头的核心卖点。 全屏纯净显示协议： 手机屏幕严禁出现任何相机 UI、图标或状态栏。] 屏幕： OLED 极致黑色基调，表面捕捉极微弱环境冷光。 数字化资产： 扇形展开的自拍照卡片具有轻微的半透明感与边缘微弱发光。卡片内容清晰且主题统一（全是自拍）。 机身： 精密的金属切边工艺，还原参考图中的粗犷/精密质感。] [Environment]: [高级商业影棚空间。强调单一、无分割、无地平线的背景。 主体下方带有极轻微的漫反射柔和投影。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [电影级高调漫反射布光。整个空间的采光逻辑必须高度统一，确保背景色调在视觉上绝对连贯。] === HARD CONSTRAINTS (硬性限制) === NO HORIZONTAL DIVIDING LINE: 严禁出现任何形式的横向分割线、阶梯阴影或背景断层。背景必须是完美的单片渐变。 ALL CARDS ARE SELFIES: 右侧扇形展开的所有照片必须全部是单人自拍照。严禁风景照、严禁食物照、严禁建筑照。 STRICTLY NO UI: 手机屏幕内禁止出现任何相机按钮、图标或系统文字。 TOP 35% BLANK: 顶部必须预留绝对留白区。 SYMMETRIC FAN-OUT: 右侧照片卡片必须以手机为中心对称展开。 [Negative Prompt (负向提示词)]: (horizontal line, dividing line, split background, background seam, floor line, horizon, scenery cards, food photos, architecture cards, landscape on small cards, family group photos, camera UI, shutter button, settings icons, status bar, text on screen, menu, gray frame, border, card container.)
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局呈现顶部中轴对称与中下部双侧均衡结构。顶部区域跨越垂直中轴线，由高字重标题构成视觉锚点。中段文本呈左右对称分布，分别位于垂直中轴线两侧，各包含加粗层级的主描述区与常规字重的多行正文区。所有文字区域直接叠放于背景之上，未采用封闭式背景框。文本分布逻辑与底部两个产品轮廓形成严谨的垂直对应关系：左侧文本组位于水平向产品轮廓正上方，右侧文本组与垂直向产品轮廓保持纵向对齐。整体视觉流由上至下引导，通过字重与间距差异建立清晰的信息层级分区，空间分布逻辑呈现高度的工程化对齐特征。

---

## selling_points: sj_10 流畅无卡顿

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Product Hero""] [Layout Type]: [""Unified Scene""] [Global Canvas Logic]: [画面中心由一双手水平握持单台“Mobile Device Architecture”。设备呈横屏景观状态，屏幕处于高亮度激活状态。构图强调人机交互的平衡感，视觉重心锁定在指尖与屏幕接触的中心区域。] === SECTION A (主画面/全景) === [Anchoring & Space]: [正面平视视角。双手对称分布于设备两侧，拇指自然置于屏幕操作区域。设备占据画幅中下部空间，上方预留约 35% 的纯净灰色背景空间。] [Generic Subject Container]: [Mobile Device Architecture (横向手持状态)。 Description: (严格泛化) 一款高端移动设备。其物理外观完全依参考图为准。 【屏幕画面细节强化】： 屏幕展示一张 AAA 级写实类现代军事战争游戏 (Realistic Modern Warfare) 实机画面。 视觉中心： 一位身着全套战术迷彩服（Multi-cam）和战术背心（Plate Carrier）的特种部队士兵，手持带有消音器和全息瞄准镜的现代突击步枪，正处于城市废墟的火拼中心。 特效渲染： 极致真实的枪口火焰 (Muzzle Flash) 瞬间、爆炸产生的厚重尘土云与碎石颗粒。高动态范围（HDR）下，爆炸火光产生的暖橘色与阴影处水泥残骸的冷灰色形成强烈对比。 环境深度： 极高清晰度的废墟战场地。远景伴有真实的**空气热浪（Heat Haze）**与碎石、硝烟弥漫的纵深感。 游戏 HUD： 屏幕边缘叠加简约的军用级战术 UI。包含：左上角半透明战术小地图、右下角简洁的白色弹药计数器、以及屏幕上方细长的方位罗盘（Compass tape），UI 风格严谨、写实。] [Material Physics]: [屏幕盖板呈现 OLED 极致自发光特性，色彩饱和度极高，黑场深邃。屏幕光影由于盖板玻璃的物理属性，在指尖按压处产生极细微的光学折射与发光扩散。加固中框呈现高强度复合材料的哑光漫反射质感。] [Environment]: [专业摄影棚环境，纯净的浅灰色（#D8D8D8）无缝背景，无多余阴影干扰，营造极简且聚焦产品的商业质感。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [全局采用高调均匀散射光。强调屏幕溢光效应： 屏幕内剧烈的枪火暖光与冷色调环境光作为核心光源，为拇指内侧边缘投射出真实的、具有色彩倾向的漫反射光晕，使产品与人手完美融合。]
- 图片1比例：{尺寸比例}  
- 参考图描述：商品主图、手机背面

**布局说明：**
【图片叠底模式】整体布局采用垂直分层的中心对称逻辑。信息区块集中于画面顶部，跨越垂直中轴线分布。视觉层级由上至下递减：顶部为高字重的标题区域，下方紧随多行常规字重的正文区块，两者均直接置于背景之上，未设置独立背景框。文本区域与下方产品轮廓保持明显的纵向间距，形成上方信息区与下方视觉重心区的两极化排布。整体构图严谨，通过中心对齐确保视觉平衡。正文区域宽度限制在产品轮廓范围内，形成了清晰的视觉聚拢感。

---

## selling_points: sj_11 夜景模式

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Professional Night Mode Comparison - Dark Theme""] [Layout Type]: [""Lower-Weighted Split-Screen Composition""] [Global Canvas Logic]: [ 画布分区： 顶部 25% 区域为绝对纯净的黑色视觉留白，为后期白色或浅色文字排版预留空间。 主体极大化填充： 影像对比单元从画布纵向 25% 处开始，向下完全撑满底部 75% 的区域。 等比例窄边距： 照片整体与画布的左、右、底三侧仅保留极窄且完全一致的等距间距 (Minimal Uniform Margins)，以获得最大的视觉冲击力。 背景连续性： 全图背景统一为深黑色，营造高端、沉浸的暗色调科技感。] === SECTION A (对比影像细节) === [Anchoring & Space]: [ 正面直视构图。左右两张 1:1 矩形影像紧密并排。每张影像均采用圆角工艺（Rounded Corners）。影像与浅灰色背景之间带有极轻微的投影（Subtle Drop Shadow），以增强层次感。 核心特征 - 分割线： 两张影像之间必须有一条清晰、垂直的极细分割线 (Sharp Vertical Dividing Line)，颜色可为深灰色或微光白，用于明确区分左右画面的处理边界。 镜头控制： 采用无畸变的长焦俯拍视角，确保城市建筑线条垂直挺拔。] [Generic Subject Container]: [宏大城市 CBD 俯拍夜景。 Description: (严格一致性) 左右展示完全相同的宏大城市俯瞰全景。构图包含密集的摩天大楼群、蜿蜒的河流及跨海大桥，左右构图逻辑 1:1完全对齐。 对比差异 (算法逻辑): 左侧 (常规拍摄 - Off): 色调深沉且偏暗。高光处的霓虹灯有明显的物理溢光 (Light Bloom)；建筑物的背光面呈现为完全的死黑，缺乏细节；暗部伴随明显的噪点感。 右侧 (超级夜景 - On): 画面呈现惊人的数字纯净感与通透度。暗部细节被大幅度无损拉升，展现出细腻的建筑纹理；灯火锐利且无眩光，展现极高的动态范围 (Ultra HDR)。] 功能开关 (Toggle Switches): 左侧影像右下角： 放置一个药丸状开关，滑块居左，呈现深灰色。 右侧影像右下角： 放置一个激活态药丸状开关，滑块居右，呈现高饱和度的科技蓝色，并带有微弱的呼吸感发光。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 暗调环境光： 极简的暗室布光，背景无反光，确保视觉焦点完全集中在影像内部的灯火上。 色彩科学： 强化右侧影像的色彩深度（Deep Color），使其看起来更具沉浸感。] === HARD CONSTRAINTS (硬性限制) === DARK BACKGROUND: 全局背景必须为黑色，严禁使用浅色或白色背景。 BOTTOM 75% MAX FILL: 影像必须最大限度撑满下半部空间，间距必须窄且等距。 CLEAR CENTRAL DIVIDER: 两图之间必须有明确的垂直分割线。 IDENTICAL AERIAL VIEW: 左右构图必须 100% 对齐，展现宏大城市俯拍。 TOP 25% BLANK: 顶部必须预留 25% 的纯净深色空间。 NO PHONE FRAME: 严禁出现手机外壳或任何工业边框。 [Negative Prompt (负向提示词)]: (White background, light gray background, light gray top, phone frame, smartphone body, hand, large margins, mismatched alignment, no divider, daylight, elements in top 25% zone.)
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图文分离模式】整体布局采用纵向层级分区。顶部跨越垂直中轴线，由单一高字重文本区构成，呈水平居中对齐，确立全局视觉重心。下方视觉空间被均等划分为左右对称的矩形视觉轮廓，作为核心空间锚点。文本区域直接叠于背景之上，未关联独立背景框。信息流由顶部文本向下方主体延伸，通过显著垂直间距实现清晰分区。整体构图严格遵循中轴对称逻辑，下方双侧轮廓与顶部文本块形成稳定的视觉关联。布局排布去修饰化，完全依赖物理间距与对齐方式界定层级，体现了极简的工程化排布特征。

---

## selling_points: sj_12 AI智能换背景

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Environmental Background Replacement Comparison""] [Layout Type]: [""Maximum-Fill Dual Composition - Flat Design""] [Global Canvas Logic]: [ 纵向分区： 顶部 25% 区域设定为绝对纯净的浅灰色视觉留白（Negative Space），严禁任何像素侵入。 极大化填充： 主体影像单元必须从画布纵向 25% 处开始，向下完全撑满底部 75% 的区域。 等比例窄边距： 左、右、底三侧保留极窄且完全等距的边缘，确保画面布局严谨。 构图比例控制： 采用环境肖像构图（Environmental Portraiture）。人物在画面中的垂直占比控制在 50%-60% 左右。人物作为环境的点缀，侧重展示其周围宏大的背景空间。 平面化协议 (核心需求)： 影像单元与背景之间严禁出现任何阴影、投影、AO遮蔽或物理厚度感。影像单元应如同直接印在背景板上的平面图像。] === SECTION A (对比影像细节) === [Anchoring & Space]: [ 正面直视广角视角。 左右两张独立的矩形影像横向并排，中间仅保留极细的垂直缝隙。每张影像采用极小弧度的圆角。 无投影逻辑： 影像边缘清晰、干脆，与浅灰色背景交界处无任何光影过渡或阴影残留。 背景采用单张连续的无缝浅灰色（#F5F5F5）背景。] [Generic Subject Container]: [双帧环境重构影像单元。 Description: 展示一名欧美男子。他呈现全身或大半身姿态，穿着户外运动装束。他仅占据画面的中下部或偏侧位置，预留出大量展示背景的空间。 左右一致性： 人物姿态、服装、表情在左右图中必须 1:1 保持物理一致。 对比差异： 左侧影像: 模拟原始样片。背景为焦外虚化的海滨沙滩，细节模糊，色调较平。 右侧影像: 模拟 AI 背景替换。人物被精准置于宏大的雪山、针叶林或高山草甸中。背景锐利度极高，光影与人物边缘衔接完美。] [Material Physics]: [ 无文字协议： 画面内严禁出现任何文字、Before/After 标签或 UI 按钮。 纯净平面感： 影像表面呈现洁净的数字质感。严禁出现任何形式的接触阴影 (Strictly NO Contact Shadow / NO Drop Shadow)。影像边缘与背景背景完全共面。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 商业级高调均匀布光。利用漫反射光消除任何可能的阴影死角。确保左右两图在背景替换后依然保持全局光照逻辑的物理一致性。] === HARD CONSTRAINTS (硬性限制) === MAXIMIZED FILL: 影像必须最大限度撑满下半部 75% 的空间。 ENVIRONMENTAL SCALE: 人物比例缩小，确保背景展示空间占据主导地位。 STRICTLY NO TEXT: 严禁出现任何文字、字母或 UI 元素。 TOP 25% BLANK: 顶部必须保持 25% 的纯净负空间。 UNIFORM MARGINS: 左、右、底三边的间距必须绝对相等且极窄。 CAUCASIAN MALE: 模特为欧美男性，户外环境肖像。 STRICTLY NO SHADOWS: 严禁影像与背景之间产生任何投影、阴影或立体感。 [Negative Prompt (负向提示词)]: (Shadow, drop shadow, contact shadow, ambient occlusion, depth of field between card and background, 3D effect, text, labels, Before, After, Asian, female, close-up, large face.)
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图文分离模式】整体布局采用顶部居中对齐与双列对称逻辑。顶部视觉核心由加粗文本区构成，横跨垂直中轴线，确立一级层级。其下方对称分布两个半透明圆角矩形容器，作为二级层级，分别位于左右大型垂直背景视觉元素的正上方。这两个容器采用封闭几何形态，内部文本居中。构图以垂直中轴线为基准，划分为左右对等分区。文本容器与下方背景轮廓保持固定间距，形成明确归属。所有文本区均叠于背景之上，通过字重与框体建立视觉动线。底部两个大尺度元素作为锚点，支撑上方文本悬浮，结构严谨且重心稳定。

---

## selling_points: sj_13 AI支持多语言

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Cinematic Visual Dialogue - Enlarged Focus""] [Layout Type]: [""Integrated Bottom-Weighted Composition""] [Global Canvas Logic]: [ 去设备化协议： 严格禁止展示任何智能手机边框或物理外壳。 构图扩张 (核心修正)： 采用中景构图 (Medium Shot)。核心影像内容必须显著放大，占据并撑满画布底部 65% 的高度区域，确保主体形象清晰且具有视觉分量。 留白与连续性协议： 顶部 35% 区域保持纯净留白，但背景必须与下方内容无缝贯通 (Single seamless continuous image)。 空间动态： 人类与 AI 机器人之间保持舒适的交谈间距，眼神平视，表达和谐的沟通感。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 正面直视中景视角 (Frontal Medium Shot)。 主体人物（胸部以上构图）垂直锚定在画布最底端，向上延伸至 65% 处。视觉中心位于两者之间的光影衔接处。影像无物理边框，通过烟雾与深色渐变自然消融于背景。] [Generic Subject Container]: [超现实 AI 沟通交互视觉稿。 Description: (尺度校准) 画面展示一名人类女性与一个精密机械 AI 头像面对面沟通。主体尺寸需大幅填充画面下半部。AI 头部内部带有复杂的机械零件与琥珀色发光线路。 氛围： 温和的眼神交流，表达“连接与理解”。 Color & Trim: 经典的电影级冷蓝与琥珀金对比色调。人类皮肤纹理真实，机器人表面呈现细腻的抛光钛金属质感。] [Material Physics]: [ 光电效应： 琥珀色光晕（Bloom）需有足够的扩散范围，照亮人类面部及周围的空气感。 背景纹理： 背景的散景（Bokeh）和科技烟雾需充盈在整个 65% 的主体区域内，增强画面的饱满度。] [Environment]: [沉浸式暗色科技空间。背景由下方的影像区向上方留白区呈现极致平滑的深炭黑至曜石黑渐变。确保没有任何视觉断层，上方 35% 空间仅保留深邃的纯净黑色。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 电影级低反差布光。利用 AI 侧的琥珀色光源作为主光。光影覆盖协议： 光影必须充满下方的 65% 区域，使主体显得宏大且细节丰富，向顶部留白区渐进式消融。] === HARD CONSTRAINTS (硬性限制) === 65% SUBJECT FILL: 主体影像（含光影烟雾）必须饱满地占据底部 65% 的高度，严禁比例过小。 NO DEVICE: 严禁出现手机或屏幕轮廓。 BOTTOM ANCHORING: 主体底部边缘必须贴合画布最底端。 CONTINUOUS VISUAL: 顶部留白与下方影像背景完全贯通。 TOP 35% BLANK: 顶部必须预留 35% 的纯净负空间。 [Negative Prompt (负向提示词)]: (Small subject, tiny figures, high-angle view, phone frame, device border, split background, horizontal line, overlapping faces, elements in top 35% zone, redundant empty space at bottom.)
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图片叠底模式】整体布局采用垂直轴线对齐的顶部聚合结构。视觉重心位于上方，由两层文本区构成。顶端为高字重标题区，横跨中轴线对称分布；下方紧邻常规字重正文区，由多行文本块组成，维持中心对齐。文字区域直接叠置于背景视觉元素之上，无独立背景框。信息层级通过字重与间距划分，文本占位约占上方三分之一。布局简洁，通过中心对齐引导视觉动线自上而下延伸。

---

## selling_points: sj_14 支持5G

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Subject Mode]: [""Abstract Performance Hero""] [Layout Type]: [""Asymmetric Composition for Typography""] [Global Canvas Logic]: [ 构图锚定： 巨大的金属“5G”标志性符号被严格锚定在画布的右下角区域（约占 60% 空间）。 排版留白协议： 画布的左侧与顶部约 40% 的区域设定为绝对视觉留白（Negative Space），严禁任何复杂结构或光束侵入，确保背景极致纯净。 背景连续性： 全图采用一张无缝连续的深暗科技背景。从右下角的主体区向左上方的留白区呈现平滑、自然的色阶过渡，严禁出现任何地平线或物理分割感。] === SECTION A (主画面/全景) === [Anchoring & Space]: [ 极低角度侧平视（Extreme Low-angle Lateral View）。视角从地面向上仰望位于右侧的 5G 符号。背景呈现为深邃的体积暗空间，确保左上方区域拥有完美的文字对比度。] [Generic Subject Container]: [Monolithic Typography Architecture（符号建筑化）。 Description: (严格去手机化) 仅展示一个巨大的、具有厚重工业美感的“5G”金属字样。字体的几何轮廓锐利且厚实，完全依参考图为准。 Color & Trim: 符号主体采用深空灰钛金属（Space Gray Titanium）。发光逻辑： 仅限字体边缘的凹槽及缝隙内部透出**青蓝色（Cyan Blue）**的内生霓虹光，严禁向外喷射无规则的散射光束。] 金属质感： 主体表面呈现细腻的精密拉丝金属质感，切面带有镜面高光，反射出环境的冷峻调性。 地面特性 (核心)： 地面为平整且有质感的暗色岩土石（Flat Rocky Soil）。地表零星散落着几颗发光的青蓝色宝石（Gems），宝石捕获并折射符号发出的幽暗冷光。严禁地表出现杂乱的结晶丛或破碎背景。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [ 内生光源协议： 仅以“5G”符号内部的青蓝色内生光作为核心氛围光源，光线应被约束在字体几何形体内。 辅助照明： 极弱的冷色侧向轮廓光，为主体勾勒出锐利且干净的边缘。 严禁： 严禁出现杂乱的、向外延伸的长光束或不规则射线。] === HARD CONSTRAINTS (硬性限制) === POSITIONING: 5G 符号必须位于右下角，左侧和顶部保持净空。 FLAT GROUND: 地面必须是平整的岩石土质，点缀少量发光宝石。 INTERNAL GLOW ONLY: 光源仅在字体内部流动，严禁无规则散乱光束。 SEAMLESS BACKGROUND: 全局背景连贯，无地平线分割。 CYAN PALETTE: 统一使用青蓝色作为唯一发光色。 NO PHONE: 严禁展示任何手机机身。
- 图片1比例：{尺寸比例}  
- 参考图描述：无

**布局说明：**
【图片叠底模式】整体布局采用左侧边缘对齐的顶部加权结构。所有信息块集中于左上象限，严格位于垂直中轴线左侧。层级由四组视觉块构成：首行大字号加粗确立一级重心，下方紧随常规字重区域。第三层级通过增大字重再次引导视觉，底部由三行低字重区域垂直堆叠而成。文本直接叠放于背景视觉元素之上，无独立背景框容器。信息组块与画面右下方的产品轮廓锚点形成对角呼应，利用大面积留白与严谨的左对齐逻辑，建立了清晰的工程化视觉秩序。整体重心偏向左上，通过字重梯次引导视线流动，空间分区逻辑严谨且明确。

---