---
title: "掌上游戏机"
type: "reference"
---

# 掌上游戏机
## selling_points: zs_1 海量经典游戏库

**图片信息：**
- 图片1提示词：[fix]""Asset A: Main Visual (主视觉) [Layout Type]: [Unified Single Scene] === SECTION A (主画面/中下) === [Anchoring & Space]: [正面平视视角，请保持严格保持正面面对摄像机。掌上游戏机主体锚定在画面中下方（X:50%, Y:75%）。画面顶部约 40% 的区域预留为深邃的星空背景，作为极简留白区用于后期置入“20,000+ Games”等标题文字。] [Subject & Physics]: [掌上游戏机主体] [Environment]: [“游戏宇宙库”叙事环境。背景由成千上万个微小的、呈矩阵排列的虚拟游戏封面磁贴组成，这些磁贴构成一个巨大的圆弧形环绕阵列，向远方的星云深处延伸。背景最深处为带有淡蓝色星团与细碎星尘的数字深空。] [Evidence]: [功能的视觉证明。视觉句法 Type C [捕获]：背景中的游戏磁贴阵列呈现出向心性的透视汇聚，视觉上仿佛被吸入游戏机中心，以此物理逻辑证明设备对“22000+ 海量游戏库”的承载力。磁贴的边缘带有微弱的自发光效果，为游戏机顶部勾勒出一层冷色调的轮廓光。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [戏剧化的“数字星系”采光。主光源来自于背景海量磁贴阵列的综合漫反射，呈现出高冷的科技蓝调。环境光极低，强调游戏机质感] [Physics Engine]: [强制执行 Type A [清晰度提升]。背景中每一个微小的游戏磁贴虽模糊处理但需保留物理厚度感；游戏机材质需达到工业级渲染精度。掌机渲染图以参考图为准]""
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图片叠底模式】整体布局呈垂直居中对称分布。顶部跨越垂直中轴线，由加粗标题与多行常规字重文本构成，均采用中心对齐逻辑。中部包含特大字重的视觉文本块，直接叠放于背景视觉元素上方。底部水平排列四个白色半透明胶囊型容器，承载正文短语，其位置严格对称并处于产品轮廓下方。视觉层级由顶部的聚合区向下引导，通过字重差异区分信息主次。所有文字区域与背景保持清晰的叠层关系，底部容器通过几何形态实现功能分区，整体呈现工程化的规整感。

---

## selling_points: zs_2 大容量电池

**图片信息：**
- 图片1提示词：[fix]""Asset A: Main Visual (主视觉) [Layout Type]: [Unified Single Scene] === SECTION A (主画面/正中) === [Anchoring & Space]: [正面直视视角。通用掌上游戏机主体位于画面中下方 (X:55%, Y:60%)。画面顶部约 40% 区域保持纯净的黑色渐变背景，作为极简留白区用于后期置入“Long Battery Life”及“1800mAh”等标题文本。底部预留约 15% 空间用于后期排版功能参数。] [Subject & Physics]: [掌上游戏机。遵循[去品牌化][规则] 电子屏幕渲染为“未激活/黑屏”状态，表面呈现高反光的镜面黑色，反射出环境中的微弱技术光条。] [Environment]: [数字技术演播室环境。背景是黑色纯色背景，空间中漂浮着透明度很低的抽象的、具有流动感的深蓝色发光纤维线条，营造出速度感与能量流动的氛围。] [Evidence]: [功能的视觉证明。视觉句法 Type C [能量捕获]：背景中的透明度很低的蓝色发光线条呈现出向机身汇聚的趋势。机身左侧与悬浮电池（Asset B1）相邻的边缘捕捉到了显著的绿色环境漫反射光，证明了能量源对硬件的逻辑补给。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高对比度的商业产品采光。主光源为来自侧方的冷白光，勾勒出机身圆润的物理轮廓。环境光由背景的红蓝渐变色提供基调，并在机身表面产生细腻的色彩映射。] [Physics Engine]: [强制执行 Type A [清晰度提升]。机身塑料的细微磨砂质感、按键的物理行程缝隙以及屏幕边缘的倒角需达到 8K 物理级解析力。掌机以参考图为准] Asset B Series: Floating Details (独立插图系列) [Coherence Strategy]: [主题和谐模式。共享“高能绿色光效”，角度适配侧面悬浮构图。] Asset B1 [Full View Spec (No Shape Desc)]: [高科技能量电池单元的 3/4 侧视视角。电池呈现为透明的钢化玻璃圆柱容器，内部充满流动的、具有生物质感的绿色自发光液体或等离子体。] [Full Lighting & Texture Spec]: [玻璃容器表面具有极强的镜面高光和环境折射效果。内部绿色能量发出强烈的“叙事性体积光”，光线在玻璃内壁产生多次反射，并在容器顶部的金属盖处产生锐利的折射。] [Content Filling Canvas]: [能量电池垂直悬浮在画面左侧 (X:15%, Y:60%)，通过内部液体的翻腾与剧烈的绿色光辐射，视觉化证明其“1800mAh”的物理储能密度。]""
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图文分离模式】整体布局采用垂直三段式结构。顶部区域由两层加粗文本构成，配有水平实线装饰，整体在中轴线两侧对称分布。中部视觉层包含一个斜向排布的大体量文本块，作为背景层级置于产品轮廓后方。底部区域通过垂直分割线划分为三个等宽的对称扇区，每个扇区内信息呈垂直堆叠分布：顶端为一个高不透明度的圆角矩形背景框，下方紧跟高字重的主信息区与低字重的副文本区。所有文本均在各自扇区内中心对齐，形成了清晰的参数化对齐逻辑。信息层级通过字号差异与字重对比实现，将视觉重心从顶部的声明性区域引导至底部的结构化数据分区，与中心产品轮廓形成严谨的包裹式布局。

---

## selling_points: zs_3 人体工学设计

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Layout Type]: [Unified Single Scene] === SECTION A (主画面/右侧) === [Anchoring & Space]: [3/4 后视角（Rear Perspective）。主体锚定在画面右侧 (X:70%, Y:50%)。画面左侧约 45% 的空间为带有动态模糊的深紫色赛博科技背景，作为极简的负空间预留给后期排版。] [Subject & Physics]: [通用掌上手持游戏机。遵循[去品牌化] [Environment]: [抽象赛博朋克虚空。背景充斥着高饱和度的紫色、深蓝色霓虹光晕，并带有轻微的数字化颗粒感。] [Evidence]: [功能的视觉证明。视觉句法 Type C [捕获/贴合]：通过四组从背部按键向下延伸的、具有物理体积感的金黄色叙事性流光（替代原图扁平箭头），光条紧贴握把的曲线轮廓向下流动，在接触机械手指处产生微弱的物理漫反射。这种流线逻辑视觉化证明了“人体工学弧形握把”与手掌的物理契合度，以及操作的瞬时响应感。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高对比度的赛博霓虹环境光。主光源为来自背景的粉紫色漫反射光，并在半透明机身及黑色机械手的关节边缘形成锐利的紫色轮廓光（Rim Light）。金黄色叙事光作为物理功能证据，真实照亮了按键的物理行程缝隙。] [Physics Engine]: [强制执行 Type A [清晰度提升]。半透明壳体的折射率、机械手关节的金属/哑光材质对比、以及按键的行程质感需达到物理级解析力。画面严格去噪，禁止出现任何原始文本、UI 文本框或 Logo。]
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图片叠底模式】整体布局呈现左侧信息聚合、右侧视觉锚点的非对称分区。视觉重心位于垂直中轴线左侧。顶部为两行高字重文本区，呈左对齐排列，直接浮于背景之上。中下部偏左区域纵向堆叠两个半透明矩形容器，容器边框具几何形态，内嵌常规字重文本块，均严格左对齐。所有纯文字容器均位于产品轮廓侧方。空间层次由顶部大尺寸文本向下级容器递进，通过容器化处理形成独立信息分区，与右侧视觉元素形成水平向的空间对位。

---

## selling_points: zs_4 高清IPS屏幕

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Layout Type]: [Unified Single Scene] === SECTION A (主画面/左/下) === [Anchoring & Space]: [仰视特写视角。通用掌上游戏机主体位于画面左下部，锚定于 (X:50%, Y:65%)，机身呈 30 度角向右上方倾斜。画面顶部约 50% 的空间延续下方的暗色调数字纹理。] [Subject & Physics]: [通用垂直结构掌上游戏机。机身有外壳，侧边物理按键与侧面细节清晰可见。[规则] 电子屏幕渲染为参考图] [Environment]: [高科技数字实验室背景。空间充斥着垂直落下的紫色与粉色数字化流光颗粒，光点呈现出高频率的闪烁感，背景基调为极深紫色。] [Evidence]: [功能的视觉证明。视觉句法 Type B [改变/净化]：在熄灭的黑屏上方约 5mm 处，悬浮着一个由青蓝色“叙事性体积光”构成的半透明矩形发光框架。该框架具有物理厚度感，边缘产生柔和的霓虹晕染，并真实地照亮了下方屏幕的边缘倒角。该发光物理结构代替了原图的扁平文字，视觉化证明了“3.5 英寸”及“IPS 全贴合”屏幕的物理边界与通透度。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高对比度的数字科技感采光。主光源为来自侧方的霓虹色，在机身侧面勾勒出锐利的高光边；环境光采用低饱和颜色，以突出框架的亮度和物理真实感。] [Physics Engine]: [强制执行 Type A [清晰度提升]。屏幕玻璃边缘的 R 角曲率、物理按键的防滑纹理、以及 TF 卡槽内部的微观深度需达到工业级渲染精度。严格剔除所有原图中的文本、勾选框、UI 图标以及屏幕内显示的赛车游戏画面。]
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图片叠底模式】Overall layout features a dual-zone vertical distribution. The primary text zone occupies the upper third, spanning the vertical axis with a centered, horizontal alignment. It is positioned directly against the background visual element without a physical container. Below, a secondary text zone is enclosed within a three-dimensional, high-transparency geometric wireframe container. This container is tilted and positioned centrally relative to the product contour's screen area, creating a perspective-driven depth. The text within this container is aligned with its isometric axes, establishing a specialized focal point. Visual hierarchy is established through a scale-based approach, with the top section serving as the structural anchor. Information partitioning is clearly divided between a flat header region and a floating, depth-oriented callout region. The layout maintains a centralized balance while utilizing a layered depth strategy to distinguish primary information from secondary focal points, strictly segregating all textual areas from the internal interface and functional elements of the product contour. This engineering-focused layout optimizes depth perception and information prioritization.

---

## selling_points: zs_5 适用于多种场合的礼物

**图片信息：**
- 图片1提示词：[fix]Asset A: Main Visual (主视觉) [Layout Type]: Symmetrical 2x2 Grid Collage with Center Focus (对称田字形四宫格 + 中心悬浮主体) === GLOBAL ENVIRONMENT (全局排版框架 - 解决乱入黑块问题) ===[Grid Structure]: 画面下方的 80% 区域被严格分割为“2x2 的田字形四宫格 (2x2 symmetrical grid)”。每个格子都有极其清晰的蓝色粗边框 (Thick blue rounded borders) 作为物理隔离线。 [Top Negative Space]: 画面顶部的 20% 区域是**完全贯通的、深蓝色的纯净渐变背景 (Clean deep blue gradient background)**。 [强制防噪]: **绝对禁止**在画面中心或顶部生成任何黑色的方块、文字、字母或 UI 标签。顶部只保留纯净的深蓝色，作为天然的排版留白。 === THE CENTER HERO (中心悬浮主角) === [Anchoring & Space]: 绝对居中锚定 (X:50%, Y:50%)。 [Subject & Physics]: 一台竖版的**紫色复古掌上游戏机 (Purple vertical retro handheld console)**。 * **空间关系**: 它像一个 3D 物体一样，**直接悬浮、覆盖在四个网格的中心交叉点正上方 (Overlapping the center cross)**，挡住了一部分网格的边框。 * **细节特征**: 屏幕点亮，显示一辆酷炫的 3D 紫色跑车。底部的两个摇杆带有发光的彩虹色 RGB 灯圈 (Glowing RGB rainbow rings)。 === THE 4 PANELS (四象限独立场景 - 强制概念隔离) === [Constraint]: 四个视窗内的场景**绝对相互独立，严禁元素跨界融合**。 * **[Top Left - 圣诞]**: 景深镜头。背景为模糊的发光圣诞树。一名父亲微笑着将一个打开的红色礼盒递给男孩，盒子里装着紫色的掌机。 * **[Top Right - 生日]**: 景深镜头。背景有彩色的派对三角旗。一名金发少年充满惊喜地打开一个天蓝色的方形礼盒，盒子上带有星球贴纸。 * **[Bottom Left - 浪漫]**: 居家环境。一位短发女性坐在灰色沙发上，从背后用手蒙住男性的眼睛，准备给他惊喜。 * **[Bottom Right - 日常]**: 第一人称俯视特写。一双手正在解开一个带有深蓝色丝带的精致方形礼盒，展示内部的高级海绵衬垫。 === GLOBAL SETTINGS (全局设置) === [Lighting]: 复合布光。中心掌机采用明亮锐利的影棚光（突出 RGB 灯效与塑料质感）；四个背景网格内采用温暖的室内生活漫反射光（Lifestyle warm lighting）。全焦段清晰。
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图文分离模式】整体布局采用【顶部居中主标题 + 四角悬浮胶囊标签】的结构。
1. 【主标题区】：位于画面最顶部的深色负空间。采用极大字号、加粗（Bold）字重、全大写字母。文本水平完全居中（Center-Aligned），横向舒展贯穿画面顶部。无任何背景框，文字直接反白浮于背景之上。
2. 【四象限副标题区（胶囊标签）】：在中下部的四个图片网格内，分别嵌入四个独立的“胶囊形文本容器 (Pill-shaped Text Badges)”。容器具有纯色的高对比背景（如亮蓝色底+白色文字），带有明显的圆角，像 UI 按钮一样悬浮在图片图层之上。
3. 【标签对齐逻辑】：严格遵循网格的物理边界进行锚定。
- 左上角网格的标签：紧贴该网格的左上角内侧。
- 左下角网格的标签：紧贴该网格的左上角内侧。
- 右上角网格的标签：紧贴该网格的右上角内侧。
- 右下角网格的标签：紧贴该网格的右上角内侧。
整体形成外发散式的平衡视觉锚点，信息层级清晰，完全还原电商场景图例的排版规范。

---

## selling_points: zs_6 轻巧便携

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Layout Type]: [Split-Screen] === SECTION A (主画面/收纳动作) === [Anchoring & Space]: [中远景视角。主体（手持掌机的手）锚定在画面中心偏右侧 (X:65%, Y:60%)。画面顶部 20% 的区域采用深蓝色至黑色的数字化渐变留白，作为负空间预留给后期排版需求。]严格控制不要出现任何文字 [Subject & Physics]: [通用掌上游戏机。遵循[去品牌化]一只写实的手正将设备斜向滑入深蓝色牛仔裤口袋内。[规则] 电子屏幕渲染为“未激活/黑屏”状态，表面呈现出高反射率的黑色镜面效果，映射出环境中的微弱自然光。] [Environment]: [特写牛仔面料环境。背景为深蓝色粗颗粒牛仔布纹理，口袋边缘的缝线细节清晰可见。] [Evidence]: [功能的视觉证明。物理交互：口袋边缘布料因设备滑入而产生的拉伸褶皱与张力，真实证明了掌机纤薄且符合口袋尺寸的物理特征。设备侧边勾勒出的一道冷白光边缘（Rim Light），强调了其紧凑的廓形。] === SECTION B (场景浮层/应用演示) === [Relation Check]: [同一设备在不同收纳环境下的应用延时。] [Anchoring & Space]: [底部左右各分布一个圆形浮窗。左侧浮窗位于 (X:15%, Y:85%)，右侧浮窗位于 (X:45%, Y:85%)。] [Subject & Physics]: [对比动作展示。左侧浮窗：手将掌机放入浅色软质收纳包；右侧浮窗：掌机平放在折叠整齐的蓝色棉质衬衫与黑框眼镜旁。] [Evidence]: [对比结果。通过不同生活化容器（包袋、衣物）的物理尺度对比，共同建立“便携”与“轻量化”的叙事链条。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高动态范围（HDR）自然光摄影。模拟室外自然采光，光影在机身与牛仔布料上产生细腻的漫反射。重点突出屏幕表面的镜面高光，以确立其物理级玻璃材质感。] [Physics Engine]: [强制执行 Type A [清晰度提升]。牛仔布的纤维纹理、手部皮肤的毛孔细节、以及机身边缘的磨砂颗粒感需达到 8K 物理级解析力。严禁出现任何原始文字标题、UI 元素或屏幕内的赛车画面。] Asset B Series: Floating Details (独立插图系列) [Coherence Strategy]: [模式B：主题和谐。共享“掌机设备”与“生活化收纳”视觉 DNA。] Asset B1 [Full View Spec (No Shape Desc)]: [圆形构图特写。手部将掌机滑入白色超细纤维收纳袋的瞬间。] [Full Lighting & Texture Spec]: [明亮扩散的柔光。收纳袋表现出柔软的织物起伏质感，与机身的硬质光影形成对比。] [Content Filling Canvas]: [收纳动作填满圆形画幅，展示设备与便携配件的物理兼容性。] Asset B2 [Full View Spec (No Shape Desc)]: [圆形构图平铺展示。掌机斜放在一件折叠的深蓝色牛仔衬衫上方，旁边配有一副黑框树脂眼镜。] [Full Lighting & Texture Spec]: [顶置柔和聚光灯。衬衫的斜纹组织与眼镜片的通透折射细节清晰，光线在掌机黑屏上产生一道斜向的高光带。] [Content Filling Canvas]: [旅行平铺（Flat Lay）叙事填满圆形画幅，视觉化其作为“旅行伴侣”的轻量化卖点。]
- 图片1比例：{尺寸比例}
- 参考图描述：商品主图

**布局说明：**
【图片叠底模式】整体布局采用顶部居中对齐逻辑，重心位于画面上部。文本区域跨越垂直中轴线，由双层级视觉块构成：顶层加粗建立一级重心，底层字重略轻形成视觉引导。文本直接叠于背景元素之上，未设独立背景容器，与下方产品轮廓及手势形成垂直堆叠关系。底部圆形容器不含纯文字块。整体构图呈倒三角形，上部宽大居中，通过层级差异引导视觉向下聚焦产品核心区，分区逻辑清晰且排布简洁。

---

## selling_points: zs_7 芯片/ CPU

**图片信息：**
- 图片1提示词：Asset A: Main Visual (主视觉) [Layout Type]: [Unified Single Scene] === SECTION A (主画面/正中) === [Anchoring & Space]: [3/4 俯视透视视角。通用高性能处理器芯片锚定在画面中心 (X:50%, Y:55%)。画面顶部 30% 区域保持纯净的深黑色背景，结合极简的数字化颗粒感，预留为“PROFESSIONAL GAMING CHIP”标题的排版留白空间。] [Subject & Physics]: [通用高性能游戏处理器（CPU）。处理器由多层物理结构堆叠而成：底层为精密的银色金属引脚阵列，中层为黑色高密度集成电路基板，顶层为具有拉丝纹理的深灰色金属散热顶盖。遵循[卖点与去噪]规则：剔除顶盖上所有特定型号文字，保持金属材质的纯净物理表现。] [Environment]: [宏观数字电路板景观。芯片底座嵌入一个巨大的、具有复杂几何凹槽的黑色母板环境。周围布满了由发光线条构成的逻辑电路路径，路径呈现出深蓝色与冷青色的霓虹质感。] [Evidence]: [功能的视觉证明。视觉句法 Type C [能量捕获]：母板上的逻辑电路路径被渲染为“叙事性体积光”，呈现出向心性的脉冲发光效果，能量流仿佛正在由四周向芯片底座汇聚。芯片底部的引脚被这些蓝光真实地照亮，产生锐利的镜面高亮和蓝色环境溢色，视觉化证明处理器作为“Smart Core”的高速运算能力与能量密度。] === GLOBAL SETTINGS (全局设置) === [Lighting]: [高对比度、戏剧性的数字科技感采光。主光源由电路路径的自发光（蓝色/青色）组成，环境光设定为极低，以强调金属盖与电路板之间的材质深度。芯片边缘受光形成明显的物理轮廓线。] [Physics Engine]: [强制执行 Type A [清晰度提升]。处理器的引脚微观纹理、顶盖的金属拉丝纹理以及母板的几何切割边缘需达到物理级解析力。全画面应用“位置保真”协议，严禁出现任何扁平 UI 图标、文字标签或 Logo。]
- 图片1比例：{尺寸比例}
- 参考图描述：无

**布局说明：**
【图片叠底模式】整体布局采用垂直中轴线对齐逻辑，视觉重心分布于顶部及中心区域。顶部信息跨越垂直中轴线，由高字重的主标题区与常规字重的多行副标题区构成，呈中心对齐排布。正中位置包含一个矩形纯文字背景框，该框体直接叠加于产品轮廓视觉元素之上，具有极高的视觉优先级。文字区域直接叠于背景或特定框体内，未跨越两侧边缘。整体分区明确，通过顶部居中聚合与中心锚点式排布，形成了清晰的由上至下的视觉引导层级，空间分布严格遵循轴对称原则，体现了均衡、稳定的工程化布局特征。