# 电商详情页设计专家

- 文件夹名：`05-电商详情页设计专家__detail-page-assistant__aTubijhXog`
- publicId：`aTubijhXog`
- name：`detail-page-assistant`
- 分类：未标注
- 版本：352
- 更新时间：2026-06-16T06:55:23.000+00:00
- 来源：https://d.design/api/agent/v1/skills/aTubijhXog

## 能干什么

用户只需输入商品相关内容，即可自动完成详情页的结构规划与视觉设计输出，覆盖卖点提炼、版块布局、视觉呈现等核心环节，帮助商家与设计师快速交付高质量的电商详情页方案。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
