# 小红书营销专家

- 文件夹名：`09-小红书营销专家__xhs-ai-assistant__gu2YNfJE3N`
- publicId：`gu2YNfJE3N`
- name：`xhs-ai-assistant`
- 分类：未标注
- 版本：17
- 更新时间：2026-06-16T01:43:41.000+00:00
- 来源：https://d.design/api/agent/v1/skills/gu2YNfJE3N

## 能干什么

全面覆盖小红书社媒运营中的多维度营销与设计能力，包括账号定位、笔记文案、封面设计、合规校验、账号诊断、广告投放分析、战略定位和变现规划等。用户可以从0开始设计起号运营方案，也可以生成一套完整的笔记发布方案，此外还支持用户上传笔记内容或视频进行评估分析与合规校验，制定后续的运营策略或广告投放策略。

## 文件说明

- `SKILL.md`：该 Skill 公开详情接口返回的主 prompt/content，标准命名。
- `content.md`：同内容备份。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
