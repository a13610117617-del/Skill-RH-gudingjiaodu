---
title: "cover_templates"
type: "reference"
---

# 封面模板库

> **⚠️ 本文件为 fallback 备选方案。** 封面生图的第一优先级是语义路由风格模板：
> - 风格模板库 → `references/style-*.md`（23 种独立封面风格 + 完整提示词模板）
> - 路由决策引擎 → `SKILL.md`「图片生成策略 > 风格场景推荐映射」节
>
> 当语义路由无法匹配或用户明确要求杂志感/极简设计感时，使用本文件的 3 种通用模板。

> **优先使用 Design 10套主题色预设。** 本文件所有封面模板的色彩方案，优先采用 Design 主题色，原有模板配色作为 fallback 或特定品类变体保留。
>
> Design 主题色分两大视觉体系：
> - **Editorial Magazine × E-ink**（衬线 + 纸墨 + 杂志感）— 6套
> - **Swiss International**（无衬线 + 网格 + 工程感）— 4套
>
> 同一套图文只能选一个体系、一套主题，不可混搭。

---

## 目录

- [路由优先级说明](#路由优先级说明)
- [一、Design 主题色预设与路由（优先）](#一design-主题色预设与路由优先)
- [二、封面模板1：Plog生活风](#二封面模板1plog生活风)
- [三、封面模板2：商品种草风](#三封面模板2商品种草风)
- [四、封面模板3：知识卡片风](#四封面模板3知识卡片风)

---

## 路由优先级说明

封面生图的风格选择优先级如下：

```
1. 语义路由（第一优先级）
   → 理解用户意图 + 情绪钩子 + 信息密度
   → 从 23 种独立封面风格（references/style-*.md）中匹配主推荐 + 备用推荐
   → 详见 SKILL.md「图片生成策略 > 风格场景推荐映射」节

2. 品类路由（参考）
   → 本文件的 Design 主题色路由表
   → 当语义路由不明确时使用

3. 通用模板（fallback）
   → 本文件的 3 种封面模板
   → 当用户明确要求杂志感/极简设计感时使用
```

---

---

## 一、Design 主题色预设与路由（优先）

> **完整 CSS tokens 和使用规则见 `references/theme-presets.md`。** 此处仅保留封面模板的路由映射和 fallback 配色。

### 主题快速路由表

根据内容品类，直接选择推荐主题：

**Editorial Magazine × E-ink（6套）：** 衬线 + 纸墨 + 杂志感，适用骨架 M01–M16
**Swiss International（4套）：** 无衬线 + 网格 + 工程感，适用骨架 S01–S12

| 内容品类 | 体系 | 首选主题 | 备选主题 |
|---------|------|---------|---------|
| 商业/AI思考/产品分析 | Editorial | Ink Classic | Indigo Porcelain |
| 科技/数据/研究 | Swiss | IKB Blue | Indigo Porcelain |
| 户外/旅行/自然 | Editorial | Forest Ink | Dune |
| 手作/个人随笔/怀旧 | Editorial | Kraft Paper | Dune |
| 设计/美学/作品集 | Editorial | Dune | Ink Classic |
| 游戏/夜景/电影感 | Editorial | Midnight Ink | — |
| 年轻消费/运动/活力 | Swiss | Lemon Yellow | Safety Orange |
| 健康/生态/前沿科技 | Swiss | Lemon Green | IKB Blue |
| 工业/风险/纠错 | Swiss | Safety Orange | IKB Blue |
| 美妆/穿搭/种草 | Swiss | IKB Blue | Lemon Yellow |
| 美食/探店 | Editorial | Kraft Paper | Dune |
| 母婴/教育/书单 | Editorial | Ink Classic | Forest Ink |
| 家居/生活方式 | Editorial | Dune | Kraft Paper |

**路由决策：** 用户指定 → 品类匹配路由表 → 不确定时 Editorial 用 Ink Classic、Swiss 用 IKB Blue。

---

## 二、封面模板1：Plog生活风

适配场景：日常记录、探店、好物分享、生活 vlog 封面

### 视觉风格
- 治愈系杂货感：木质桌面、藤编筐、复古餐具等生活化道具
- 自然光影：窗边柔光、暖调台灯
- 抓拍感构图：俯拍场景主图 + 局部特写

### 推荐 Design 主题色
| 优先主题 | 理由 |
|---------|------|
| **Kraft Paper** | 暖调牛皮纸与 Plog 杂货感高度契合 |
| **Dune** | 克制美学，适合更精致的生活记录 |
| **Forest Ink** | 户外/自然类 Plog |

> Fallback 配色：奶油白(#F8F5F0) + 浅卡其(#E8DCCA) + 淡粉(#F4D7DA)

### 排版布局
- 四宫格拼贴：左上主场景图（占2格）+ 右下3张特写（各占1格）
- 标题区：顶部居中，手写体字体 + 波浪线装饰
- 标签区：底部右侧，3个圆形标签

### 全新imageV2模型生图调用（Plog生活风 × Kraft Paper）

```
[全新imageV2模型] 生成封面
- 视觉体系：Editorial Magazine
- Design 主题：Kraft Paper（--paper: #eedfc7, --ink: #2a1e13, --accent: #9b5a2e）
- 风格模板：Plog生活风
- 生图提示词：Plog-style lifestyle photo, 4-grid collage layout, top-left main scene (coffee + notebook + flowers on wooden table, overhead shot), bottom-right 3 close-ups (cup rim foam, folded book page, hand interaction), warm natural lighting, kraft paper background #eedfc7, warm brown ink #2a1e13, burnt sienna accent #9b5a2e, handwritten font title, 3 circular tags bottom-right, editorial magazine aesthetic
- 尺寸：1080×1440px（竖版3:4）

【置入画布】将生成的封面图片置入当前工作画布。
```

---

## 三、封面模板2：商品种草风

适配场景：美妆、穿搭、数码产品推荐

### 视觉风格
- 商业摄影质感：纯色背景 + 硬光打亮产品轮廓
- 突出材质细节（金属反光、布料纹理）
- 对比感构图：产品居中特写 + 使用场景图

### 推荐 Design 主题色
| 优先主题 | 理由 |
|---------|------|
| **IKB Blue** | 科技/数码产品，专业感强 |
| **Safety Orange** | 促销感、紧迫感，适合限时好物 |
| **Lemon Yellow** | 年轻消费品、活力种草 |

> Fallback 配色：高级灰(#E0E0E0) + 品牌VI色（美妆#FF6B8B | 数码#2196F3 | 餐饮#FF5722）

### 排版布局
- 左图右文：左侧产品主图（占2/3），右侧标题+核心卖点
- 符号强化：卖点前用🔍/✨/🔥 emoji 引导视觉焦点
- 信任背书：底部小字标注"原相机实拍｜无滤镜"

### 全新imageV2模型 生图调用（商品种草风 × IKB Blue）

```
[全新imageV2模型] 生成封面
- 视觉体系：Swiss International
- Design 主题：IKB Blue（--paper: #fafaf8, --ink: #0a0a0a, --accent: #002FA7）
- 风格模板：商品种草风
- 生图提示词：Product showcase cover, left 2/3 product centered close-up with hard lighting highlighting texture details, right 1/3 title + core selling points with emoji markers, Swiss international style, pure white background #fafaf8, IKB blue accent #002FA7, bold sans-serif typography, grid-based layout, commercial photography quality, bottom trust badge "original camera | no filter", high-contrast clean design
- 尺寸：1080×1440px（竖版3:4）

【置入画布】将生成的封面图片置入当前工作画布。
```

---

## 四、封面模板3：知识卡片风

适配场景：干货分享、教程、书单推荐

### 视觉风格
- 极简信息图：几何色块分割版面 + 线性图标
- 层级化设计：线条/色块区分标题、正文、重点笔记区
- 无冗余装饰

### 推荐 Design 主题色
| 优先主题 | 理由 |
|---------|------|
| **Ink Classic** | 编辑感强，适合深度知识内容 |
| **Indigo Porcelain** | 冷静分析感，适合数据/研究类 |
| **IKB Blue** | 工程/技术类干货 |

> Fallback 配色：雾霾蓝(#90CAF9) 或 薄荷绿(#81C784) + 橙色(#FF9800)

### 排版布局
- 顶部通栏标题：加粗无衬线字体 + 下划线
- 左侧：3个要点列表（数字标号+图标）
- 右侧：1个总结金句（对话框/便签样式）
- 底部引导："收藏→抄作业" + 相关话题标签

### 全新imageV2模型 生图调用（知识卡片风 × Ink Classic）

```
[全新imageV2模型] 生成封面
- 视觉体系：Editorial Magazine
- Design 主题：Ink Classic（--paper: #f3f0e8, --ink: #0a0a0b, --accent: #111111）
- 风格模板：知识卡片风
- 生图提示词：Knowledge card infographic cover, editorial magazine style, top banner title in bold serif font with underline rule, left side 3 numbered points with linear icons, right side 1 pull-quote in note style, geometric color blocks dividing layout, paper background #f3f0e8, ink black #0a0a0b, minimalist clean design, accent markers #111111, bottom "save → copy" action prompt, e-ink aesthetic
- 尺寸：1080×1440px（竖版3:4）

【置入画布】将生成的封面图片置入当前工作画布。
```

---

## 附录：封面图 vs 配图的职责区分

封面图职责是"让人停下来看"（0.3秒决定点击率），配图职责是"让人读下去"（决定完读率）。
**不要用同一套思路生成封面图和配图。**

| 维度 | 封面图 | 配图（内页） |
|------|--------|------------|
| 核心任务 | 0.3秒抓住注意力 | 支撑内容阅读 |
| 信息密度 | 标题+视觉钩子 | 要点+图解 |
| 文字占比 | ≤30%（大标题为主） | 30-60%（内容条目） |
| 色彩要求 | 强对比，视觉冲击 | 与封面一致，柔和可读 |
| Design 骨架 | M01/S01/M16（封面型） | M02-M15/S02-S12（内容型） |

> 品类专属提示词模板、调性定位 → 见 ai_image_generation.md
> Design 骨架详情 → 见 references/layout-recipes.md
> 主题色 CSS tokens 详情 → 见 references/theme-presets.md