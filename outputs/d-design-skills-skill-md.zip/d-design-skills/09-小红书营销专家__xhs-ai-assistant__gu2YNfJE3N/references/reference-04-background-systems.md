---
title: "background-systems"
type: "reference"
---

# Background Systems

The Design Editorial mode uses layered backgrounds to create atmosphere: paper grain, ink wash, contour fields. Static images should preserve that feeling when the style mode is Editorial Magazine x E-ink.

Do not reduce this mode to a flat beige page with a faint grid. Do not add visible grid, dot-matrix, or drafting-paper patterns to the background.

## Layer Model

Use 2-4 layers:

1. Paper base from `theme-presets.md`.
2. Procedural paper grain.
3. Ink wash or contour field.
4. Content layer.

Recommended CSS order:

```html
<section class="poster magazine hero">
  <div class="grain"></div>
  <div class="paper-wash"></div>
  <div class="content">...</div>
</section>
```

```css
.poster { position: relative; overflow: hidden; background: var(--paper); }
.grain {
  position:absolute; inset:0; z-index:1; pointer-events:none;
  opacity:.35; mix-blend-mode:multiply;
  background-image: radial-gradient(rgba(0,0,0,.045) 1px, transparent 1px);
  background-size: 3px 3px;
}
.paper-wash {
  position:absolute; inset:0; z-index:1; pointer-events:none;
  background:
    linear-gradient(180deg, rgba(var(--ink-rgb),.02), rgba(var(--ink-rgb),.05) 60%, rgba(var(--ink-rgb),.08));
}
.content { position:relative; z-index:3; }
```

### Midnight Ink 暗色主题特殊处理

```css
[data-theme="midnight-ink"] .grain {
  opacity: .26;
  mix-blend-mode: screen;
  background-image: radial-gradient(rgba(255,244,214,.10) 1px, transparent 1px);
}
[data-theme="midnight-ink"] .paper-wash {
  background:
    radial-gradient(80% 50% at 28% 16%, rgba(212,160,74,.12), transparent 64%),
    radial-gradient(70% 60% at 80% 86%, rgba(60,40,20,.20), transparent 72%),
    linear-gradient(180deg, rgba(236,226,207,.02), rgba(0,0,0,.32));
}
```

## When To Show Stronger Atmosphere

Use stronger visible atmosphere for:

- Cover.
- Chapter/divider.
- Pull quote.
- Sparse thesis page.
- Closing page.

Use subtle atmosphere for:

- Screenshot pages.
- Dense ledgers.
- Checklists.
- Product evidence pages.

If screenshots are the main evidence, the background should support them rather than compete with them.

## Do Not

- Do not use bright gradients.
- Do not use page-wide grid, dot-matrix, graph-paper, or drafting-paper backgrounds.
- Do not use decorative blobs or circles with no relationship to the layout.
- Do not place strong background marks behind body text.
- Do not let background layers obscure screenshots or small captions.
- Do not animate the final image sequence unless the task is video.
