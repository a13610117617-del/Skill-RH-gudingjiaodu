---
title: "CPU散热器提示词模板"
type: "reference"
---

# CPU散热器 提示词模板

**来源:** 第3行

```json
{
  "sellingPoints": []
}
```
