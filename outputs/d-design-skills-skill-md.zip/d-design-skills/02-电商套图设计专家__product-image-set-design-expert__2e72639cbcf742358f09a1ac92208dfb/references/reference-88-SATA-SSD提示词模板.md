---
title: "SATA SSD提示词模板"
type: "reference"
---

# SATA SSD 提示词模板

**来源:** 第17行

```json
{
  "sellingPoints": []
}
```
