---
title: "车载摄像头卖点列表"
type: "reference"
---

# 车载摄像头 卖点列表

**来源URL:** `http://autolayout.oss-cn-beijing.aliyuncs.com/visual_reverse_results%2F20260413_165430_%E5%8D%96%E7%82%B9%E5%88%97%E8%A1%A8.md?OSSAccessKeyId=LTAI5t8AyMKpMrXtvsvNoo8d&Expires=2091430471&Signature=%2FIX%2BzHPVi%2FbyjOjKRv8Lnm228MQ%3D`

**来源:** 第13行

---

# 卖点列表

1. 安装简易
2. 自动录制
3. 触摸屏
4. 4K摄像头
5. 高速无线传输
6. 循环录影
7. GPS记录
8. 内置存储
9. 直连供电
10. 耐用耐高低温无污染