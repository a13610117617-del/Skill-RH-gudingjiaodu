# 电商套图设计专家

- 文件夹名：`02-电商套图设计专家__product-image-set-design-expert__2e72639cbcf742358f09a1ac92208dfb`
- publicId：`2e72639cbcf742358f09a1ac92208dfb`
- name：`product-image-set-design-expert`
- 分类：未标注
- 版本：177
- 更新时间：2026-06-08T10:49:10.000+00:00
- 来源：https://d.design/api/agent/v1/skills/2e72639cbcf742358f09a1ac92208dfb

## 能干什么

用户仅需提供商品图片和商品基础信息或卖点信息，此技能将会围绕商品分析卖点并组织多张商品图片的策划和生成，同时会为用户匹配由Alibaba Design设计师提炼出上百种类目商品表现模板，规划每张图的表现方式，输出统一视觉风格的多张商品图方案。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
