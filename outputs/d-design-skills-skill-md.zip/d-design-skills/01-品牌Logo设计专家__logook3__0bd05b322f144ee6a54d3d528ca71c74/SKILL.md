---
name: logo-creator
description: Generates professional AI image prompts for flat vector logo designs. Use when user asks for "logo design", "create a logo", "brand identity", "company logo", or needs help with logo concepts and prompt engineering for AI image generators.
metadata:
  author: Logo Design Expert
  version: 3.0.0
  category: design
  tags: [logo, branding, design, ai-prompts, vector]
---
***重要：如果logo是英文选择使用全新ImageV2模型生成；如果logo是中文选择使用标准图片模型生成，如果logo是中英文结合选择使用全新ImageV2模型生成。***

# Logo Creator

Generates optimized prompts for **flat vector style logos**. All outputs emphasize clean, scalable vector designs suitable for brand identity.

## Core Principle

**Every logo must be flat vector style** - No 3D renders, no photorealistic effects, no complex shadows. Clean, scalable, professional.

## When to Use

- User asks for "logo design" or "create a logo"
- User mentions brand identity or company branding
- User needs help with logo concepts or ideas
- User wants AI prompts for logo generation
- User describes visual elements for a brand mark

## Workflow

### Step 1: Analyze User Input

Extract these dimensions from user request:

| Dimension | What to Capture | Examples |
|-----------|----------------|----------|
| **Brand Name** | Chinese, English, or both | "云栖", "StarLink", "百新生活 / BAIXIN LIFE" |
| **Industry** | Business category | Tech, Food, Fashion, Education, Healthcare |
| **Style** | Visual aesthetic | Minimalist, Vintage, Modern, Playful, Luxury |
| **Elements** | Visual components | Animals, Plants, Geometric shapes, Letters |
| **Colors** | Preferred palette | Blue, Earth tones, Black & white, Gradient |
| **Typography** | Font preferences | Serif, Sans-serif, Script, Custom |

### Step 2: Apply Style Constraints

**CRITICAL: Enforce flat vector style**

All prompts must include:
- `flat vector logo` or `flat design`
- `scalable` or `SVG-ready`
- `clean lines` or `crisp edges`
- `minimal` or `simple`

**Forbidden elements** (automatically excluded):
- 3D renders, photorealistic effects
- Complex shadows, depth effects
- Texture overlays (unless specified as flat texture)
- Gradient meshes (use simple flat gradients only)

### Step 3: Select Logo Type

Determine the appropriate logo type based on user needs:

**Type 1: Symbol/Icon Logo**
- Pure graphic, no text
- Best for: App icons, favicons, simple brands
- Key phrase: `symbol logo`, `icon mark`, `pictogram`

**Type 2: Wordmark**
- Text-only, stylized typography
- Best for: Established brands, fashion, media
- Key phrase: `wordmark logo`, `typography logo`, `lettering`

**Type 3: Lettermark**
- Initials or monogram
- Best for: Long brand names, corporate
- Key phrase: `lettermark`, `monogram`, `initials logo`

**Type 4: Combination Mark**
- Icon + text, separable
- Best for: Most brands, versatile use
- Key phrase: `combination logo`, `icon with wordmark`

**Type 5: Emblem/Badge**
- Text inside graphic container
- Best for: Schools, organizations, traditional
- Key phrase: `emblem logo`, `badge logo`, `seal design`

**Type 6: Mascot**
- Character or figure
- Best for: Sports, entertainment, food
- Key phrase: `mascot logo`, `character logo`

### Step 4: Build the Prompt

**Standard Prompt Structure:**

```
[Style keywords] [Logo type] for "[Brand Name]", [Main element description], 
[Composition details], [Color scheme], flat vector design, clean lines, 
scalable SVG, professional brand identity, [Additional requirements]
```

**Required components in every prompt:**

1. **Style Declaration** (always first)
   - `Minimalist flat vector logo`
   - `Clean flat design logo`
   - `Modern flat vector mark`

2. **Brand Identity**
   - Brand name in quotes
   - Industry context
   - Brand personality

3. **Visual Elements**
   - Primary element (animal, plant, geometric, letter)
   - Secondary elements (accents, decorations)
   - Composition (centered, asymmetric, circular, etc.)

4. **Color Specification**
   - Primary color
   - Secondary/accent color
   - Background (usually white or transparent)

5. **Technical Requirements** (always included)
   - `flat vector design`
   - `clean lines`
   - `scalable`
   - `professional brand identity`

### Step 5: Generate Variations

Create 3 distinct variations:

**Variation A: Classic/Conservative**
- Timeless design principles
- Broad appeal
- Safe for any industry

**Variation B: Modern/Trendy**
- Current design trends
- Distinctive and memorable
- Appeals to younger audiences

**Variation C: Minimal/Pure**
- Maximum simplicity
- Highest scalability
- Focus on essential elements only

## Style Library

### Minimalist
```
Core: minimalist, simple, clean, geometric, flat
Elements: negative space, basic shapes, limited palette
Avoid: ornamentation, complexity, gradients
```

### Modern/Tech
```
Core: modern, tech, digital, geometric, flat
Elements: clean lines, grid-based, sans-serif
Colors: blue, cyan, black, white, electric tones
```

### Vintage/Retro
```
Core: vintage, retro, classic, heritage, flat
Elements: badge shapes, traditional motifs, serif fonts
Colors: sepia, cream, burgundy, forest green
Texture: flat texture only (no 3D distressing)
```

### Organic/Natural
```
Core: organic, natural, eco, botanical, flat
Elements: flowing lines, plant motifs, hand-drawn feel
Colors: green, earth tones, soft blues
```

### Playful/Friendly
```
Core: playful, friendly, approachable, flat
Elements: rounded shapes, bright colors, simple icons
Colors: vibrant, multi-color, cheerful
```

### Luxury/Elegant
```
Core: luxury, elegant, premium, sophisticated, flat
Elements: refined details, monogram, serif fonts
Colors: black, gold, navy, white, burgundy
```

## Element Fusion Patterns

When user requests multiple elements, use these fusion techniques:

### Animal + Letter
```
[Animal] silhouette forming letter [X], negative space design, 
flat vector, simple outline
```

### Plant + Object
```
[Plant element] integrated with [object], flowing composition, 
flat design, clean lines
```

### Geometric + Organic
```
Geometric [shape] with organic [element] inside, balanced composition, 
flat vector style
```

### Text + Graphic
```
"[Text]" with [graphic element] incorporated into letterforms, 
flat design, cohesive mark
```

## Color Palettes

### Professional
- Navy + White
- Black + Gold
- Charcoal + Teal
- Dark Blue + Light Gray

### Creative
- Purple + Pink
- Orange + Yellow
- Cyan + Magenta
- Multi-color flat

### Natural
- Forest Green + Cream
- Earth Brown + Sage
- Ocean Blue + Sand
- Olive + Terracotta

### Modern Tech
- Electric Blue + Black
- Neon Green + Dark Gray
- Purple + Cyan gradient (flat)
- White + Any accent

## Examples

### Example 1: Tech Startup

**User Input**: "科技公司叫 StarLink，想要现代感，带星星元素"

**Analysis**:
- Brand: StarLink
- Industry: Tech
- Style: Modern
- Element: Star, connection
- Type: Combination mark

**Output**:

```markdown
## Logo Concepts for "StarLink"

### Option A: Modern Combination Mark (Recommended)
```
Minimalist flat vector logo for "StarLink" tech company, interconnected stars 
forming a network pattern, clean geometric lines, deep space blue and electric 
cyan, icon positioned left of modern sans-serif wordmark, flat design, 
clean lines, scalable SVG, professional brand identity, versatile application
```

**Why this works**: Clean, scalable, communicates connection/network concept

### Option B: Abstract Symbol
```
Flat vector symbol logo for "StarLink", stylized star with circuit-like 
connections, geometric precision, navy blue and silver, centered composition, 
flat design, crisp edges, scalable brand mark, tech industry
```

**Why this works**: Unique symbol, works at small sizes, memorable

### Option C: Minimal Lettermark
```
Clean flat vector lettermark "SL" with integrated star negative space, 
modern sans-serif typography, minimal composition, black and electric blue, 
flat design, simple lines, scalable monogram, professional tech brand
```

**Why this works**: Ultra-minimal, maximum versatility, sophisticated
```

### Example 2: Coffee Shop

**User Input**: "咖啡店叫 CozyCup，想要温暖复古的感觉"

**Analysis**:
- Brand: CozyCup
- Industry: Food/Beverage
- Style: Vintage/Warm
- Element: Coffee cup
- Type: Emblem or Wordmark

**Output**:

```markdown
## Logo Concepts for "CozyCup"

### Option A: Vintage Emblem
```
Flat vector emblem logo for "CozyCup" coffee shop, steaming coffee cup inside 
circular badge, warm cream and coffee brown palette, retro-inspired typography, 
decorative border elements, flat design, clean lines, scalable badge, 
heritage cafe branding
```

**Why this works**: Classic emblem format, warm colors, approachable

### Option B: Modern Wordmark
```
Flat vector wordmark logo "CozyCup", custom rounded sans-serif with subtle 
coffee bean accent on letter "C", warm beige and espresso brown, horizontal 
layout, flat design, clean typography, scalable brand identity, friendly 
coffee brand
```

**Why this works**: Simple, modern, easy to read

### Option C: Minimal Icon
```
Flat vector icon logo for "CozyCup", stylized coffee cup with steam forming 
heart shape, burnt orange and cream, centered composition, flat design, 
simple shapes, scalable symbol, cozy cafe mark
```

**Why this works**: Sweet concept, works on signage and cups
```

### Example 3: Chinese Brand

**User Input**: "茶叶品牌'云栖'，中式风格，有山水元素"

**Analysis**:
- Brand: 云栖 (YUNXI)
- Industry: Tea/Beverage
- Style: Chinese/Traditional
- Element: Mountain, water, cloud
- Type: Combination or Emblem

**Output**:

```markdown
## Logo Concepts for "云栖 YUNXI"

### Option A: Modern Chinese Style
```
Flat vector logo for "云栖 YUNXI" tea brand, stylized mountain peaks with 
flowing water lines, cloud motif above, ink black and jade green, Chinese 
aesthetic with modern execution, flat design, clean lines, scalable vector, 
horizontal layout with Chinese characters above English, premium tea branding
```

**Why this works**: Balances tradition and modernity, clean execution

### Option B: Seal-Inspired Mark
```
Flat vector emblem logo "云栖", circular seal design with mountain landscape 
inside, traditional Chinese red and black, flat design, clean geometry, 
scalable badge, cultural tea brand identity
```

**Why this works**: Strong cultural reference, distinctive shape

### Option C: Minimal Nature
```
Flat vector symbol logo for "云栖", single flowing line forming mountain and 
cloud silhouette, sage green and warm gray, centered composition, flat design, 
minimal lines, scalable nature mark, zen tea brand
```

**Why this works**: Extremely simple, peaceful feeling, versatile
```

## Error Handling

### Unclear User Input

**Symptom**: User request is vague or incomplete

**Solution**:
1. Ask clarifying questions:
   - "What is your brand name?"
   - "What industry are you in?"
   - "Do you have any specific visual elements in mind?"
   - "What style appeals to you - modern, classic, playful, or minimal?"

2. Provide style examples to help user choose

### Conflicting Requirements

**Symptom**: User asks for contradictory elements (e.g., "vintage and futuristic")

**Solution**:
1. Acknowledge both directions
2. Offer separate variations for each style
3. Suggest a "fusion" approach if appropriate

### Overly Complex Requests

**Symptom**: User wants too many elements in one logo

**Solution**:
1. Prioritize elements (primary vs secondary)
2. Suggest simplifying to 1-2 core elements
3. Explain that simple logos are more effective

## Best Practices

### For Users

1. **Start simple**: Begin with minimal concepts, add complexity only if needed
2. **Consider scalability**: Logo should work at 16px (favicon) and 16ft (billboard)
3. **Test in black and white**: Good logos work without color
4. **Think about context**: Where will this logo appear? (web, print, merchandise)

### For Prompt Engineering

1. **Always include**: `flat vector`, `clean lines`, `scalable`
2. **Specify colors**: Use specific color names, not vague descriptions
3. **Describe composition**: Centered, left-aligned, circular, etc.
4. **Mention industry**: Helps AI understand appropriate style
5. **Include brand name**: In quotes for clarity

## Reference Resources

### Color Theory
- `references/color-palettes.md` - Curated color combinations
- `references/industry-colors.md` - Industry-standard color schemes

### Typography
- `references/font-pairings.md` - Recommended font combinations
- `references/typography-styles.md` - Style-specific type treatments

### Design Patterns
- `references/logo-types.md` - Detailed logo type explanations
- `references/fusion-patterns.md` - Element combination techniques

## Quality Checklist

Before delivering prompts, verify:

- [ ] All prompts specify `flat vector` or `flat design`
- [ ] Brand name is clearly stated
- [ ] Color palette is specific
- [ ] Style keywords match user intent
- [ ] Technical terms (`scalable`, `clean lines`) are included
- [ ] Three distinct variations provided
- [ ] Each variation has explanation
- [ ] No 3D or photorealistic language used

## Parameter Recommendations

For AI image generators:
**标准图片模型**:
```
比例: 1:1, 质量: 高清, 风格: 扁平插画
```

## Notes

💡 **Tip**: Flat vector logos are the most versatile for branding. They scale infinitely, load quickly on websites, and work across all media types.

⚠️ **Important**: If user specifically requests 3D or textured effects, remind them that flat vector is recommended for brand logos, but provide their requested style as an alternative variation.

🎯 **Goal**: Every logo prompt should produce a design that could be used immediately as a brand mark without modification.
