# 品牌Logo设计专家

- 文件夹名：`01-品牌Logo设计专家__logook3__0bd05b322f144ee6a54d3d528ca71c74`
- publicId：`0bd05b322f144ee6a54d3d528ca71c74`
- name：`logook3`
- 分类：未标注
- 版本：17
- 更新时间：2026-06-11T09:14:12.000+00:00
- 来源：https://d.design/api/agent/v1/skills/0bd05b322f144ee6a54d3d528ca71c74

## 能干什么

将专业 Logo 设计流程压缩至一次对话，无需反复调整，只需告诉它你的品牌名称与行业，从创意到视觉，一步到位。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
