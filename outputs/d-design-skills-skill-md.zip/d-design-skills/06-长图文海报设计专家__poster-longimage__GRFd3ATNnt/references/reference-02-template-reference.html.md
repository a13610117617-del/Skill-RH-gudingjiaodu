---
title: "template-reference.html"
type: "reference"
---

<!--
  poster-longimage 设计词汇表
  ================================
  本文件展示长图海报内容区的可用视觉元素和排版模式。

  ⚠️ 使用原则：
  - 这是设计词汇表，不是复制源
  - 生成海报时，理解这些模式的设计意图，然后原创你自己的实现
  - 鼓励：调整比例、混搭元素、发明新的排版方式、改变布局
  - 禁止：整段复制代码只替换文字内容——每张海报都应该是独特的

  设计元素索引：
  1. 海报骨架（Tailwind config + CSS Variables + Canvas）
  2. 主视觉图片区 + 过渡方案
  3. 标题排版模式（3 种风格示例）
  4. 卡片网格（2列/3列 + 几何图标库）
  5. 列表排版（编号/勾选）
  6. 大数字突出
  7. 时间线 / 步骤
  8. 键值信息
  9. 引用 / 评价
  10. 分割装饰（3 种风格示例）
  11. CTA / 页脚

  每种元素展示的是一种设计"语言"——间距感、字体层级、色彩节奏。
  你应该用这套语言来"说"出完全不同的"句子"。
-->
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=750">
<title>长图海报模板参考</title>

<!-- Google Fonts: 根据 design tone 加载 2-3 种字体 -->
<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@600;700;900&family=Noto+Sans+SC:wght@400;500;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">

<!-- Tailwind CDN -->
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          primary: 'var(--color-primary)',
          secondary: 'var(--color-secondary)',
          'bg-base': 'var(--color-bg)',
          'bg-alt': 'var(--color-bg-alt)',
          'text-main': 'var(--color-text)',
          'text-muted': 'var(--color-text-muted)',
          accent: 'var(--color-accent)',
          'card-bg': 'var(--color-card-bg)',
        },
        fontFamily: {
          display: ['var(--font-display)'],
          body: ['var(--font-body)'],
          accent: ['var(--font-accent)'],
        },
      }
    }
  }
</script>

<style>
/* ==================== CSS Variables ==================== */
:root {
  --color-primary: #1a237e;
  --color-secondary: #c9a84c;
  --color-bg: #f5f0e8;
  --color-bg-alt: #ede7db;
  --color-text: #1a1a2e;
  --color-text-muted: #6b6b7b;
  --color-accent: #c9a84c;
  --color-card-bg: #ffffff;
  --font-display: 'Noto Serif SC', serif;
  --font-body: 'Noto Sans SC', sans-serif;
  --font-accent: 'Playfair Display', serif;
}

/* ==================== Canvas ==================== */
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
  width: 750px;
  margin: 0 auto;
  background: var(--color-bg);
  font-family: var(--font-body);
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
  color: var(--color-text);
}
.poster-canvas { width: 750px; overflow: hidden; }

/* ==================== Hero Image ==================== */
.hero-wrapper { position: relative; line-height: 0; }
.hero-image { display: block; width: 100%; height: auto; }

/* 过渡方案 B: 渐变叠加 */
.hero-wrapper--gradient::after {
  content: '';
  position: absolute;
  bottom: 0; left: 0; right: 0;
  height: 120px;
  background: linear-gradient(to bottom, transparent, var(--color-bg));
  pointer-events: none;
}

/* 过渡方案 C: 波浪分割 */
.transition-wave {
  width: 100%;
  height: 50px;
  background: var(--color-bg);
  clip-path: ellipse(60% 100% at 50% 100%);
  margin-top: -50px;
  position: relative;
  z-index: 2;
}

/* ==================== Background Patterns ==================== */
.pattern-dots {
  background-image: radial-gradient(circle, var(--color-primary) 1px, transparent 1px);
  background-size: 24px 24px;
  opacity: 0.04;
  position: absolute; inset: 0; pointer-events: none;
}
.pattern-diag {
  background-image: repeating-linear-gradient(
    -45deg, var(--color-primary), var(--color-primary) 1px,
    transparent 1px, transparent 12px
  );
  opacity: 0.03;
  position: absolute; inset: 0; pointer-events: none;
}
.pattern-grid {
  background-image:
    linear-gradient(var(--color-secondary) 1px, transparent 1px),
    linear-gradient(90deg, var(--color-secondary) 1px, transparent 1px);
  background-size: 32px 32px;
  opacity: 0.04;
  position: absolute; inset: 0; pointer-events: none;
}
</style>
</head>
<body>

<div class="poster-canvas">

  <!-- ==================== 主视觉图片区 ==================== -->
  <!--
    使用说明：
    - 默认方案 A（纯色匹配），图片底部颜色 = bg-base
    - 渐变过渡：class 改为 "hero-wrapper hero-wrapper--gradient"
    - 波浪分割：hero-wrapper 后面加 <div class="transition-wave"></div>
  -->
  <div class="hero-wrapper hero-wrapper--gradient">
    <img class="hero-image" src="./poster-hero.png" alt="海报主视觉">
  </div>


  <!-- ==================== 元素 1: 标题排版模式 ==================== -->
  <!--
    以下 3 种风格展示了不同的标题设计语言。
    实际使用时应理解其设计意图后原创实现，而非直接复制。
    你也可以发明完全不同的标题排版方式。
  -->

  <!-- 变体 A: 居中标题 + 强调下划线 -->
  <div class="pt-[40px] px-[48px] pb-5 text-center">
    <h2 class="font-display text-[34px] font-bold text-text-main tracking-[2px]">岗位职责</h2>
    <div class="w-12 h-[3px] bg-secondary rounded-full mx-auto mt-3"></div>
    <p class="mt-3 font-accent text-[20px] text-text-muted tracking-[3px] uppercase">What You'll Do</p>
  </div>

  <!-- 变体 B: 左对齐 + 渐变竖线 -->
  <div class="pt-[40px] px-[48px] pb-5">
    <div class="flex items-center gap-4">
      <div class="w-[6px] h-[36px] rounded-full bg-gradient-to-b from-secondary to-primary"></div>
      <h2 class="font-display text-[32px] font-bold text-text-main">核心优势</h2>
    </div>
  </div>

  <!-- 变体 C: 居中徽章 + 两侧渐变装饰线 -->
  <div class="pt-[40px] px-[48px] pb-5 text-center">
    <div class="flex items-center justify-center gap-4">
      <div class="h-[1px] w-12 bg-gradient-to-r from-transparent to-secondary"></div>
      <span class="inline-block bg-primary text-white text-[26px] font-bold px-8 py-2.5 rounded-full tracking-[4px] shadow-lg shadow-primary/20">
        我们提供
      </span>
      <div class="h-[1px] w-12 bg-gradient-to-l from-transparent to-secondary"></div>
    </div>
  </div>


  <!-- ==================== 元素 2: 卡片网格 ==================== -->
  <!--
    设计语言：并列信息的网格化展示，带几何图标 + 标题 + 描述。
    以下示例展示了 2列/3列、顶部边框/左侧边框等变化。
    实际设计中可自由调整列数、间距、边框位置、图标样式。
  -->

  <!-- 2列卡片网格（顶部边框） -->
  <div class="grid grid-cols-2 gap-5 px-[48px] pt-5 pb-[40px]">

    <div class="bg-card-bg rounded-2xl p-7 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary">
      <!-- 几何图标: Diamond -->
      <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
        <div class="w-5 h-5 bg-secondary/80 rounded-[4px] rotate-45"></div>
      </div>
      <div class="text-[26px] font-bold text-text-main mb-2 text-center font-display">医疗保障</div>
      <div class="text-[22px] text-text-muted leading-[1.5] text-center">五险一金 + 补充商业保险</div>
    </div>

    <div class="bg-card-bg rounded-2xl p-7 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary">
      <!-- 几何图标: Ring -->
      <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
        <div class="w-6 h-6 border-[3px] border-secondary/80 rounded-full"></div>
      </div>
      <div class="text-[26px] font-bold text-text-main mb-2 text-center font-display">带薪年假</div>
      <div class="text-[22px] text-text-muted leading-[1.5] text-center">入职即享 15 天带薪年假</div>
    </div>

    <div class="bg-card-bg rounded-2xl p-7 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary">
      <!-- 几何图标: Bars -->
      <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
        <div class="flex flex-col gap-[5px]">
          <div class="w-5 h-[3px] bg-secondary/80 rounded-full"></div>
          <div class="w-4 h-[3px] bg-secondary/80 rounded-full"></div>
          <div class="w-5 h-[3px] bg-secondary/80 rounded-full"></div>
        </div>
      </div>
      <div class="text-[26px] font-bold text-text-main mb-2 text-center font-display">学习成长</div>
      <div class="text-[22px] text-text-muted leading-[1.5] text-center">每年 1 万元学习基金</div>
    </div>

    <div class="bg-card-bg rounded-2xl p-7 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary">
      <!-- 几何图标: Cross -->
      <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
        <div class="relative w-5 h-5">
          <div class="absolute top-1/2 left-0 w-full h-[3px] bg-secondary/80 -translate-y-1/2 rounded-full"></div>
          <div class="absolute left-1/2 top-0 h-full w-[3px] bg-secondary/80 -translate-x-1/2 rounded-full"></div>
        </div>
      </div>
      <div class="text-[26px] font-bold text-text-main mb-2 text-center font-display">三餐补贴</div>
      <div class="text-[22px] text-text-muted leading-[1.5] text-center">公司食堂免费三餐</div>
    </div>

  </div>

  <!-- 3列卡片网格 -->
  <div class="grid grid-cols-3 gap-4 px-[48px] pt-5 pb-[40px]">
    <div class="bg-card-bg rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary text-center">
      <div class="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mx-auto mb-3">
        <div class="w-4 h-4 bg-secondary/80 rounded-[3px] rotate-45"></div>
      </div>
      <div class="text-[24px] font-bold text-text-main mb-1 font-display">快速迭代</div>
      <div class="text-[20px] text-text-muted leading-[1.4]">双周发版</div>
    </div>
    <div class="bg-card-bg rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary text-center">
      <div class="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mx-auto mb-3">
        <div class="w-5 h-5 border-[2px] border-secondary/80 rounded-full"></div>
      </div>
      <div class="text-[24px] font-bold text-text-main mb-1 font-display">数据安全</div>
      <div class="text-[20px] text-text-muted leading-[1.4]">端到端加密</div>
    </div>
    <div class="bg-card-bg rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-t-[3px] border-secondary text-center">
      <div class="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mx-auto mb-3">
        <div class="w-0 h-0 border-l-[8px] border-r-[8px] border-b-[14px] border-l-transparent border-r-transparent border-b-secondary/80"></div>
      </div>
      <div class="text-[24px] font-bold text-text-main mb-1 font-display">全球部署</div>
      <div class="text-[20px] text-text-muted leading-[1.4]">多区域节点</div>
    </div>
  </div>

  <!-- 左侧边框变体 -->
  <div class="grid grid-cols-2 gap-5 px-[48px] pt-5 pb-[40px]">
    <div class="bg-card-bg rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-l-4 border-secondary text-left">
      <div class="text-[26px] font-bold text-text-main mb-2 font-display">Front-end Engineer</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">构建下一代用户界面</div>
    </div>
    <div class="bg-card-bg rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.06)] border-l-4 border-secondary text-left">
      <div class="text-[26px] font-bold text-text-main mb-2 font-display">Back-end Engineer</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">设计高可用分布式系统</div>
    </div>
  </div>


  <!-- ==================== 几何图标灵感库 ==================== -->
  <!--
    6 种 CSS-only 几何形状示例，替代 emoji。
    这些是灵感参考——你可以修改尺寸、颜色、组合方式，也可以发明全新的几何形状。
  -->
  <!--
    1. Diamond (菱形)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="w-5 h-5 bg-secondary/80 rounded-[4px] rotate-45"></div>
    </div>

    2. Ring (圆环)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="w-6 h-6 border-[3px] border-secondary/80 rounded-full"></div>
    </div>

    3. Bars (三横线)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="flex flex-col gap-[5px]">
        <div class="w-5 h-[3px] bg-secondary/80 rounded-full"></div>
        <div class="w-4 h-[3px] bg-secondary/80 rounded-full"></div>
        <div class="w-5 h-[3px] bg-secondary/80 rounded-full"></div>
      </div>
    </div>

    4. Cross (十字)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="relative w-5 h-5">
        <div class="absolute top-1/2 left-0 w-full h-[3px] bg-secondary/80 -translate-y-1/2 rounded-full"></div>
        <div class="absolute left-1/2 top-0 h-full w-[3px] bg-secondary/80 -translate-x-1/2 rounded-full"></div>
      </div>
    </div>

    5. Triangle (三角)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="w-0 h-0 border-l-[10px] border-r-[10px] border-b-[18px] border-l-transparent border-r-transparent border-b-secondary/80"></div>
    </div>

    6. Dot Cluster (四点)
    <div class="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
      <div class="grid grid-cols-2 gap-[6px]">
        <div class="w-[8px] h-[8px] bg-secondary/80 rounded-full"></div>
        <div class="w-[8px] h-[8px] bg-secondary/80 rounded-full"></div>
        <div class="w-[8px] h-[8px] bg-secondary/80 rounded-full"></div>
        <div class="w-[8px] h-[8px] bg-secondary/80 rounded-full"></div>
      </div>
    </div>

    极简 SVG 示例（仅当需要可识别符号时使用）:
    <svg class="w-6 h-6 text-secondary" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M12 6v12M6 12h12" stroke-linecap="round"/>
    </svg>
  -->


  <!-- ==================== 元素 3: 列表排版 ==================== -->
  <!--
    设计语言：垂直列表项，带装饰标记。
    以下展示编号标记和勾选标记两种风格。
    实际使用中可自由发挥标记样式和布局方式。
  -->

  <!-- 编号标记 -->
  <div class="px-[48px] pt-5 pb-[40px] space-y-5">

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-secondary text-primary text-[16px] font-bold flex items-center justify-center font-accent shadow-sm shadow-secondary/30">1</span>
      <span class="text-[26px] leading-[1.6] text-text-main">负责核心产品的前端架构设计与技术选型，搭建高性能、可扩展的前端体系</span>
    </div>

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-secondary text-primary text-[16px] font-bold flex items-center justify-center font-accent shadow-sm shadow-secondary/30">2</span>
      <span class="text-[26px] leading-[1.6] text-text-main">推动前端工程化建设，完善 CI/CD 流程与自动化测试</span>
    </div>

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-secondary text-primary text-[16px] font-bold flex items-center justify-center font-accent shadow-sm shadow-secondary/30">3</span>
      <span class="text-[26px] leading-[1.6] text-text-main">与产品、设计、后端团队紧密协作，参与技术方案评审</span>
    </div>

  </div>

  <!-- 勾选标记 -->
  <div class="px-[48px] pt-5 pb-[40px] space-y-5">

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-primary text-white flex items-center justify-center shadow-sm">
        <svg class="w-4 h-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 8l4 4 6-7" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </span>
      <span class="text-[26px] leading-[1.6] text-text-main">3 年以上前端开发经验，精通 React 或 Vue 生态</span>
    </div>

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-primary text-white flex items-center justify-center shadow-sm">
        <svg class="w-4 h-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 8l4 4 6-7" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </span>
      <span class="text-[26px] leading-[1.6] text-text-main">扎实的 JavaScript / TypeScript 基础，熟悉 ES6+ 特性</span>
    </div>

    <div class="flex items-start gap-4">
      <span class="flex-shrink-0 w-8 h-8 mt-1 rounded-full bg-primary text-white flex items-center justify-center shadow-sm">
        <svg class="w-4 h-4" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M3 8l4 4 6-7" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </span>
      <span class="text-[26px] leading-[1.6] text-text-main">良好的沟通能力与团队协作精神</span>
    </div>

  </div>


  <!-- ==================== 元素 4: 大数字突出 ==================== -->
  <!--
    设计语言：大号数字 + 标签，制造视觉冲击力。
    核心要素：font-accent 大字体 + 深色反转背景。
    数字的排列、大小、辅助标签位置都可以自由调整。
  -->

  <section class="relative bg-primary overflow-hidden">
    <div class="pattern-grid"></div>
    <div class="relative flex justify-around py-10 px-[48px]">
      <div class="text-center">
        <div class="font-accent text-[72px] font-black leading-none text-secondary drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">
          30<span class="text-[28px] font-normal ml-1">K+</span>
        </div>
        <div class="text-[22px] text-white/80 mt-2 tracking-[2px]">月薪范围</div>
      </div>
      <div class="text-center">
        <div class="font-accent text-[72px] font-black leading-none text-secondary drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">
          16<span class="text-[28px] font-normal ml-1">薪</span>
        </div>
        <div class="text-[22px] text-white/80 mt-2 tracking-[2px]">年终奖金</div>
      </div>
      <div class="text-center">
        <div class="font-accent text-[72px] font-black leading-none text-secondary drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">
          15<span class="text-[28px] font-normal ml-1">天</span>
        </div>
        <div class="text-[22px] text-white/80 mt-2 tracking-[2px]">带薪年假</div>
      </div>
    </div>
  </section>


  <!-- ==================== 元素 5: 时间线 / 步骤 ==================== -->
  <!--
    设计语言：有时序或步骤顺序的内容展示。
    核心要素：连接线 + 节点 + 时间标记(font-accent) + 标题(font-display)。
    以下展示了步骤式和时间范围式两种变化。布局和样式可以自由调整。
  -->

  <div class="px-[48px] pl-[68px] pt-5 pb-[40px]">

    <div class="relative pl-10 pb-8 border-l-[3px] border-primary/15">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">Step 01</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">投递简历</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">扫描下方二维码或发送简历至 hr@acme.com</div>
    </div>

    <div class="relative pl-10 pb-8 border-l-[3px] border-primary/15">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">Step 02</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">简历筛选</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">HR 将在 3 个工作日内回复</div>
    </div>

    <div class="relative pl-10 pb-8 border-l-[3px] border-primary/15">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">Step 03</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">技术面试</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">2 轮技术面 + 1 轮团队文化面</div>
    </div>

    <div class="relative pl-10 border-l-[3px] border-transparent">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">Step 04</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">发放 Offer</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">面试通过后 1 周内发放正式 Offer</div>
    </div>

  </div>

  <!-- 时间线变体：时间范围格式（适用于活动日程） -->
  <div class="px-[48px] pl-[68px] pt-5 pb-[40px]">

    <div class="relative pl-10 pb-8 border-l-[3px] border-primary/15">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">09:00 &mdash; 09:30</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">签到入场</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">领取参会资料与纪念品</div>
    </div>

    <div class="relative pl-10 border-l-[3px] border-transparent">
      <div class="absolute -left-[11px] top-1 w-5 h-5 rounded-full bg-secondary border-[3px] border-primary shadow-md shadow-secondary/20"></div>
      <div class="text-[22px] font-bold text-primary font-accent mb-1">09:30 &mdash; 11:00</div>
      <div class="text-[26px] font-bold text-text-main font-display mb-1">主旨演讲</div>
      <div class="text-[22px] text-text-muted leading-[1.5]">技术趋势与行业展望</div>
    </div>

  </div>


  <!-- ==================== 元素 6: 键值信息 ==================== -->
  <!--
    设计语言：标签 + 值 的结构化信息展示。
    核心要素：key 用 font-display 加粗、value 用 font-body。
    可以用卡片、表格、横排条、竖排块等各种方式呈现。
  -->

  <div class="mx-[48px] bg-card-bg rounded-2xl p-8 shadow-[0_2px_12px_rgba(0,0,0,0.06)] mb-[40px]">

    <div class="flex items-baseline py-4 border-b border-primary/10">
      <span class="w-[140px] flex-shrink-0 text-[26px] font-bold text-primary font-display">招聘岗位</span>
      <span class="text-[26px] text-text-main leading-[1.5]">高级前端开发工程师</span>
    </div>

    <div class="flex items-baseline py-4 border-b border-primary/10">
      <span class="w-[140px] flex-shrink-0 text-[26px] font-bold text-primary font-display">薪资范围</span>
      <span class="text-[26px] text-text-main leading-[1.5]">25K — 40K &middot; 16薪</span>
    </div>

    <div class="flex items-baseline py-4 border-b border-primary/10">
      <span class="w-[140px] flex-shrink-0 text-[26px] font-bold text-primary font-display">工作地点</span>
      <span class="text-[26px] text-text-main leading-[1.5]">北京市海淀区中关村软件园</span>
    </div>

    <div class="flex items-baseline py-4">
      <span class="w-[140px] flex-shrink-0 text-[26px] font-bold text-primary font-display">学历要求</span>
      <span class="text-[26px] text-text-main leading-[1.5]">本科及以上</span>
    </div>

  </div>


  <!-- ==================== 元素 7: 引用 / 评价 ==================== -->
  <!--
    设计语言：突出展示引用语句。
    核心要素：引号装饰(SVG) + 引用文字(font-display italic) + 署名。
    背景、引号样式、文字大小、署名位置等均可自由调整。
  -->

  <section class="relative bg-bg-alt py-[40px] px-[48px]">
    <div class="text-center max-w-[580px] mx-auto">
      <svg class="w-10 h-10 mx-auto mb-5 text-secondary/60" viewBox="0 0 40 32" fill="currentColor">
        <path d="M0 20.4C0 27.2 3.6 32 9.2 32c3.6 0 6.4-2.8 6.4-6.4 0-3.2-2.4-5.6-5.2-5.6-1.2 0-2 .4-2.8.8C8 18 10 14.4 14.8 11.2L12 6.4C4.4 11.2 0 16 0 20.4zm21.6 0C21.6 27.2 25.2 32 30.8 32c3.6 0 6.4-2.8 6.4-6.4 0-3.2-2.4-5.6-5.2-5.6-1.2 0-2 .4-2.8.8C29.6 18 31.6 14.4 36.4 11.2L33.6 6.4C26 11.2 21.6 16 21.6 20.4z"/>
      </svg>
      <p class="text-[28px] text-text-main leading-[1.8] font-display italic">
        我们相信技术的力量，更相信人的力量。每一位同事都是我们最宝贵的财富。
      </p>
      <div class="mt-5 flex items-center justify-center gap-3">
        <div class="w-8 h-[2px] bg-secondary rounded-full"></div>
        <span class="text-[22px] text-text-muted">CEO 张三</span>
        <div class="w-8 h-[2px] bg-secondary rounded-full"></div>
      </div>
    </div>
  </section>


  <!-- ==================== 元素 8: 分割装饰 ==================== -->
  <!--
    设计语言：section 之间的视觉过渡。
    以下展示 3 种风格。实际使用中可自由发挥，也可以不用分割线——
    通过背景色交替或间距就能实现自然过渡。
  -->

  <!-- 变体 A: 渐隐线 + 大小渐变圆点 -->
  <div class="flex items-center justify-center gap-4 py-3 px-[48px]">
    <div class="flex-1 h-[1px] bg-gradient-to-r from-transparent to-primary/10"></div>
    <div class="w-[6px] h-[6px] rounded-full bg-secondary/50"></div>
    <div class="w-[8px] h-[8px] rounded-full bg-secondary"></div>
    <div class="w-[6px] h-[6px] rounded-full bg-secondary/50"></div>
    <div class="flex-1 h-[1px] bg-gradient-to-l from-transparent to-primary/10"></div>
  </div>

  <!-- 变体 B: 渐变色带 -->
  <div class="mx-[48px] h-[3px] rounded-full bg-gradient-to-r from-primary via-secondary to-primary my-2"></div>

  <!-- 变体 C: 几何菱形 -->
  <div class="flex items-center justify-center gap-2 py-4 px-[48px]">
    <div class="flex-1 h-[1px] bg-primary/10"></div>
    <div class="w-3 h-3 bg-secondary/40 rotate-45 rounded-[2px]"></div>
    <div class="w-4 h-4 bg-secondary rotate-45 rounded-[2px]"></div>
    <div class="w-3 h-3 bg-secondary/40 rotate-45 rounded-[2px]"></div>
    <div class="flex-1 h-[1px] bg-primary/10"></div>
  </div>


  <!-- ==================== 元素 9: CTA / 页脚 ==================== -->
  <!--
    设计语言：海报底部的行动号召区。
    核心要素：醒目标题 + 二维码占位 + 联系方式 + 品牌信息。
    背景、布局、CTA 文案风格均可根据场景调性自由调整。
  -->

  <section class="relative bg-primary overflow-hidden">
    <div class="pattern-dots" style="opacity: 0.06;"></div>

    <div class="relative py-12 px-[48px] text-center text-white">
      <h3 class="font-display text-[32px] font-bold tracking-[4px] mb-6">扫码投递简历</h3>

      <div class="inline-block bg-white p-4 rounded-2xl shadow-lg shadow-black/20 mb-6">
        <div class="w-[180px] h-[180px] bg-gray-100 rounded-xl flex items-center justify-center text-[22px] text-gray-400">
          二维码占位
        </div>
      </div>

      <p class="text-[24px] text-white/85 mb-2">长按识别二维码，立即申请</p>

      <div class="text-[22px] text-white/60 leading-[1.8]">
        联系邮箱：hr@example.com<br>
        联系电话：400-123-4567
      </div>

      <div class="mt-8 pt-6 border-t border-white/15 text-[18px] text-white/40 tracking-[2px]">
        &copy; 2026 Example Corp. All rights reserved.
      </div>
    </div>
  </section>


</div><!-- .poster-canvas -->

</body>
</html>
