

# 营销长图海报生成器

将用户需求拆分为「主视觉图片区」+「结构化内容区」，分别用 AI 图片生成和 HTML/CSS 实现，最终组合为一张可直接分享的移动端长图海报 HTML。

## 适用场景

- 校招/社招海报
- 活动推广海报
- 产品发布海报
- 促销/折扣活动海报
- 任何需要「上图下文」结构的营销长图



---

## 工作流程（7 步）

### Step 1: 内容收集

采用「两阶段收集」确保用户内容完整准确。

**Phase A — 自由输入**

分析用户提供的所有素材（文本、文档、描述、截图等），提取结构化内容。向用户展示提取摘要，明确标注已提取字段和缺失字段。

示例输出：

```
我已分析您提供的内容，提取到以下信息：

公司名称：Acme Technologies
招聘岗位：高级前端开发工程师
岗位职责：[已提取 4 条]
任职要求：[已提取 5 条]
薪资范围：未提供
福利待遇：未提供
联系邮箱：hr@acme.com（从文本中提取）
```

如果用户提供的内容不足以覆盖必填字段（见 scenarios.md 中的 Content Schema），主动引导用户补充。

**Phase B — AskUserQuestion 确认与补全**

使用 AskUserQuestion 提问 2-3 个问题：

**Q1 — 内容确认：**

```
header: "内容确认"
question: "以上提取的内容是否准确？"
multiSelect: false
options:
  - label: "内容正确"
    description: "按提取内容继续制作"
  - label: "需要修改"
    description: "我会在下条消息中提供修改"
```

**Q2 — 可选区块（multiSelect=true，选项因场景而异，见 scenarios.md）：**

```
header: "内容板块"
question: "需要包含哪些额外板块？"
multiSelect: true
options: (根据场景从 scenarios.md 获取)
```

**Q3 — 设计调性：**

```
header: "设计风格"
question: "海报的视觉风格偏好？"
multiSelect: false
options:
  - label: "精致商务"
    description: "深蓝金色系，衬线标题字体，沉稳优雅"
  - label: "科技现代"
    description: "深色背景，青色/霓虹强调色，几何元素"
  - label: "温暖亲和"
    description: "暖色调，圆润造型，友好亲切"
  - label: "大胆活力"
    description: "高饱和色彩，强对比，视觉冲击力"
```

用户选择可选区块后，如有对应字段缺失，再追问一轮收集具体数据。

### Step 2: 场景识别与设计方向

1. 识别场景类型（招聘 / 活动 / 产品 / 促销 / 自定义）
2. 校验内容是否覆盖场景必填字段（见 scenarios.md 的 Content Schema）
3. 根据 Q3 答案确定设计方向

**Design Tone → 具体决策：**

| Tone | Display Font | Body Font | Accent Font | 配色风格 | 纹理 |
|------|-------------|-----------|-------------|---------|------|
| 精致商务 | Noto Serif SC | Noto Sans SC | Playfair Display | Navy + Gold on cream | Dot grid |
| 科技现代 | Noto Sans SC:900 | Noto Sans SC:400 | Space Mono | Black + Cyan on dark | Diagonal lines |
| 温暖亲和 | ZCOOL XiaoWei | Noto Sans SC | DM Serif Display | Terracotta + Amber on warm white | None |
| 大胆活力 | Noto Sans SC:900 | Noto Sans SC | Outfit | Purple + Orange on lavender | Geometric grid |

**内容分区规则：**

| 放入图片（氛围感/情绪） | 放入 HTML（精确/可编辑） |
|------------------------|------------------------|
| 主标题 / 品牌 Slogan | 次级标题、段落正文 |
| 品牌名 / 活动名 | 列表、需求条目、特性描述 |
| 情绪渲染文案（装饰性） | 时间、地点、价格等精确信息 |
| 产品名 / 活动主题 | 联系方式、二维码、条款 |

### Step 3: 定义色彩与排版方案

**先定颜色和字体，再生成图片。**

定义 8 个色彩变量 + 3 个字体变量：

```css
:root {
  --color-primary: #1a237e;
  --color-secondary: #c9a84c;
  --color-bg: #f5f0e8;
  --color-bg-alt: #ede7db;
  --color-text: #1a1a2e;
  --color-text-muted: #6b6b7b;
  --color-accent: #c9a84c;
  --color-card-bg: #ffffff;
  --font-display: 'Noto Serif SC', serif;
  --font-body: 'Noto Sans SC', sans-serif;
  --font-accent: 'Playfair Display', serif;
}
```

**三个字体槽位：**

| 槽位 | 用途 | Tailwind class |
|------|------|---------------|
| Display | 区块标题、大标题、引用文字 | `font-display` |
| Body | 正文、卡片描述、列表项 | `font-body` |
| Accent | 大数字、英文副标题、时间标记 | `font-accent` |

**色彩预设参考（可根据 Design Tone 选择或自定义）：**

| 风格 | Primary | Secondary | BG | BG-Alt | Text |
|------|---------|-----------|-----|--------|------|
| 精致商务 | `#1a237e` | `#c9a84c` | `#f5f0e8` | `#ede7db` | `#1a1a2e` |
| 科技现代 | `#0a0a0a` | `#00e5ff` | `#111111` | `#1a1a1a` | `#ffffff` |
| 温暖亲和 | `#8b4513` | `#d4a574` | `#fef9f3` | `#f5ede3` | `#3e2723` |
| 大胆活力 | `#6200ea` | `#ff6d00` | `#f3e5f5` | `#ead6f0` | `#311b92` |
| 温暖节庆 | `#c62828` | `#ffab00` | `#fff8e1` | `#f5edd4` | `#3e2723` |
| 清新自然 | `#2e7d32` | `#ffd54f` | `#f1f8e9` | `#e4f0da` | `#1b5e20` |
| 极简克制 | `#212121` | `#ff5722` | `#fafafa` | `#f0f0f0` | `#212121` |

### Step 4: 生成主视觉图片

使用可用的图片生成工具，按以下结构组装 prompt：

```
[场景/主体描述]
[风格与媒介——须与选定 design tone 一致]
[明确的色彩指定，含 hex 值]
[构图说明：顶部至少 1/3 留白/轻元素呼吸区，底部 15% 为纯色/渐变过渡带]
[图内文字说明]
[负面约束]
```

**关键约束：**
- **宽高比至少 1:1（正方形），推荐 3:4 或 2:3（竖版）**——图片应有充足的纵向空间
- **图片顶部至少 1/3 保持留白**或仅有轻量装饰元素，让视觉有充足的呼吸感，避免内容顶头
- 图片底部 15% 必须是纯色或渐变色带，颜色等于 `--color-bg` 或 `--color-primary`
- 主文字安排在图片中下部区域（纵向 35%-80%），顶部留白不放主要内容
- 推荐尺寸：宽 1500px（2x 缩放），高度按比例——1:1 为 1500x1500，3:4 为 1500x2000
- 图片在 HTML 中以 750px 宽度显示


**关键**：生成完成主图后不要直接进入下一步，需要用户确认主图的效果，但要使用<Next-action>标签作下一步引导。


### Step 5: 创意设计内容区

> **核心原则：[template-reference.html](template-reference.html) 是设计词汇表，不是复制源。**

你的职责是：

1. 理解模板中每种区块的**设计语言**（间距节奏、字体搭配、色彩层次、几何图标系统）
2. 根据当前海报的具体内容和用户选择，**原创设计**每个区块的 HTML/Tailwind 代码
3. 允许且鼓励：调整比例、混搭元素、发明模板中没有的新排版方式、改变卡片布局
4. **禁止：整段复制模板代码只替换文字内容**——每张海报都应该是独特的

各场景的 Q2 选项→区块映射见 [scenarios.md](scenarios.md)。

#### 严格遵从用户选择

内容区**只**包含以下区块，不多不少：

| 类型 | 包含条件 | 说明 |
|------|---------|------|
| 主视觉图片 | 始终包含 | 海报顶部的 AI 生成图片 |
| 必填内容展示 | 始终包含 | 用户提供的必填字段（如职责、要求），展示方式由你根据内容量和调性自由决定 |
| 可选区块 | **仅当用户在 Q2 中勾选时** | 严格按 scenarios.md 的映射表对应 |
| CTA / Footer（含二维码） | **仅当用户提供了二维码/联系方式，或在 Q2 中勾选时** | 用户没有提供联系方式也没有要求二维码，就不出现此区块 |

**红线规则：**

- 如果用户原始内容中包含某类信息，但 Q2 中**未勾选**对应板块 → 不要自作主张添加，忽略该信息或回头追问用户
- 绝不出现用户没有要求的区块。**宁可海报简洁也不要臃肿**
- 必填内容的展示方式不绑定固定区块类型——同样的职责列表可以用 Feature List、Card Grid、编号段落、甚至纯文本排版，取决于内容量和设计判断

#### 美学规则

**1. 禁止 emoji**

所有图标使用 CSS 几何形状或极简 inline SVG。template-reference.html 展示了 6 种几何图标作为灵感参考。
你也可以发明自己的几何形状。仅当内容确实需要可识别符号时（如医疗十字、时钟），使用极简线条 SVG，不超过 3 条 path。

**2. 视觉节奏**

- 连续 section 交替使用不同底色（浅色交替或深浅对比）
- 内容区块 ≥ 3 个时，考虑插入一个深色反转 section 打破单调
- 背景纹理最多用在 2 个 section 上，opacity ≤ 0.06
- 同一海报使用 2 种以上的标题排版方式
- 分割线只在大内容组之间使用，不滥用

**3. 卡片与容器**

卡片需要有视觉深度（阴影 + 边框/色带），但具体实现方式自由发挥——不必拘泥于模板中的固定写法。

**4. 字体配对**

- 标题层级用 `font-display`
- 正文/描述用 `font-body`
- 数字/英文/时间等特殊元素用 `font-accent`
- 三种字体必须在海报中各出现至少 1 次

### Step 6: 组装最终 HTML

将主视觉图片和内容区 HTML 组装为单个自包含文件。

**HTML 骨架（使用 Tailwind CDN）：**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=750">
  <title>海报标题</title>
  <!-- Google Fonts: 根据 design tone 加载 2-3 种字体 -->
  <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+SC:wght@600;700;900&family=Noto+Sans+SC:wght@400;500;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">
  <!-- Tailwind CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            primary: 'var(--color-primary)',
            secondary: 'var(--color-secondary)',
            'bg-base': 'var(--color-bg)',
            'bg-alt': 'var(--color-bg-alt)',
            'text-main': 'var(--color-text)',
            'text-muted': 'var(--color-text-muted)',
            accent: 'var(--color-accent)',
            'card-bg': 'var(--color-card-bg)',
          },
          fontFamily: {
            display: ['var(--font-display)'],
            body: ['var(--font-body)'],
            accent: ['var(--font-accent)'],
          },
        }
      }
    }
  </script>
  <style>
    :root {
      /* 按 Step 3 定义的变量填入 */
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      width: 750px;
      margin: 0 auto;
      background: var(--color-bg);
      font-family: var(--font-body);
      -webkit-font-smoothing: antialiased;
      overflow-x: hidden;
      color: var(--color-text);
    }
    .poster-canvas { width: 750px; overflow: hidden; }
    .hero-wrapper { position: relative; line-height: 0; }
    .hero-image { display: block; width: 100%; height: auto; }
    .hero-wrapper--gradient::after {
      content: '';
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: 120px;
      background: linear-gradient(to bottom, transparent, var(--color-bg));
      pointer-events: none;
    }
    /* 背景纹理 */
    .pattern-dots {
      background-image: radial-gradient(circle, var(--color-primary) 1px, transparent 1px);
      background-size: 24px 24px;
      opacity: 0.04;
      position: absolute; inset: 0; pointer-events: none;
    }
    .pattern-diag {
      background-image: repeating-linear-gradient(
        -45deg, var(--color-primary), var(--color-primary) 1px,
        transparent 1px, transparent 12px
      );
      opacity: 0.03;
      position: absolute; inset: 0; pointer-events: none;
    }
    .pattern-grid {
      background-image:
        linear-gradient(var(--color-secondary) 1px, transparent 1px),
        linear-gradient(90deg, var(--color-secondary) 1px, transparent 1px);
      background-size: 32px 32px;
      opacity: 0.04;
      position: absolute; inset: 0; pointer-events: none;
    }
  </style>
</head>
<body>
  <div class="poster-canvas">
    <div class="hero-wrapper hero-wrapper--gradient">
      <img class="hero-image" src="./poster-hero.png" alt="海报主视觉">
    </div>
    <div class="content-zone">
      <!-- 从 template-reference.html 选取的区块 -->
    </div>
  </div>
</body>
</html>
```

**过渡区处理（三种方案选其一）：**

| 方案 | 适用场景 | 实现方式 |
|------|---------|---------|
| 纯色匹配（默认） | 通用 | 图片底部纯色 = 内容区首个 section 背景色 |
| 渐变叠加 | 高端/优雅场景 | `.hero-wrapper--gradient` |
| 波浪分割 | 活泼/创意场景 | `clip-path` 波浪 SVG |

### Step 7: 质量检查

交付前逐项确认：

- [ ] 图片与内容区使用同一套色彩方案
- [ ] 图片底部与 HTML 顶部无可见接缝
- [ ] 所有文字清晰可读（对比度足够）
- [ ] 字号为海报尺度（正文 ≥ 26px，标题 ≥ 32px，大数字 ≥ 64px）确保移动端可读性
- [ ] 无网页交互元素
- [ ] 海报整体高度比例合理（图片占 35-55%）
- [ ] CTA/页脚区视觉突出且引导明确
- [ ] 二维码区域有清晰占位
- [ ] 画布恰好 750px 宽
- [ ] **字体配对已应用（display / body / accent 三种字体各出现至少 1 次）**
- [ ] **海报中无任何 emoji**
- [ ] **至少 2 种不同的 section 背景处理**
- [ ] **至少 1 个深色反转 section**
- [ ] **背景纹理 opacity ≤ 0.06**
- [ ] **卡片有 shadow 和彩色边框**
- [ ] **至少使用了 2 种标题排版方式**
- [ ] **每个内容区块都能追溯到用户的明确选择（Q2 勾选或必填字段）**
- [ ] **没有任何用户未要求的"bonus"区块**
- [ ] **HTML 代码不是模板的逐字复制——每个区块都有原创的排版处理**

---

## 海报尺度参考

### 海报高度控制

由于主视觉图片采用至少 1:1 的竖版比例，整体海报会更长。以下为参考：

| 内容量 | 图片建议高度 | 内容区建议高度 | 海报总高度 |
|--------|------------|-------------|-----------|
| 轻量（2-3 个区块） | 750-1000px | 600-800px | 1400-1800px |
| 中等（4-5 个区块） | 750-1000px | 1000-1500px | 1800-2500px |
| 重量（6+ 个区块） | 750-1000px | 1500-2000px | 2300-3000px |

超过 3000px 建议精简内容。

### 字号参考

| 元素 | 推荐字号 | 字重 | 字体槽 |
|------|---------|------|--------|
| 区块标题 | 32-36px | 700 | display |
| 正文内容 | 26-28px | 400 | body |
| 卡片标题 | 26px | 700 | display |
| 卡片描述 | 22px | 400 | body |
| 大数字 | 64-80px | 900 | accent |
| 英文副标题 | 20-22px | 400-700 | accent |
| KV 标签 | 26px | 700 | display |
| 时间标记 | 22px | 700 | accent |
| 页脚文字 | 18-22px | 400 | body |

### 间距参考

| 元素 | 推荐值 |
|------|--------|
| 画布水平内边距 | 48px |
| section 间距 | 40px |
| 卡片间距 | 20px |
| 卡片内边距 | 24-28px |
| 列表项间距 | 20px |

---

## 附加资源，生成之前请先参考这些问题文件！

- 完整的区块参考和 Tailwind 代码：见 [template-reference.html](template-reference.html)
- 各场景详细指导、内容 Schema 和示例：见 [scenarios.md](scenarios.md)
