# 长图文海报设计专家

- 文件夹名：`06-长图文海报设计专家__poster-longimage__GRFd3ATNnt`
- publicId：`GRFd3ATNnt`
- name：`poster-longimage`
- 分类：未标注
- 版本：21
- 更新时间：2026-06-04T14:57:19.000+00:00
- 来源：https://d.design/api/agent/v1/skills/GRFd3ATNnt

## 能干什么

当用户需要促销活动长图，社交媒体传播用长图文等长图内容时使用此技能。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
