---
title: "Proposal HTML Section Templates"
type: "reference"
---

# Proposal HTML Section Templates

CSS framework + HTML templates for the 9-section brand proposal. Page uses exactly 3 fonts, supports dark/light/colored backgrounds, and includes orphan/widow prevention for CJK and Latin text.

## Global Styles

The page uses **exactly 3 fonts**: one display (serif/decorative), one body (sans-serif), and one mono (for labels/metadata). The background is NOT restricted to dark — choose based on brand direction (dark, light, or colored). Orphan/widow control and CJK-aware line breaks are built in.

```html
<style>
  *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }
  html { scroll-behavior: smooth; }

  :root {
    /* BACKGROUND DIRECTION — choose ONE per brand, delete the others */
    /* Dark:    --ink: #050505;  --text-1: #e8e8e8; --text-2: rgba(255,255,255,0.45); --text-3: rgba(255,255,255,0.22); --card-bg: #0c0c0c; --surface: #111; --hairline: rgba(255,255,255,0.08); */
    /* Light:   --ink: #f5f3ef;  --text-1: #1a1a1a; --text-2: rgba(0,0,0,0.5); --text-3: rgba(0,0,0,0.25); --card-bg: #ffffff; --surface: #eae8e3; --hairline: rgba(0,0,0,0.08); */
    /* Colored: --ink: [brand-tinted bg]; adjust text/card colors accordingly */

    --ink: #050505;
    --text-1: #e8e8e8;
    --text-2: rgba(255,255,255,0.45);
    --text-3: rgba(255,255,255,0.22);
    --card-bg: #0c0c0c;
    --surface: #111;
    --hairline: rgba(255,255,255,0.08);
    --paper: #f0efeb;

    --brand-primary: #2a5cff;
    --brand-accent: #ff6b2a;

    /* === 3 FONTS ONLY — pick one set from design-integration.md Style Presets === */
    --font-display: 'Instrument Serif', serif;
    --font-body: 'Instrument Sans', sans-serif;
    --font-mono: 'JetBrains Mono', monospace;
  }

  body {
    background: var(--ink); color: var(--text-1);
    font: 400 15px/1.65 var(--font-body);
    -webkit-font-smoothing: antialiased;
  }

  /* Grain texture overlay */
  body::after {
    content: ''; position: fixed; inset: 0;
    pointer-events: none; z-index: 9999; opacity: 0.03;
    background: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E") repeat;
    background-size: 128px 128px;
  }

  /* === LINE-BREAK & ORPHAN CONTROL === */
  p, h1, h2, h3, span, div {
    word-break: keep-all;        /* CJK: prevent mid-word breaks */
    overflow-wrap: break-word;   /* fallback for long strings */
    text-wrap: pretty;           /* modern browsers: avoid orphans/widows */
  }
  /* For headlines: prevent single-character orphans in CJK */
  .t-display { text-wrap: balance; }

  .frame { max-width: 1280px; margin: 0 auto; padding: 0 60px; }
  .section { padding: 140px 0; position: relative; }
  .section + .section { border-top: 1px solid var(--hairline); }

  .g2 { display: grid; grid-template-columns: 1fr 1fr; gap: 2px; }
  .g3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 2px; }
  .g4 { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 2px; }
  .g-asym { display: grid; grid-template-columns: 1fr 1.618fr; gap: 2px; }
  .g-asym-r { display: grid; grid-template-columns: 1.618fr 1fr; gap: 2px; }

  .block { background: var(--card-bg); border: 1px solid var(--hairline); padding: 48px; position: relative; }

  .t-label--num { font: 400 10px var(--font-mono); letter-spacing: 0.14em; text-transform: uppercase; color: var(--text-3); padding-bottom: 32px; border-bottom: 1px solid var(--hairline); margin-bottom: 48px; }
  .t-display { font: 400 1em/1.08 var(--font-display); letter-spacing: -0.02em; color: var(--text-1); }
  .t-display--xl { font-size: clamp(56px,8vw,96px); }
  .t-display--lg { font-size: clamp(36px,4.5vw,56px); }
  .t-display--md { font-size: clamp(24px,3vw,36px); }
  .t-display--sm { font-size: 22px; }
  .t-body { font-size: 15px; color: var(--text-2); line-height: 1.7; }
  .t-body--lg { font-size: 18px; color: var(--text-2); line-height: 1.7; }
  .t-kicker { font: 400 11px var(--font-mono); letter-spacing: 0.1em; text-transform: uppercase; color: var(--brand-primary); margin-bottom: 12px; }
  .t-meta { font: 400 11px var(--font-mono); color: var(--text-3); letter-spacing: 0.04em; }

  .logo-wrap { display: flex; align-items: center; justify-content: center; }
  .logo-wrap img { max-width: 100%; height: auto; object-fit: contain; }
  .logo-mono img { filter: grayscale(100%) brightness(0); }
  .logo-reversed img { filter: grayscale(100%) brightness(0) invert(1); }

  .hl { color: var(--brand-primary); }
  .hairline { height: 1px; background: var(--hairline); }
</style>
```

### Font Rules (non-negotiable)

1. **Exactly 3 `@import` / `<link>` fonts per page** — one display, one body, one mono. No exceptions.
2. The font trio is selected from `design-integration.md` Style Presets based on brand keywords.
3. **Section 05 (Color & Typography)** is the ONLY place that may visually *recommend* additional fonts for the brand's future use — but those recommended fonts are NOT loaded or used elsewhere on the page.
4. All `font-family` declarations in CSS must resolve to one of the 3 loaded fonts.

### Background Direction

Choose based on brand personality — dark is NOT the default:

| Direction | When to Use | Key Vars |
|-----------|-------------|----------|
| Dark | Tech, luxury, editorial, cinematic brands | `--ink: #050505`, light text |
| Light | Organic, warm, approachable, lifestyle brands | `--ink: #f5f3ef`, dark text |
| Colored | Bold, playful, or brands with strong color identity | `--ink: [brand-tinted]`, adjust contrast |

---

## Section 01: Cover — Striking Typographic Design

Full-viewport. Brand name as typographic art — NOT a plain centered heading. Use dramatic scale contrast, asymmetric positioning, intentional line breaks. Logo sits small (40-80px) while typography does the heavy lifting. Tagline in tiny mono type, positioned away from the brand name.

```html
<section class="section" style="min-height: 100vh; display: flex; position: relative; overflow: hidden;">
  <div class="frame" style="display: flex; flex-direction: column; justify-content: space-between; width: 100%; padding-top: 60px; padding-bottom: 60px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
      <div class="logo-wrap" style="max-width: 56px;">[LOGO]</div>
      <span class="t-meta">Brand Proposal / [YEAR]</span>
    </div>
    <div style="position: relative; margin: auto 0;">
      <div style="position: absolute; top: -20%; left: -5%; font-family: var(--font-display); font-size: clamp(300px,40vw,600px); line-height: 0.8; color: rgba(255,255,255,0.025); pointer-events: none; user-select: none;">[FIRST_LETTER]</div>
      <h1 style="font-family: var(--font-display); font-size: clamp(72px,12vw,180px); font-weight: 400; line-height: 0.92; letter-spacing: -0.04em; position: relative; z-index: 1;">
        [BRAND_NAME_LINE_1]<br><span style="color: var(--brand-primary);">[BRAND_NAME_LINE_2]</span>
      </h1>
    </div>
    <div style="display: flex; justify-content: flex-end; align-items: flex-end; gap: 40px;">
      <div style="width: 48px; height: 1px; background: var(--brand-primary); margin-bottom: 6px;"></div>
      <p style="font: 400 11px/1.6 var(--font-mono); letter-spacing: 0.12em; text-transform: uppercase; color: var(--text-2); max-width: 320px; text-align: right;">[TAGLINE]</p>
    </div>
  </div>
</section>
```

**Alternate compositions** (pick one per brand for uniqueness): (A) Brand name left-aligned, tagline rotated 90° along right edge. (B) Brand name fills full viewport width, tagline in tiny mono with 80px gap below. (C) Slight CSS transform skew for diagonal energy.

---

## Section 02: Value Proposition — Manifesto Tagline

Near full-viewport. One sentence only — the brand's core belief. NOT a slogan or mission statement. Think Apple "Think Different" level. Display type 32-56px, generous whitespace, one brand-color accent detail.

```html
<section class="section" style="min-height: 80vh; display: flex; align-items: center;">
  <div class="frame">
    <p class="t-label--num">01 — Belief</p>
    <div style="max-width: 900px;">
      <p class="t-display" style="font-size: clamp(32px,5vw,56px); line-height: 1.35;">
        [VALUE_TAGLINE_PART_1] <span style="color: var(--brand-primary);">[HIGHLIGHTED_WORD]</span> [VALUE_TAGLINE_PART_2]<span style="color: var(--brand-primary);">.</span>
      </p>
      <div style="width: 40px; height: 1px; background: var(--brand-primary); margin-top: 48px;"></div>
    </div>
  </div>
</section>
```

---

## Section 03: Logo / Graphic Creative Rationale

Asymmetric 2-column. Left: creative concept narrative — why this logo/graphic direction was chosen, the core idea, visual metaphor, and how it connects to brand values. Right: construction sketch or breakdown showing key design elements, proportions, and meaning.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">02 — Creative Rationale</p>
    <div class="g-asym-r">
      <div style="padding-right: 80px;">
        <p class="t-kicker">Design Concept</p>
        <p class="t-display t-display--md" style="line-height: 1.4; margin-bottom: 32px;">[CONCEPT_HEADLINE — e.g. "The Interlocking Horizon"]</p>
        <p class="t-body--lg" style="line-height: 1.85; margin-bottom: 32px;">[CREATIVE_NARRATIVE — 3-5 sentences explaining the visual metaphor, what the logo form represents, how it relates to the brand's core values, and what emotion it intends to evoke]</p>
        <div style="width: 32px; height: 1px; background: var(--brand-primary);"></div>
      </div>
      <div class="block">
        <p class="t-kicker">Element Breakdown</p>
        <div style="display: flex; flex-direction: column; gap: 28px;">
          <!-- Repeat 3-4 times for each design element -->
          <div style="display: grid; grid-template-columns: 48px 1fr; gap: 16px; align-items: start;">
            <div style="width: 48px; height: 48px; border: 1px solid var(--hairline); display: flex; align-items: center; justify-content: center;">
              <span class="t-meta" style="font-size: 16px;">[ICON_OR_NUMBER]</span>
            </div>
            <div>
              <p style="font-weight: 600; font-size: 14px; margin-bottom: 6px; color: var(--text-1);">[ELEMENT_NAME — e.g. "Negative Space Arrow"]</p>
              <p class="t-body">[ELEMENT_EXPLANATION — what it represents, why it matters]</p>
            </div>
          </div>
        </div>
        <div class="hairline" style="margin: 28px 0;"></div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
          <div>
            <p class="t-meta" style="margin-bottom: 8px;">LOGO TYPE</p>
            <p class="t-body">[Wordmark / Symbol / Combination / etc.]</p>
          </div>
          <div>
            <p class="t-meta" style="margin-bottom: 8px;">STYLE DIRECTION</p>
            <p class="t-body">[Minimalist / Modern-Tech / Organic / etc.]</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
```

---

## Section 04: Logo System

3 blocks edge-to-edge. Dark / light / black backgrounds.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">03 — Logo System</p>
    <div class="g3">
      <div class="block" style="min-height: 320px; display: flex; align-items: center; justify-content: center; position: relative;">
        <div class="logo-wrap" style="max-width: 200px;">[LOGO_STANDARD]</div>
        <span class="t-meta" style="position: absolute; bottom: 20px; left: 24px;">Standard</span>
      </div>
      <div class="block" style="min-height: 320px; display: flex; align-items: center; justify-content: center; background: var(--paper); position: relative;">
        <div class="logo-wrap logo-mono" style="max-width: 200px;">[LOGO_MONO]</div>
        <span class="t-meta" style="position: absolute; bottom: 20px; left: 24px; color: rgba(0,0,0,0.3);">Monochrome</span>
      </div>
      <div class="block" style="min-height: 320px; display: flex; align-items: center; justify-content: center; background: #000; position: relative;">
        <div class="logo-wrap logo-reversed" style="max-width: 200px;">[LOGO_REVERSED]</div>
        <span class="t-meta" style="position: absolute; bottom: 20px; left: 24px;">Reversed</span>
      </div>
    </div>
  </div>
</section>
```

---

## Section 05: Color & Typography

Asymmetric. Left: palette swatches. Right: type specimen.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">04 — Visual System</p>
    <div class="g-asym">
      <div>
        <p class="t-kicker" style="margin-bottom: 24px;">Color Palette</p>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2px;">
          <div style="background: var(--brand-primary); height: 160px; padding: 16px; display: flex; flex-direction: column; justify-content: flex-end;">
            <span style="font: 10px var(--font-mono); color: rgba(255,255,255,0.8); letter-spacing: 0.06em;">PRIMARY</span>
            <span style="font: 12px var(--font-mono); color: rgba(255,255,255,0.6); margin-top: 4px;">[HEX_PRIMARY]</span>
          </div>
          <div style="background: var(--brand-accent); height: 160px; padding: 16px; display: flex; flex-direction: column; justify-content: flex-end;">
            <span style="font: 10px var(--font-mono); color: rgba(255,255,255,0.8); letter-spacing: 0.06em;">ACCENT</span>
            <span style="font: 12px var(--font-mono); color: rgba(255,255,255,0.6); margin-top: 4px;">[HEX_ACCENT]</span>
          </div>
          <div style="background: var(--card-bg); height: 120px; padding: 16px; display: flex; flex-direction: column; justify-content: flex-end; border: 1px solid var(--hairline);">
            <span style="font: 10px var(--font-mono); color: var(--text-3); letter-spacing: 0.06em;">SURFACE</span>
            <span style="font: 12px var(--font-mono); color: var(--text-3); margin-top: 4px;">[HEX_SURFACE]</span>
          </div>
          <div style="background: var(--paper); height: 120px; padding: 16px; display: flex; flex-direction: column; justify-content: flex-end;">
            <span style="font: 10px var(--font-mono); color: rgba(0,0,0,0.4); letter-spacing: 0.06em;">PAPER</span>
            <span style="font: 12px var(--font-mono); color: rgba(0,0,0,0.35); margin-top: 4px;">[HEX_PAPER]</span>
          </div>
        </div>
      </div>
      <div>
        <p class="t-kicker" style="margin-bottom: 24px;">Typography</p>
        <div class="block" style="min-height: 340px; display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <p style="font: 400 72px/1 var(--font-display); letter-spacing: -0.03em; margin-bottom: 8px;">Aa</p>
            <p class="t-meta">[DISPLAY_FONT] — Display</p>
          </div>
          <div class="hairline" style="margin: 24px 0;"></div>
          <div>
            <p style="font: 400 48px/1 var(--font-body); margin-bottom: 8px;">Aa</p>
            <p class="t-meta">[BODY_FONT] — Body</p>
          </div>
          <div class="hairline" style="margin: 24px 0;"></div>
          <p style="font: 14px var(--font-body); color: var(--text-3); line-height: 1.8;">ABCDEFGHIJKLMNOPQRSTUVWXYZ<br>abcdefghijklmnopqrstuvwxyz<br>0123456789</p>
        </div>
      </div>
    </div>
  </div>
</section>
```

---

## Section 06: Brand Applications

4 images, 4:3 ratio, gradient label overlay.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">05 — Applications</p>
    <div class="g4">
      <!-- Repeat this block 4 times with [IMG_1-4] and [SCENARIO_1-4_LABEL] -->
      <div style="aspect-ratio: 4/3; overflow: hidden; position: relative;">
        <img src="[IMG_N]" alt="[SCENARIO_N]" style="width: 100%; height: 100%; object-fit: cover; display: block;">
        <div style="position: absolute; bottom: 0; left: 0; right: 0; padding: 20px; background: linear-gradient(transparent, rgba(0,0,0,0.8));">
          <span class="t-meta" style="color: rgba(255,255,255,0.7);">[SCENARIO_N_LABEL]</span>
        </div>
      </div>
    </div>
  </div>
</section>
```

---

## Section 07: Copywriting

Full-width slogan in display type, then asymmetric split: brand story + message pillars.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">06 — Brand Voice</p>
    <p class="t-display t-display--lg" style="max-width: 900px; margin-bottom: 16px; font-style: italic;">"[SLOGAN]"</p>
    <div style="width: 48px; height: 1px; background: var(--brand-primary); margin-bottom: 80px;"></div>
    <div class="g-asym">
      <div>
        <p class="t-kicker">Brand Story</p>
        <p class="t-body--lg" style="line-height: 1.85;">[BRAND_STORY]</p>
      </div>
      <div>
        <p class="t-kicker">Core Messages</p>
        <div style="display: flex; flex-direction: column; gap: 32px;">
          <!-- Repeat 3 times for each pillar -->
          <div style="padding-left: 20px; border-left: 1px solid var(--brand-primary);">
            <p style="font-weight: 600; font-size: 14px; margin-bottom: 8px; color: var(--text-1);">[PILLAR_N]</p>
            <p class="t-body">[PILLAR_N_MSG]</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
```

---

## Section 08: Implementation

3-phase blocks with top accent lines, then channel chips.

```html
<section class="section">
  <div class="frame">
    <p class="t-label--num">07 — Implementation</p>
    <div class="g3" style="margin-bottom: 64px;">
      <!-- Repeat 3 times: --brand-primary / --brand-accent / --hairline top borders -->
      <div class="block" style="border-top: 2px solid var(--brand-primary);">
        <p class="t-kicker" style="margin-top: 8px;">Phase N</p>
        <p class="t-display t-display--sm" style="margin-bottom: 8px;">[PHASE_TITLE]</p>
        <p class="t-meta" style="margin-bottom: 28px;">[PHASE_TIME]</p>
        <div style="display: flex; flex-direction: column; gap: 12px;">
          <p class="t-body">[TASK_1-4]</p>
        </div>
      </div>
    </div>
    <p class="t-kicker" style="margin-bottom: 20px;">Recommended Channels</p>
    <div style="display: flex; flex-wrap: wrap; gap: 2px;">
      <!-- Repeat 4 times -->
      <div style="padding: 16px 24px; border: 1px solid var(--hairline); flex: 1; min-width: 200px;">
        <p style="font-weight: 600; font-size: 13px; margin-bottom: 4px; color: var(--text-1);">[CHANNEL]</p>
        <p class="t-meta">[REASON]</p>
      </div>
    </div>
  </div>
</section>
```

---

## Section 09: Footer

```html
<footer style="padding: 48px 0;">
  <div class="frame">
    <div class="hairline" style="margin-bottom: 24px;"></div>
    <div style="display: flex; justify-content: space-between; align-items: center;">
      <span class="t-meta">[BRAND_NAME] Brand Proposal</span>
      <span class="t-meta">Confidential / [YEAR]</span>
    </div>
  </div>
</footer>
```
