---
title: "Brand Strategy Framework"
type: "reference"
---

# Brand Strategy Framework

Content guidelines for the brand proposal's strategy sections.

## 1. Value Proposition Tagline

A single sentence capturing the brand's **core belief about the world**. Not a slogan, not a mission — a manifesto line.

**Criteria**: Insightful (makes reader pause), brand-specific (can't swap in a competitor), belief-driven (what the brand believes, not what it does), emotionally resonant, max 15-20 words.

**Approaches**:

| Pattern | Example |
|---------|---------|
| Redefinition | "Strength isn't built in the gym. It's built in the moment you almost quit." |
| Elevation | "Every cup is a conversation between the farmer's hands and yours." |
| Provocation | "The most sustainable garment is the one you never throw away." |
| Human Truth | "The best version of yourself lives in a city you haven't visited yet." |
| Transformation | "The question you're afraid to ask is the one that changes everything." |

**Never write**: Generic corporate ("Innovating for a better tomorrow"), feature-based ("The fastest solution"), meaningless superlatives ("The future of X"), buzzword soup ("Leveraging synergy").

---

## 2. Logo / Graphic Creative Rationale

Explain the design thinking behind the logo or core graphic. This is NOT a description of what the logo looks like — it's the WHY behind each design decision.

### Creative Concept

A short conceptual headline (3-8 words) followed by a narrative paragraph (3-5 sentences). Structure:

```
Concept Headline: A poetic or provocative name for the design direction
  e.g. "The Interlocking Horizon", "Breath Between Letters", "Rooted Geometry"

Narrative: Explain in prose —
  1. What visual metaphor drives the design
  2. How the form connects to the brand's core values or story
  3. What emotion or impression it aims to create in the viewer
  4. Why this direction (not another) suits this particular brand
```

**Criteria**: Conceptual (not descriptive), brand-specific (the same rationale can't apply to another brand), insightful (reveals a layer the viewer might not immediately see).

### Element Breakdown

Identify 3-4 key design elements and explain each:

```
Per element:
  Name: A clear label (e.g. "Negative Space Arrow", "Rising Curve", "Serif Tail")
  Explanation: 1-2 sentences on what it represents and why it was chosen
```

### Metadata

Include two factual labels:

- **Logo Type**: Symbol / Wordmark / Lettermark / Combination / Emblem / Mascot
- **Style Direction**: Minimalist / Modern-Tech / Vintage / Organic / Playful / Luxury

---

## 3. Copywriting

**Slogan**: 3-7 words, rhythmic/alliterative. Patterns: action-based ("Just Do It"), promise-based, question-based, contrast-based.

**Brand Story**: 150-200 words. Structure: Origin (why born, 2-3 sentences) → Challenge (obstacle, 1-2 sentences) → Philosophy (beliefs, 2-3 sentences) → Promise (commitment, 1-2 sentences). Tone matches brand personality.

**Core Messages**: 3 pillars, each with: topic/theme, one-sentence core message, one-sentence proof point.

---

## 4. Implementation

**3 Phases**: Foundation (Month 1-2: identity, collateral, website, training) → Launch (Month 3-4: event, social campaign, PR, partnerships) → Growth (Month 5-12: community, content, feedback loop, optimization).

**Channels**: Recommend 4-5 from: Social Media, Content, Experiential, Digital Ads, PR & Media, Community. Match to brand personality and target audience.
