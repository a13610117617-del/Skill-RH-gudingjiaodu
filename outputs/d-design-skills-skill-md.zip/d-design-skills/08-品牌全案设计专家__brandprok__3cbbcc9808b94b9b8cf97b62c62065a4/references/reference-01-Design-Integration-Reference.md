---
title: "Design Integration Reference"
type: "reference"
---

# Design Integration Reference

Style presets, logo generation, mockup scenarios, logo handling, and color system.

## Style Presets

ALL presets: `border-radius: 0`, `box-shadow: none`, no emojis.

---

## Logo Generation (Route C — no uploaded logo)

When user provides only text (no logo file), generate a professional logo using this methodology. All outputs must be **flat vector style** — no 3D, no photorealistic, no complex shadows.

### Step 1: Select Logo Type

| Type | Best For | Prompt Keywords |
|------|----------|-----------------|
| Symbol/Icon | App icons, global brands, strong visual metaphors | `symbol logo`, `icon mark` |
| Wordmark | Short names, fashion, media, luxury | `wordmark logo`, `typography logo` |
| Lettermark | Long names, corporate, monogram traditions | `lettermark`, `monogram` |
| Combination | Most new brands, versatile use (recommended default) | `combination logo`, `icon with wordmark` |
| Emblem/Badge | Heritage, schools, F&B, authority | `emblem logo`, `badge logo` |
| Mascot | Sports, entertainment, children's, food | `mascot logo`, `character logo` |

**Selection guide**: New brand → Combination or Wordmark. Long name → Lettermark. App-first → Symbol. Heritage/traditional → Emblem.

### Step 2: Select Style

| Style | Core Keywords | Colors |
|-------|--------------|--------|
| Minimalist | minimal, clean, geometric, negative space | Limited palette, black + 1 accent |
| Modern/Tech | modern, digital, geometric, grid-based | Blue, cyan, electric tones |
| Vintage/Retro | vintage, heritage, classic, badge shapes | Sepia, cream, burgundy, forest green |
| Organic/Natural | organic, flowing lines, botanical, hand-drawn | Green, earth tones, soft blues |
| Playful | rounded shapes, bright, approachable | Vibrant, multi-color |
| Luxury/Elegant | refined, monogram, serif fonts | Black, gold, navy, burgundy |

### Step 3: Element Fusion (if combining concepts)

| Technique | Description | Prompt Pattern |
|-----------|-------------|----------------|
| Negative Space | Empty space within one element forms another | `[A] with [B] formed in negative space` |
| Silhouette | One element's outline contains another | `[A] silhouette containing [B] inside` |
| Shared Contours | Two elements share a common edge | `[A] and [B] sharing common contour line` |
| Letterform Sub | Parts of letters replaced with visual elements | `Letter "[X]" with [element] replacing [part]` |
| Encapsulation | One element frames another (badge effect) | `[A] inside [B] frame, badge style` |

### Step 4: Build Prompt

**Structure**: `[Style keywords] [Logo type] for "[Brand Name]", [main element description], [composition], [color scheme], flat vector design, clean lines, scalable SVG, professional brand identity`

**Mandatory in every prompt**: `flat vector` + `clean lines` + `scalable`. Keep to 1-2 core visual elements max.

### Step 5: Generate Variations

Generate 3 distinct options when possible:
- **Option A** (Conservative): Timeless, broad appeal, safe
- **Option B** (Modern): Current trends, distinctive, memorable
- **Option C** (Minimal): Maximum simplicity, highest scalability

### Color Palettes for Logos

| Category | Palette |
|----------|---------|
| Corporate | Navy `#1E3A5F` + Gold `#C9A227` |
| Tech | Dark Navy `#0A2540` + Teal `#00D4AA` |
| Natural | Forest `#2D5016` + Sage `#68A357` |
| Luxury | Midnight `#1A1A2E` + Gold `#C9A227` |
| F&B | Coffee `#4A3728` + Golden `#8B6914` |
| Chinese Traditional | Red `#C41E3A` + Gold `#D4AF37` |
| Creative | Purple `#6C5CE7` + Pink `#FD79A8` |

---

## Logo Handling (uploaded logos)

**Format detection**: `<svg` → SVG; `data:image` → base64; file path → read & convert to base64; URL → convert to base64.

**Variants**:
- SVG: modify `fill` directly (standard: original, mono: `#1a1a1a`, reversed: `#ffffff`)
- Image: CSS filters (standard: none, mono: `grayscale(100%) brightness(0)`, reversed: `grayscale(100%) brightness(0) invert(1)`)

---

## Mockup Scenarios

Select 4 from different categories:

| Cat | Scenario | Best For |
|-----|----------|----------|
| A1 | Storefront signage | All |
| A2 | Office reception wall | Tech, Luxury |
| A3 | Cafe interior | Organic |
| B1 | Mobile app splash | All |
| B2 | Website on laptop | Tech, Editorial |
| B4 | Digital billboard | Industrial |
| C1 | Business card set | All |
| C2 | Letterhead & envelope | Luxury, Editorial |
| C3 | Packaging box | All |
| D1 | Branded coffee cup | Organic |
| D2 | Canvas tote bag | Organic |
| D4 | Workspace flat-lay | All |

**Style mapping**: Editorial→A2+B2+C2+D4, Brutalist→A1+B4+C1+D4, Luxury→A2+C2+C3+D4, Industrial→A1+B4+C1+D4, Organic→A3+C3+D2+D4.

**Prompt template**: `[Scene], professional brand mockup, featuring [BRAND] logo [placement], the brand identity uses a [COLOR_NAME] palette ([HEX]), all branded elements reflect this scheme, [material], [lighting], 4:3, ultra-detailed, photorealistic`. Size: 1024x768. i2i reference: LOGO_REF (same for all 4).

---

## Color System

Derived FROM the logo — never invented independently.

```
LOGO_REF → primary color → --brand-primary
         → accent (hue +150°) → --brand-accent
         → neutrals → --card-bg, --surface, --paper
         → scene image prompts (mandatory color directive)
         → Section 05 swatches
```

**Extraction**: SVG → parse `fill="#xxx"`, first non-black/white. Image → identify dominant color visually, translate to hex. Monochrome black → choose by industry.

**Fallback colors**: Editorial `#2a5cff`, Brutalist `#ff3d00`, Luxury `#b8963e`, Industrial `#00e676`, Organic `#7a8c5a`.

**Industry colors**: Tech `#2a5cff`/`#4f46e5`, F&B `#c42b1c`/`#e85d04`, Fashion `#1a1a1a`/`#b8963e`, Health `#2d6a4f`/`#0891b2`, Education `#2a5cff`/`#d97706`.
