---
name: brand-proposal
description: Generate a complete brand strategy and design proposal as a single interactive HTML page. Covers brand value proposition, market positioning, logo design, visual identity, application mockups, copywriting, and implementation plan. Use when user asks for "brand proposal", "品牌提案", "brand strategy", "品牌策略", "branding deck".
---
***图片生成必须使用全新ImageV2模型，图片生成必须使用全新ImageV2模型，图片生成必须使用全新ImageV2模型***

# Brand Proposal Generator

Generate a professional **brand strategy + design proposal** as a single interactive HTML page — client-ready, agency-grade.

## When to Use

User asks for "brand proposal" / "品牌提案" / "branding deck" / "品牌全案" / "brand pitch", or provides a brand name/logo and wants a full strategy + design proposal.

## Design Rules (non-negotiable)

- **Zero border-radius** — sharp corners on everything, no exceptions
- **No emojis** — never, anywhere
- **No box-shadow** — use borders and spacing instead
- **Exactly 3 fonts per page** — one display, one body, one mono (selected from style presets); Section 05 may *recommend* additional fonts for the brand's identity system, but those are NOT loaded or used on the page itself
- **Background not limited to dark** — choose dark / light / colored based on brand direction
- **Line-break control** — use `word-break: keep-all` + `text-wrap: pretty/balance` to prevent single-character orphans and awkward breaks, especially for CJK text
- **Restrained color** — brand color as surgical accents (thin lines, small highlights); 90% monochrome
- **Asymmetric layouts** — golden ratio splits (1:1.618), offset elements
- **Generous whitespace** — 120-160px between sections
- **Grain texture** — subtle SVG noise overlay on body::after

## Workflow

### Step 1: Gather Inputs

| Input | Required | Description |
|-------|----------|-------------|
| Brand Brief | Yes | Brand name + industry + product/service + target audience, OR an uploaded logo image |
| Brand Name | Yes | Primary language + English if applicable |
| Style Direction | No | 3-5 keywords; infer from brief if not provided |
| Additional Context | No | Competitors, price range, market, cultural preferences |

### Step 2: Brand Strategy Analysis

Generate content per `references/strategy-framework.md`:

| Output | Description |
|--------|-------------|
| Value Proposition Tagline | One insightful manifesto line capturing the brand's core belief (max 15-20 words) |
| Logo Creative Rationale | Concept headline + narrative explaining design thinking, element breakdown, logo type & style |
| Copywriting | Slogan, brand story (150-200 words), 3 core messages |
| Implementation | 3-phase launch plan + channel recommendations |

### Step 3: Visual Design — Logo as Single Source of Truth

#### 3a: Establish LOGO_REF

**Route A (uploaded image):** Convert to base64 → designate as `LOGO_REF` → extract dominant color.

**Route B (uploaded SVG):** Use SVG inline for HTML; render to PNG via ImageGen for i2i reference → designate PNG as `LOGO_REF` → extract color from `fill` attributes.

**Route C (text only):** Follow the logo generation methodology in `references/design-integration.md` § Logo Generation:
1. Determine logo type (Symbol / Wordmark / Lettermark / Combination / Emblem / Mascot) based on brand name length, industry, and maturity
2. Select style direction (Minimalist / Modern-Tech / Vintage / Organic / Playful / Luxury) from brand brief
3. Choose element fusion pattern if combining multiple concepts (negative space, silhouette integration, shared contours, letterform substitution)
4. Build structured prompt: `[Style keywords] [Logo type] for "[Brand Name]", [main element], [composition], [color scheme], flat vector design, clean lines, scalable SVG, professional brand identity`
5. Generate via ImageGen at 1024x1024 → designate as `LOGO_REF` → extract dominant color

**Critical for Route C**: All prompts MUST include `flat vector` + `clean lines` + `scalable`. Never use 3D, photorealistic, complex shadows, or gradient meshes.

#### 3b: Color System FROM Logo

```
LOGO_REF → extract primary color → --brand-primary
         → derive accent (hue +150°) → --brand-accent
         → derive neutrals → --card-bg, --surface, --paper
         → pass into CSS variables + scene image prompts
```

Rules: `--brand-primary` must match logo's dominant color. Scene prompts must reference color by name + hex. If logo is monochrome black, choose color based on industry context. See `references/design-integration.md` for fallback colors.

#### 3c: Style Preset

Select from `references/design-integration.md` based on style keywords → determines fonts and layout details. Color comes from Step 3b, not the preset.

#### 3d: Generate 4 Scene Images

Generate 4 mockup images (1024x768, 4:3) using `LOGO_REF` as i2i reference. Every prompt MUST include: `"...the brand identity uses a [COLOR_NAME] palette ([HEX]), all branded elements reflect this color scheme..."`. Select scenarios from `references/design-integration.md`.

### Step 4: Generate HTML — 9 Sections

Output a single self-contained HTML file. See `references/proposal-sections.md` for CSS framework and section templates.

```
01: Cover — Striking typographic design (NOT plain centered heading; use mixed scales, offset, dynamic composition)
02: Value Proposition — Single powerful manifesto tagline, full-viewport cinematic treatment
03: Logo Creative Rationale — Design concept narrative + element breakdown explaining logo/graphic choices
04: Logo System — Primary logo + mono + reversed variants
05: Color & Typography — Palette swatches + font specimens (may recommend fonts beyond the 3 loaded)
06: Brand Applications — 4 generated mockup images (4:3)
07: Copywriting — Slogan hero + brand story + core messages
08: Implementation — 3-phase timeline + channels
09: Footer — Contact/credits
```

### Step 5: Image Embedding

| Source | Method | Variants |
|--------|--------|----------|
| Uploaded PNG/JPG | base64 `data:image/png;base64,...` in `<img src>` | CSS `filter` for mono/reversed |
| Uploaded SVG | Inline SVG, modify `fill` attrs | Direct `fill` color changes |
| Generated logo | File path or base64 | CSS `filter` for mono/reversed |
| Scene images | File paths from ImageGen in `<img src>` | — |

## Output Rules

Single HTML file. CSS in `<style>` (Google Fonts `<link>` allowed, max 3 font families). Background direction (dark/light/colored) chosen per brand — NOT always dark. Smooth scroll. Section numbering in mono labels (`01 —`, `02 —`...). No Lorem ipsum — all content brand-specific. Exactly 3 fonts loaded and used. `word-break: keep-all` + `text-wrap: pretty` for orphan prevention. Reads like a Pentagram/Collins agency deliverable.

## Quality Checklist

- [ ] 9 sections, correct numbering, zero border-radius, no emojis, no box-shadow
- [ ] Exactly 3 Google Fonts loaded; all CSS font-family resolves to those 3 only
- [ ] Background direction matches brand personality (not always dark)
- [ ] No single-character orphans; `word-break: keep-all` and `text-wrap` applied
- [ ] Cover (01): Creative typography — mixed scales, offset, NOT plain centered
- [ ] Value tagline (02): One insightful manifesto line, brand-specific, not generic
- [ ] Logo rationale (03): Concept headline + narrative + element breakdown with clear design reasoning
- [ ] LOGO_REF established before scene generation; all 4 scenes used same reference
- [ ] Color chain intact: logo → --brand-primary → scene tones → Section 05 swatches
- [ ] Asymmetric layouts, generous spacing, grain overlay
- [ ] Brand story 150-200 words; slogan memorable; implementation has 3 phases
- [ ] Section 05 may recommend additional brand fonts but page only uses the 3 loaded

## References

- `references/proposal-sections.md` — CSS framework + HTML templates for all 9 sections
- `references/strategy-framework.md` — Strategy content guidelines
- `references/design-integration.md` — Style presets, logo generation methodology, mockup scenarios, color system
