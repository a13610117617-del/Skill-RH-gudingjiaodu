# 品牌全案设计专家

- 文件夹名：`08-品牌全案设计专家__brandprok__3cbbcc9808b94b9b8cf97b62c62065a4`
- publicId：`3cbbcc9808b94b9b8cf97b62c62065a4`
- name：`brandprok`
- 分类：未标注
- 版本：28
- 更新时间：2026-06-11T09:14:57.000+00:00
- 来源：https://d.design/api/agent/v1/skills/3cbbcc9808b94b9b8cf97b62c62065a4

## 能干什么

面向品牌创建、升级与提案等场景。从核心概念的建立，到落地的执行方向，厘清品牌的核心价值定位，生成完整品牌提案。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
