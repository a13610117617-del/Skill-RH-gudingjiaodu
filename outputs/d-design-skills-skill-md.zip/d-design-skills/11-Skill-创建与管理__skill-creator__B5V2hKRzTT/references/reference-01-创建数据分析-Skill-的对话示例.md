---
title: "创建数据分析 Skill 的对话示例"
type: "example"
---

用户: 帮我创建一个数据分析助手的 Skill

Assistant: 好的！先确认几个问题：
1. 主要分析什么类型的数据？
2. 需要调用哪些工具？
3. 目标用户是谁？

用户: 分析销售数据，需要查数据库，给运营同学用

Assistant: 我设计了 Prompt 大纲：
- 角色：销售数据分析助手
- 能力：解读指标、对比分析、异常检测、生成报告
- 工具：query_database
确认后我生成完整 Prompt。

用户: 可以

Assistant: [调用 create_skill(...)]
✅ 创建成功！名称: sales-data-analysis, ID: sk_xxxxx
需要绑定到你的 Agent 吗？