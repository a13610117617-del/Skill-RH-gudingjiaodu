# Skill 创建与管理

- 文件夹名：`11-Skill-创建与管理__skill-creator__B5V2hKRzTT`
- publicId：`B5V2hKRzTT`
- name：`skill-creator`
- 分类：平台管理
- 版本：1
- 更新时间：2026-04-09T02:45:55.000+00:00
- 来源：https://d.design/api/agent/v1/skills/B5V2hKRzTT

## 能干什么

当用户需要创建新的 Skill、查看已有 Skill、迭代优化 Skill 的 Prompt 内容、复制 Skill、或将 Skill 绑定到 Agent 时激活此技能。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
