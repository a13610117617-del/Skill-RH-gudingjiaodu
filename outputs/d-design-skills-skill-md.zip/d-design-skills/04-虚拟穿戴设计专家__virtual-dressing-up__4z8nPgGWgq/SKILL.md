## 使用场景

当用户提到以下内容时使用此 Skill：
- 虚拟试衣
- tryon
- AI 试穿
- 穿搭效果图
- 虚拟试鞋
- 配饰试戴

激活本 Skill 后，**必须严格按照以下 Workflow 执行**， 禁止跳过任何步骤，禁止调用本skill之外的工具。Core Workflow 中的 "简单指令优化"逻辑在本 Skill 激活期间**完全失效**。
## 核心功能

1. **图像理解**：使用通义千问视觉模型识别用户上传的图片内容
2. **智能匹配**：根据识别结果自动调用对应的虚拟试、穿 API
   - 服装 + 模特 → 虚拟试衣
   - 仅服装 → 模特模板查询 → 虚拟试衣
   - 鞋子 + 模特 →  虚拟试鞋
   - 仅鞋子 → 模特模板查询 → 虚拟试鞋
   - 配饰 + 模特 →  虚拟配饰
   - 仅配饰 →  模特模板查询 → 虚拟配饰
3. **满意度反馈**：生成结果后询问用户，不满意可重新生成或更换素材
4.**用户打断后重新唤起**：例如先输入了虚拟试穿，agent说需要上传产品图后，继续使用此skill完成后续工作，不许脱离此skill执行
## 交互式使用流程

### 第一步：上传图片

告诉用户：
```
请上传图片（可一次性上传多张，支持模特图、服装、鞋子、配饰等）
图片需可公开访问（URL 形式）
```

让用户输入一个或多个图片 URL（用逗号或换行分隔）。

### 第二步：图像理解

用户上传图片后，告诉用户：
```
正在进行图像理解分析您的图片，请耐心等待
```
**直接调用** `get_try_on_image_info` **一次性分析所有图片**。


**返回结果格式：**

**批量分析结果（返回JSON数组）：**
```json
[
  {
    "index": 1,
    "imageUrl": "图片1的URL",
    "imageType": "MODEL/DRESS/SHOES/LONG_COAT/LONG_SKIRT/LONG_SLEEVED_TOP/SHORTS/SHORT_SKIRT/SHORT_SLEEVED_TOP/SLEEVELESS_TOP/TROUSERS/BAG/GLASSES/HAT/NECKLACE/EARRINGS/OTHER",
    "category": "具体分类",
    "description": "图片内容描述",
    "width": 960,
    "height": 1280,
    "aspect_ratio": "3:4"
  },
  {
    "index": 2,
    "image_url": "图片2的URL",
    "image_type": "...",
    ...
  }
]
```

**分类说明：**
- MODEL: 人物模特照片
- DRESS/LONG_COAT/LONG_SKIRT/LONG_SLEEVED_TOP/SHORTS/SHORT_SKIRT/SHORT_SLEEVED_TOP/SLEEVELESS_TOP/TROUSERS: 各种服装类型
- SHOES: 鞋子
- BAG/GLASSES/HAT/NECKLACE/EARRINGS: 配饰（HAT/帽子、GALSSES/眼镜、BAG/包包、NECKLACE/项链、EARRINGS/耳环）
- OTHER: 其他无法识别的图片
如果检查到用户上传的是套装（不为单一产品类目），则"imageType"需要根据上述分类涵盖套装中的所有类目，每个类目用逗号隔开，作为执行结果。
**配饰类目处理：**
当检测到配饰类型时，统一调用 gen_try_on_common 生成效果：
type字段改为下面的服饰类型映射
- 包包(BAG) → typegemini_bag
- 帽子(HAT) → gemini_hat
- 眼镜(GLASSES) → gemini_glasses
- 耳环(EARRINGS) → gemini_earring
- 项链(NECKLACE) → gemini_necklace

**aspect_ratio 比例说明：**
- 用于后续 gen_try_on_common 调用时指定输出图片比例
- 支持：1:1, 1:4, 1:8, 2:3, 3:2, 3:4, 4:1, 4:3, 4:5, 5:4, 8:1, 9:16, 16:9, 21:9

**分类处理 + 用户意图解析**

当分析完所有图片后，需要根据识别结果和用户需求进行分类处理：

| 识别类型 | 处理方式 |
|---------|---------|
| 单张模特 + 1张产品图 | 直接调用 gemini_common |
| 单张模特 + ≥2张不同类型产品图 |直接调用 gemini_common |
| 单张模特 + 单个鞋子 |直接调用 调用 gemini_shoes |
| 单张模特 + 单个包包 |直接调用 调用 gemini_bag |
| 单张模特 + 单个帽子 |直接调用 调用 gemini_hat |
| 单张模特 + 单个眼镜 |直接调用 调用 gemini_glasses |
| 单张模特 + 单个耳环 |直接调用 调用 gemini_earring |
| 单张模特 + 单个项链 |直接调用 调用 gemini_necklace |

 **其余情况请参考下列情况灵活进行调用** 

**场景一：所有图片都是模特图（imageType 均为 MODEL）**
- 如果用户有明确需求（如"把第一张的包换到第二张模特手上"）：
  1. 解析用户指令，按用户指定的顺序匹配
  2. **自动修改 JSON 中的 imageType**：
     - 产品来源图（如"第一张"）→ 改为对应产品类型（SHOES/DRESS/LONG_COAT/LONG_SKIRT/LONG_SLEEVED_TOP/SHORTS/SHORT_SKIRT/SHORT_SLEEVED_TOP/SLEEVELESS_TOP/TROUSERS/BAG/GLASSES/HAT/NECKLACE/EARRINGS/OTHER）
     - 目标模特图 → 保持 MODEL
  3. 修正 JSON 后调用对应的生成脚本
- 如果用户没有明确需求 → 询问用户缺少哪张图片或者询问用户需要将哪张图片作为产品图，并将用户选择的那张改为对应产品类型

**场景二：所有分析后图片都是产品图（SHOES/DRESS/LONG_COAT/LONG_SKIRT……）**
- 如果用户有明确需求 → 按照用户指令匹配
- 如果用户没有明确需求 → 模板推荐 → 图像生成

**场景三：混合类型（既有模特图又有不同的多张产品图）且模特数量 = 1**
- 询问用户如何生成：例如将每件上衣分别穿在同一模特身上/将第二件上衣穿在模特身上/将上衣和裤子穿在同一张模特身上…………（各种情况均需要兼容）
- 确认意图后调用对应的tool进行生图

**场景四：多张模特混合类型（≥2张 MODEL）+ 服装/配饰图**

识别到 ≥2 张模特时，**必须先询问用户**：
- 询问用户如何生成：例如将每件上衣分别穿在同一模特身上/将每件上衣分别穿在不同模特身上/将第二品分别穿在同一个模特身上……（各种情况均需要兼容）
- 确认意图后调用对应的tool进行并发生图
```
**智能提示词生成（--gemini 模式，仅产品≥2张时触发）**
- 当检测到服装数量≥2时，自动根据返回的imageType和description生成适用于 gemini_common 的提示词
- 提示词格式："图1的xx模特换上图2的xx服装和图3的xx鞋子"这样的效果
- 提示词详细描述每件服装的款式、颜色、图案等特点
- 生成的参数包含：modelImage、imageUrls、aspectRatio、type、userPrompt
modelImage：模特图url单个
imageUrls：产品图片 URL 列表多个
aspectRatio：输出图片尺寸比例，如 "1:1"、"3:4"、"9:16" 等，模型推断 
type：（试穿商品类型，对应 ：
aib_tryOn: aib的试衣
gemini_common :通用
 gemini_shoes :试鞋gemini_necklace: 虚拟试项链 
 gemini_hat:虚拟试帽子
 gemini_glasses:试眼镜
gemini_earring:虚拟试耳环
gemini_bag:虚拟试包
类型由模型判断）
userPrompt：AI模型描述输入，gemini_common 时传入
clothesTypes：tops/outwears/dresses/bottoms
aib_tryOn 的时候传，其他不传

**提示词生成示例：**
假设识别到用户上传：图1=模特、图2=连衣裙、图3=鞋子
生成的提示词："将图1中的模特换成图2的绿色热带植物图案白色连衣裙（短袖、A字裙摆），脚上穿上图3的白色紫色装饰运动鞋，保持模特姿势和背景不变"

**直接调用 gen_try_on_common：**

# 使用生成的参数（假设为上面返回的 Gemini 调用参数）
modelImage = "模特图URL" （一定使用用户上传的完整模特图url，不能删减或者使用虚假url） # 
imageUrls = "服装图片URL"（一定使用用户上传的完整服装或者产品的url）
userPrompt = "生成的AI提示词（一定要明确图片1图片2字段的对应关系）"
aspectRatio = "3:4"

# 调用 gemini_common

### 第三步：选择模特模板 ###
当图片理解后只识别到了服装、鞋子或者配饰等（没有MODEL类型的图片），告知用户请选择模特模版，将调用 `query_try_on_template` 进行模特模板推荐。

**单产品图规则：**
如果 `get_try_on_image_info` 中返回的 imageType 仅有一个不为 MODEL（即只上传了一个产品图），则直接使用该产品图的 "description" 字段作为 `query_try_on_template` 的入参的"description"，使用该产品图的 "imageType" 字段作为 `query_try_on_template` 的入参的"imageType"调用模板推荐，无需合并。"templateNum": 8 不改变
入参示例：
```json
{
"templateNum": 8,
"description": "一个20岁的亚洲黄皮肤女性，穿着米白色短款T恤和蓝色高腰直筒牛仔裤，搭配白色运动鞋，双手自然下垂，正面站立，ins休闲风格",
"imageType": "TROUSERS"
}
```

**合并 description 规则：**
如果 `get_try_on_image_info` 中返回的 imageType 有两个或两个以上都不为 MODEL，则分析所有返回的 description 字段，合并为一个统一的描述用于 query_try_on_template 模板推荐。

**合并示例：**
假设返回结果为：
```json
[
  {
    "index": 1,
    "imageUrl": "第1张图片URL",
    "imageType": "DRESS",
    "category": "淡黄色长裙",
    "description": "一个25岁的欧洲白皮肤女性，穿着淡黄色长裙，双手叉腰，正面，ins街头风格",
    "width": 960,
    "height": 1280,
    "aspectRatio": "3:4"
  },
  {
    "index": 2,
    "imageUrl": "第2张图片URL",
    "imageType": "LOW_CUT_SHOES",
    "category": "低帮运动鞋",
    "description": "一个20岁的亚洲黄皮肤女性，穿着牛仔裤，低帮运动鞋，双手自然垂放，正面全身，室内风格",
    "width": 960,
    "height": 1280,
    "aspectRatio": "3:4"
  }
]
```

**合并后的 description 用于 ModelCheckbox：**
将两个 description 合并为一个完整的穿搭描述，例如：
- 保留第一个人物的特征描述作为主要参考（年龄、肤色、性别等）
- 融入第二个人物的鞋子特征
- 以此类推
- 入参示例：
```json
{
  "pageSize": 8,
  "imageType": "DRESS,LOW_CUT_SHOES",
  "description": "一个25岁的欧洲白皮肤女性，穿着淡黄色长裙，低帮运动鞋，双手叉腰，正面全身，ins街头风格"
  
}
```
**单产品图规则：**                
如果 `get_try_on_image_info` 中返回的 imageType 仅有一个不为 MODEL（即只上传了一个产品图），则直接使用该产品图的 "description" 字段作为 `ModelCheckbox` 的入参调用模板推荐，无需合并。   

**模板推荐流程：**
1. 调用 `ModelCheckbox`，直接传入分析产品后或者多个产品合并后的 description
2. 使用`ModelCheckbox`工具直接渲染前端卡片组件，`ModelCheckbox`工具的入参是第一步中返回的结果并按照如下入参格式字段映射： 
{
  "modelList": [
    {
      "previewUrl": "（ModelCheckbox返回结果的previewUrl）",
      "imageUrl": "（ModelCheckbox返回结果的imageUrl）"
    }
  ]
}

出参格式： {
  "imageUrl": [
    "imageUrl1",
    "imageUrl2"
  ] // gen_try_on_common中modelImage的入参
}
3. 让用户点击选择心仪的模特模板编号（1-8）也可以点击全部模板进行选择，之后 采用`ModelCheckbox` 返回结果中的imageUrl
4. 模版库调用完成后，按模特顺序展示每张效果图，使用`ModelCheckbox`中imageUrl完整字段展示到前端，禁止使用previewUrl字段的任何内容！并告展示前端。
5. 下面是`query_try_on_template`返回的例子。选择完成后使用data.imageUrl进行 modelImage 的参数的赋值。禁止去掉imageUrl中的任何数据

{"traceId":null,"code":null,"data":[{"previewUrl":"https://piccopilot.oss-accelerate.aliyuncs.com/static/tryOn_model/female_Spr3_2.png?Expires=2090908660&OSSAccessKeyId=LTAI5tAt4VGUZ2t5U68W4uFh&Signature=l17uLWDbgPgXJkiHbLjkM3SYrlo%3D&x-oss-process=image%2Fauto-orient%2C1%2Fresize%2Cm_lfit%2Cw_512%2Fquality%2Cq_100%2Fformat%2Cavif","imageUrl":"https://piccopilot.oss-accelerate.aliyuncs.com/static/tryOn_model/female_Spr3_2.png?Expires=2090908660&OSSAccessKeyId=LTAI5tAt4VGUZ2t5U68W4uFh&Signature=l17uLWDbgPgXJkiHbLjkM3SYrlo%3D&x-oss-process=image%2Fauto-orient%2C1%2Fresize%2Cm_lfit%2Cw_512%2Fquality%2Cq_100%2Fformat%2Cavif","name":"上衣模特1","description":"金发女生，黄色外套全套，站姿","templateId":"1769","type":"LONG_COAT","class":"com.alibaba.uedmid.aigc.model.result.mcp.TryOnTemplateResult","ratio":null}],"level":"GREEN","success":true,"message":null,"class":"com.alibaba.uedmid.ms.common.DataResult"}


选择完成后，将用户选择好的模特data.imageUrl作为模特图，并与原始服装/鞋子/配饰图片一起调用对应`gen_try_on_common`中对应的生成方式进行生图。防止幻觉窜行[参考文档：工具入参调用指南]如果用户选择的多张模特图，要分别将用户选择好的imageUrl与用户上传的产品图进行匹配，再依次调用对应`gen_try_on_common`中对应的生成方式进行生图。
6. 如果用户选择了'AI决策' "imageUrl1"为空，证明无需选择任何模特模板，直接通过提示词将用户的产品穿到适配的模特身上，如果用户有指定要求，按照要求撰写提示词后，直接调用`gen_try_on_common`进行生成
### 第四步：选择完成后调用 gen_try_on_common MCP 生成 确认好type正确（和之前用户提供模特的结构一样，需要替换modelImage字段为`ModelCheckbox`中"imageUrl"完整的返回字段） 
用户选择完模特图或者已经有模特图后，告诉用户：
```
正在进行换装生成，请耐心等待
```
- 入参示例：
{
    "userPrompt": "",
    "imageUrls": "服装图片完整原始URL",
    "aspectRatio": "1:1",
    "source": "iframe",
    "type": "gemini_common",
    "modelImage": "模特图片`ModelCheckbox`返回的原始data.imageUrl，不允许中断",
    "userId": "123",
    "clothesTypes": ""
  }
modelImage = "模特图URL" （一定使用用户上传或者query_try_on_template用户选择完成后返回的完整data.imageUrl是模版图url字段，禁止使用data.previewUrl字段的任何内容！，不能删减或者使用虚假url，防止幻觉窜行） # 
imageUrls = "服装图片URL"（一定使用用户上传的完整服装或者产品的url）
userPrompt = "生成的AI提示词"
aspectRatio = "3:4"

这个接口返回例子：
{
  "traceId": null,
  "code": null,
  "data": "x5tUMACy8X",
  "level": "GREEN",
  "success": true,
  "message": null,
  "class": "com.alibaba.uedmid.ms.common.DataResult"
}

### 第五步：返回结果并询问满意度
使用 data中的结果去调用轮训接口poll_task_result 
提交全部任务之后进行轮询查询，告诉用户结果图片展示到画布或者对话并且同时执行其他的图片轮询，全部完成后并询问：
```
生成完成！




## NextAction

任务完成后，根据情况推荐以下操作：

| 条件 | 推荐操作 |
|------|----------|
| 重新生成 |参数不变，直接重新调用生图模型再次生成一遍 |
| 更换素材 | 让用户上传新的图片，替换对应类型的素材后重新生成 |
| 更换模特 | 让用户上重新选择ModelCheckbox查询出来的图片，选择完成后继续后续流程|
| 完成 | 结束当前任务 |


## tool文件

| 文件 | 说明 |
|------|------|
| `ModelCheckbox` | 模特模板查询及前端卡片渲染|
| `gemini_common` | Gemini 图像生成客户端（服装多张时或者已经获取到了单张模特和单张产品时使用，根据用户需求生成提示词） |
| `gemini_shoes` | 虚拟试鞋（内置固定提示词） |
| `gemini_bag` | 虚拟试包（内置固定提示词） |
| `gemini_hat` | 虚拟试帽（内置固定提示词） |
| `gemini_glasses` | 虚拟试眼镜（内置固定提示词） |
| `gemini_earring` | 虚拟试耳环（内置固定提示词） |
| `gemini_necklace` | 虚拟试项链（内置固定提示词） |
