# 虚拟穿戴设计专家

- 文件夹名：`04-虚拟穿戴设计专家__virtual-dressing-up__4z8nPgGWgq`
- publicId：`4z8nPgGWgq`
- name：`virtual-dressing-up`
- 分类：未标注
- 版本：105
- 更新时间：2026-06-04T14:57:17.000+00:00
- 来源：https://d.design/api/agent/v1/skills/4z8nPgGWgq

## 能干什么

当用户需要制作上下衣/裙子/鞋靴/背包挎包/帽子/眼镜/耳环/项链等相关商品，在模特身上试穿、试戴效果图或穿搭效果图时，使用本技能。推荐用户上传相关商品图，并指出需要什么样的模特试穿试戴。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
