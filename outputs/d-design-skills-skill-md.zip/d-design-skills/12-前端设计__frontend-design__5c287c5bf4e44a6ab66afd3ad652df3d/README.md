# 前端设计

- 文件夹名：`12-前端设计__frontend-design__5c287c5bf4e44a6ab66afd3ad652df3d`
- publicId：`5c287c5bf4e44a6ab66afd3ad652df3d`
- name：`frontend-design`
- 分类：未标注
- 版本：2
- 更新时间：2026-03-30T12:49:58.000+00:00
- 来源：https://d.design/api/agent/v1/skills/5c287c5bf4e44a6ab66afd3ad652df3d

## 能干什么

Create distinctive, production-grade frontend interfaces with high design quality. Use this skill when the user asks to build web components, pages, or applications. Generates creative, polished code that avoids generic AI aesthetics.
license: Complete terms in LICENSE.txt

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
