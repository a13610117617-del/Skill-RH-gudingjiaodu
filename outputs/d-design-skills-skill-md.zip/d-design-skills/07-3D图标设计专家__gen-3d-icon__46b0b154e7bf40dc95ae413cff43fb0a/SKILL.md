# 3D Icon Prompt Generator

This skill transforms simple user input into detailed, professional prompts for generating modern 3D isometric icons with transparent backgrounds, using automated image generation and background removal.

## Process

When user provides simple keywords or descriptions for icon generation:

1. **Expand the user's input** following these principles:
   - Identify the core subject
   - Add rich material details (e.g., frosted glass, polished chrome, liquid metal, glowing resin)
   - Describe lighting effects (ambient light, edge lighting, subsurface scattering)
   - Include floating particles, flowing lines, or small decorative elements
   - Keep the expanded description under 200 characters
   - **Constraints**: NO human figures, body parts, or text/characters allowed

2. **Select a random reference image** from this list (internal use only, not shown to user):
   ```
   https://img.alicdn.com/imgextra/i2/O1CN01riCZnk1wZ4eU1Y4QB_!!6000000006321-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN01TPLWjt1bZtQfZ2zYd_!!6000000003480-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01CvqKZc1SqXHNn4Xi6_!!6000000002298-2-tps-1068-1024.png
   https://img.alicdn.com/imgextra/i1/O1CN01Q32zHR1m4iErvZuBI_!!6000000004901-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01FeGvXi1yryDzpPHiZ_!!6000000006633-2-tps-1024-1100.png
   https://img.alicdn.com/imgextra/i1/O1CN01dN2iIj1tnK7y3p4uW_!!6000000005946-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01gONskr1eR8hsksg7R_!!6000000003867-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN01ZMg3nW1gTY1LZiAWN_!!6000000004143-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN01ugY4ai1vmz46X9ull_!!6000000006216-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN01tRV4Gt1Ca18ufptYk_!!6000000000096-2-tps-1275-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN0162JNZF1NuahvYmLTQ_!!6000000001630-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i1/O1CN01vJOvH21I2TpqrmjQo_!!6000000000835-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i1/O1CN01iJPuKB1g19SreM0YY_!!6000000004081-2-tps-1108-1108.png
   https://img.alicdn.com/imgextra/i1/O1CN01irbV181ir1YPWO6EW_!!6000000004465-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i1/O1CN01G2B2ge1zFKQLFG0hc_!!6000000006684-2-tps-1050-1050.png
   https://img.alicdn.com/imgextra/i4/O1CN01Q4J2zI1K85vDicCqS_!!6000000001118-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN017oC6F91LbEjsRBbSW_!!6000000001317-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN01BjyxNR1hx9EZfnAfF_!!6000000004343-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN01QhFLhr1T2RZq3ynIv_!!6000000002324-2-tps-1027-1027.png
   https://img.alicdn.com/imgextra/i2/O1CN01iC4QY71k6QUOJah1a_!!6000000004634-2-tps-1026-1026.png
   https://img.alicdn.com/imgextra/i3/O1CN01Alb4gr1L9kyVGbQh2_!!6000000001257-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i1/O1CN01T3eFfc1c7mjpJq0r0_!!6000000003554-2-tps-1141-1142.png
   https://img.alicdn.com/imgextra/i2/O1CN01FlKWDa1kMukPB24dp_!!6000000004670-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN015Cenw11yE7lbJYTVE_!!6000000006546-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i3/O1CN01NMKZR71w2YX0ATohL_!!6000000006250-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01Ct8L3Q1jUPcEjiKLH_!!6000000004551-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN01qj7InQ1PzI0CsIOmc_!!6000000001911-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01qUqi3D1E2FAS96lR0_!!6000000000293-2-tps-1024-1024.png
   https://img.alicdn.com/imgextra/i4/O1CN01mG4ka21DUoFqtwMsn_!!6000000000220-2-tps-1036-1057.png
   https://img.alicdn.com/imgextra/i3/O1CN01apmR1u1H2ByDBbvQF_!!6000000000699-2-tps-1084-1024.png
   https://img.alicdn.com/imgextra/i2/O1CN01VqA4uG1LFFjBqNtkW_!!6000000001269-2-tps-1024-1024.png
   ```

3. **Format the final prompt** using this template:
   ```
   参考图1的风格，创建一个现代拟物3d图标，等轴侧图，1:1比例，背景透明.
   {expanded_user_input}.
   材质混搭达到最佳真实效果，色彩鲜亮时尚，画面细腻.
   ```

4. **Call 全新ImageV2模型 图片生成 tool ** to generate the initial image

5. **使用抠图工具抠掉背景**

6. **Present the final transparent background image with design description**

## Expansion Guidelines

When expanding user input, consider:

- **Materials**: Frosted glass, polished metal, ceramic glaze, jelly-like texture, liquid metal, glowing resin
- **Lighting**: Ambient light, edge/rim lighting, subsurface scattering (SSS), soft shadows
- **Accents**: Floating particles, flowing lines, geometric patterns, small decorative objects
- **Atmosphere**: Tech-inspired, warm/cool tones, gradient backgrounds, depth of field

## Workflow (Internal - Not Shown to User)

```
User Input → Expand Description → Select Random Reference Image → Format Prompt 
→ Generate Image (全新ImageV2模型) → Remove Background (2048×2048) 
→ Return Final Image with Design Description
```

## Output Format

[Display the transparent background image]

**✨ 你的 {subject} 3D 图标已完成，2048×2048px。**

**设计说明：**
- {Material descriptions and textures}
- {Lighting effects}
- {Decorative elements}
- {Technical details like edge lighting, shadows, etc.}

**Do NOT mention:**
- Reference images or which one was selected
- The two-step process (generation + background removal)
- Tool names or technical workflow

## Tool Call Sequence

1. 全新ImageV2模型 图片生成
   - Input: Formatted prompt with reference image
   - Output: Generated 3D icon image URL

## Example

User input: "一个咖啡杯"

**User sees:**

[Transparent background 3D coffee cup icon image at 2048×2048]

✨ 你的咖啡杯 3D 图标已完成，2048×2048px。

**设计说明：**
- 半透明陶瓷材质，温润釉面光泽
- 杯中咖啡呈现焦糖渐变色
- 蒸汽状流动粒子环绕杯身
- 边缘高光 + 柔和投影