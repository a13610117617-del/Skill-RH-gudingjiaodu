# 3D图标设计专家

- 文件夹名：`07-3D图标设计专家__gen-3d-icon__46b0b154e7bf40dc95ae413cff43fb0a`
- publicId：`46b0b154e7bf40dc95ae413cff43fb0a`
- name：`gen-3d-icon`
- 分类：设计
- 版本：27
- 更新时间：2026-06-11T09:16:45.000+00:00
- 来源：https://d.design/api/agent/v1/skills/46b0b154e7bf40dc95ae413cff43fb0a

## 能干什么

批量生成电商促销、类目导航及 UI 界面等高频图标场景的 3D Icon ，将平台视觉语言参数化，有效提升素材生产效率与视觉一致性。

## 文件说明

- `content.md`：该 Skill 公开详情接口返回的主 prompt/content。
- `references/`：该 Skill 附带的参考资料，若接口有返回。
- `metadata.json`：名称、描述、版本、来源接口等元数据。
